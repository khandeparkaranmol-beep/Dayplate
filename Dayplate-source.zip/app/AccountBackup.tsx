"use client";
import {useRef,useState} from "react";
import {Modal} from "./ui";
import {shareJSON} from "./share-file";
import {sendEntries,restoreBatch} from "./activity-records";
import type {Stored} from "./model";
export default function AccountBackup({close,refresh}:{close:()=>void,refresh:()=>Promise<void>}){
 const [busy,setBusy]=useState(false),[msg,say]=useState("");const input=useRef<HTMLInputElement>(null);
 async function run(job:()=>Promise<string>){setBusy(true);try{say(await job())}catch(e){say((e as Error).message)}finally{setBusy(false)}}
 return <Modal title="Your account" close={()=>{if(!busy)close()}} description="Your private diary follows you across devices when you use the same sign-in."><div className="backup-buttons">
 <button className="light full" disabled={busy} onClick={()=>void run(async()=>{const r=await fetch("/api/journal",{cache:"no-store"});if(!r.ok)throw Error("Could not export your diary.");await shareJSON(JSON.stringify({app:"dayplate",format:1,exportedAt:new Date().toISOString(),entries:await r.json()}),"dayplate-backup.json","backup");return "Diary exported."})}>Export private diary</button>
 <button className="light full" disabled={busy} onClick={()=>input.current?.click()}>Import a Dayplate backup</button><input type="file" ref={input} accept=".json" hidden onChange={e=>{const f=e.target.files?.[0];e.target.value="";if(!f)return;void run(async()=>{if(f.size>50_000_000)throw Error("Choose a backup under 50 MB.");const v=JSON.parse(await f.text());if(v.app!=="dayplate"||v.format!==1||!Array.isArray(v.entries))throw Error("Choose a Dayplate backup.");for(let i=0;i<v.entries.length;i+=25)if(!restoreBatch.safeParse({action:"restore",entries:v.entries.slice(i,i+25)}).success)throw Error("This file includes an invalid diary entry.");await sendEntries(fetch,"restore",v.entries as Stored[]);await refresh();return "Imported missing records. Your existing entries were kept."})}}/>
 <p className="note">Import adds the entries in your selected file to the account you’re using.</p><button className="account-link" disabled={busy} onClick={()=>void run(async()=>{const res=await fetch("/api/google/signout",{method:"POST"});if(!res.ok)throw Error("Could not sign out. Try again.");const {next}=await res.json() as {next:string};location.assign(next);return "Signing out…"})}>Sign out</button></div>{msg&&<p role="status">{msg}</p>}</Modal>
}
