export function BiscuitLabel({open}:{open:(name:string)=>void}){
  return <div className="note"><b>Looking for Dark Magic?</b>
    <p>Choose the biscuit that matches your packet, or enter the nutrition printed on your Dark Magic pack.</p>
    <button type="button" className="light" onClick={()=>open("Britannia Dark Magic")}>Enter Dark Magic label</button>
  </div>;
}
