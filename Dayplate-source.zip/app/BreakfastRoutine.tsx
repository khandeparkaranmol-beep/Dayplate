"use client";
import {useState} from "react";
import {Sunrise,Check} from "lucide-react";
import {Modal,Field} from "./ui";
import {shift,foodEntries,type Entry,type Stored} from "./model";
import type {FoodEntry} from "./repeat";

type Plan = Extract<Entry,{kind:"routine"}>;
const labels=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const weekday=(day:string)=>new Date(day+"T12:00:00").getDay();
const breakfast=(rows:Stored[],day:string)=>foodEntries(rows).filter(r=>r.day===day&&r.data.meal==="Breakfast");
export function BreakfastRoutine({rows,today,busy,save,repeat,log}:{rows:Stored[],today:string,busy:boolean,save:(e:Entry,msg:string)=>Promise<boolean>,repeat:(items:FoodEntry[])=>Promise<boolean>,log:()=>void}){
  const plans=rows.filter((r):r is Plan & {revision:number}=>r.kind==="routine").sort((a,b)=>b.day.localeCompare(a.day));
  const planAt=(date:string)=>plans.find(r=>r.day<=date)?.data;
  const plan=planAt(today);
  const [adjust,setAdjust]=useState(false);
  const [cue,setCue]=useState("After morning chai");
  const [days,setDays]=useState<number[]>([1,2,3,4,5,6,0]);
  const [usual,setUsual]=useState("");
  const [paused,setPaused]=useState(false);
  function edit(){
    setCue(plan?.cue??"After morning chai");setDays(plan?.days??[1,2,3,4,5,6,0]);
    setUsual(plan?.usualDay??"");setPaused(plan?.paused??false);setAdjust(true);
  }
  const breakfasts=foodEntries(rows).filter(r=>r.data.meal==="Breakfast"&&r.day<=today);
  const choices=[...new Set(breakfasts.map(r=>r.day))].sort().reverse().filter(d=>breakfast(rows,d).length<=40);
  const saved=plan?.usualDay?breakfast(rows,plan.usualDay):[];
  const logged=breakfast(rows,today).length>0;
  const planned=plan&&!plan.paused&&plan.days.includes(weekday(today));
  const monday=shift(today,-((weekday(today)+6)%7));
  let total=0,done=0;
  for(let d=monday;d<=today;d=shift(d,1)){
    const past=planAt(d);
    if(past&&!past.paused&&past.days.includes(weekday(d))){total++;if(breakfast(rows,d).length)done++}
  }
  return <section className="panel breakfast-routine"><div className="section-head"><h2><Sunrise size={20}/>Breakfast routine</h2><button className="text-btn" onClick={edit}>{plan?"Adjust routine":"Set up"}</button></div>
    {plan?<><p>{plan.paused?"Routine paused":plan.cue+" · "+plan.days.slice().sort((a,b)=>(a+6)%7-(b+6)%7).map(d=>labels[d]).join(", ")}</p>
    {planned&&(logged?<strong><Check size={16}/> Breakfast logged today</strong>:<div>{saved.length>0&&<p>{saved.map(r=>r.data.quantity+" × "+r.data.food.name+" ("+r.data.food.serving+")").join(" · ")}</p>}{saved.length>0&&saved.length<=40?<><button className="primary" disabled={busy} onClick={()=>void repeat(saved.map((r,i)=>({kind:"food",day:today,id:"usual-breakfast-"+today+"-"+i,data:{...r.data}})))}>Log usual breakfast</button><button className="text-btn" onClick={log}>Log something else</button></>:<button className="primary" disabled={busy} onClick={log}>Log breakfast</button>}</div>)}
    {total>0&&<small>This week so far · {done} of {total} planned mornings logged</small>}</>:<p>Choose when to log breakfast and save your usual meal.</p>}
    {adjust&&<Modal close={()=>{if(!busy)setAdjust(false)}} title={plan?"What would make breakfast easier to log?":"Your breakfast routine"}><form onSubmit={async e=>{e.preventDefault();if(await save({id:"routine-"+today,kind:"routine",day:today,data:{cue:cue.trim(),days,usualDay:usual||null,paused}},"Breakfast routine saved"))setAdjust(false)}}>
      <Field label="When will you log breakfast?"><input required maxLength={80} value={cue} onChange={e=>setCue(e.target.value)}/></Field>
      <fieldset><legend>Planned mornings</legend><div className="routine-days">{[1,2,3,4,5,6,0].map(d=><button key={d} className="light" type="button" aria-pressed={days.includes(d)} onClick={()=>setDays(days.includes(d)?days.filter(v=>v!==d):[...days,d])}>{labels[d]}</button>)}</div></fieldset>
      <Field label="Usual breakfast"><select value={usual} onChange={e=>setUsual(e.target.value)}><option value="">Choose food each morning</option>{choices.map(d=><option key={d} value={d}>{d} · {breakfast(rows,d).map(r=>r.data.food.name).join(", ")}</option>)}</select></Field>
      {!choices.length&&<p className="note">Log your first breakfast to use it again here.</p>}
      <label><input type="checkbox" checked={paused} onChange={e=>setPaused(e.target.checked)}/> Pause routine</label>
      <button className="primary full" disabled={busy||!days.length||!cue.trim()}>Save routine</button>
    </form></Modal>}
  </section>;
}
