"use client";
import {useState} from "react";
import {Sunrise} from "lucide-react";
import {dateKey,foodEntries,type Stored,type Entry} from "./model";
import {Field,Modal} from "./ui";
import {hungerSummary,rounded,shortDay,type Experiment,type Hunger} from "./week-story";

type Save=(entry:Entry,message:string,revision?:number)=>Promise<boolean>;
export const experiments=(rows:Stored[])=>rows.filter((r):r is Experiment=>r.kind==="experiment").sort((a,b)=>b.day.localeCompare(a.day)||b.id.localeCompare(a.id));
export function todaysStudy(rows:Stored[],day:string){
  return experiments(rows).find(e=>day>=e.day&&(!e.data.end||day<=e.data.end));
}
const ratingFor=(rows:Stored[],e:Experiment,day:string)=>rows.find((r):r is Hunger=>r.kind==="hunger"&&r.data.experiment===e.id&&r.day===day);
export function BreakfastStudy({rows,day,busy,start,rate,save}:{rows:Stored[],day:string,busy:boolean,start:()=>void,rate:(e:Experiment)=>void,save:Save}){
  const [picked,pick]=useState(""),[confirm,ask]=useState(false);
  const history=experiments(rows).filter(e=>e.day<=day);
  const study=history.find(e=>e.id===picked)??history.find(e=>!e.data.end)??history[0];
  const canStart=day===dateKey()&&!experiments(rows).some(e=>!e.data.end||e.data.end>=day);
  return <section className="panel breakfast-study"><div className="section-head"><div className="title-line"><Sunrise size={20}/><h2>Breakfast experiment</h2></div>{canStart&&<button className="light" onClick={start}>Start experiment</button>}</div>
    {!study?<p>Choose two breakfasts you already eat. After lunch, record how hungry you felt at about the same time each day.{day!==dateKey()?" Go to today to start.":""}</p>:<>
    {history.length>1&&<Field label="Experiment"><select value={study.id} onChange={e=>{pick(e.target.value);ask(false)}}>{history.map(e=><option key={e.id} value={e.id}>{shortDay(e.day)} · {e.data.first} / {e.data.second}</option>)}</select></Field>}
    <p>{shortDay(study.day)} – {study.data.end&&study.data.end<=day?shortDay(study.data.end):"ongoing"} · Afternoon hunger from 1 (not hungry) to 5 (very hungry)</p>
    <div className="week-facts">{hungerSummary(rows,study,day).map(v=><div key={v.choice}><small>{v.name}</small><b>{v.mean==null?"—":rounded(v.mean)+" / 5"}</b><small>{v.count} {v.count===1?"rating":"ratings"}</small></div>)}</div>
    <p className="note">These averages describe the days you rated. Meal timing, sleep and activity can also affect how you feel.</p>
    <div className="k-actions">{(!study.data.end||day<=study.data.end)&&<button className="light" onClick={()=>rate(study)}>{ratingFor(rows,study,day)?"Edit hunger rating":"Rate afternoon hunger"}</button>}
    {!study.data.end&&day===dateKey()&&<button className="text-btn" disabled={busy} onClick={async()=>{if(!confirm){ask(true);return}if(await save({...study,data:{...study.data,end:day}},"Experiment finished",study.revision))ask(false)}}>{confirm?"Confirm finish":"Finish experiment"}</button>}</div></>}
  </section>;
}
export function StudyForm({rows,day,busy,save,close}:{rows:Stored[],day:string,busy:boolean,save:Save,close:()=>void}){
  const [id]=useState(()=>crypto.randomUUID()),[first,setFirst]=useState(""),[second,setSecond]=useState("");
  const recent=[...new Set(foodEntries(rows).filter(r=>r.data.meal==="Breakfast"&&r.day<=day).sort((a,b)=>b.day.localeCompare(a.day)).map(r=>r.data.food.name))].slice(0,15);
  const valid=first.trim()&&second.trim()&&first.trim().toLowerCase()!==second.trim().toLowerCase();
  return <Modal title="Try two breakfasts" close={close} description="Pick two breakfasts you would happily repeat. On days you have one, rate your hunger at the same time in the afternoon.">
    <form onSubmit={e=>{e.preventDefault();if(valid)void save({id,kind:"experiment",day,data:{first:first.trim(),second:second.trim()}},"Breakfast experiment started",0)}}>
    <Field label="First breakfast"><input required list="usual-breakfasts" maxLength={100} placeholder="e.g. Kanda pohe" value={first} onChange={e=>setFirst(e.target.value)}/></Field>
    <Field label="Second breakfast"><input required list="usual-breakfasts" maxLength={100} placeholder="e.g. Besan tomato omelette and curd" value={second} onChange={e=>setSecond(e.target.value)}/></Field>
    <datalist id="usual-breakfasts">{recent.map(name=><option key={name} value={name}/>)}</datalist>
    <button className="primary full" disabled={busy||!valid}>Start experiment</button></form></Modal>;
}
export function HungerForm({rows,day,study,busy,save,close,remove}:{rows:Stored[],day:string,study:Experiment,busy:boolean,save:Save,close:()=>void,remove:(r:Stored)=>Promise<boolean>}){
  const [previous]=useState(()=>ratingFor(rows,study,day));
  const [choice,pick]=useState<"first"|"second"|undefined>(previous?.data.choice),[rating,setRating]=useState(previous?.data.rating),[confirm,ask]=useState(false);
  return <Modal title="Afternoon hunger" description={shortDay(day)+" · Choose the breakfast you had and how hungry you felt."} close={close}>
    <fieldset className="study-field"><legend>Which breakfast did you eat?</legend>{(["first","second"] as const).map(c=><label key={c}><input type="radio" name="breakfast-choice" checked={choice===c} onChange={()=>pick(c)}/>{study.data[c]}</label>)}</fieldset>
    <fieldset className="study-field"><legend>How hungry were you?</legend><div className="hunger-scale">{[1,2,3,4,5].map(n=><button type="button" className="light" key={n} aria-pressed={rating===n} onClick={()=>setRating(n)}>{n}</button>)}</div><div className="scale-labels"><small>Not hungry</small><small>Very hungry</small></div></fieldset>
    <button className="primary full" disabled={busy||!choice||!rating} onClick={()=>{if(choice&&rating)void save({kind:"hunger",id:"h-"+study.id+"-"+day,day,data:{experiment:study.id,choice,rating}},"Hunger rating saved",previous?.revision??0)}}>Save rating</button>
    {previous&&<button className="text-btn" disabled={busy} onClick={()=>confirm?void remove(previous):ask(true)}>{confirm?"Confirm removal":"Remove rating"}</button>}
  </Modal>;
}
