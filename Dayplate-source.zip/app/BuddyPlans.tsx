"use client";
import {useEffect,useState} from "react";
import {Check,Heart,CalendarDays} from "lucide-react";
import {deviceZone,plusDays,reminderDue,sharingOptions,type Goal,type BuddyView,type SharedMeal} from "./buddy";
import {dateKey,meals,format,type Entry,type Stored} from "./model";
import {MovementPicker} from "./MovementPicker";
import {recipePortion} from "./kitchen";
import {Field,Modal} from "./ui";
import {pagesRequest} from "./pages-api";

type Save=(entry:Entry,message:string,revision?:number)=>Promise<boolean>;
type Actions={act:(body:object,message:string)=>Promise<boolean>;busy:boolean};
const foodExample="Meet my breakfast protein goal";
const defaultMovement={activity:"Walking · Moderate pace",minutes:10};
const dayName=(d:string)=>new Date(d+"T12:00:00Z").toLocaleDateString(undefined,{month:"short",day:"numeric",timeZone:"UTC"});
const initial=(habit=foodExample,target=3):Goal=>({goal:habit,target,sharing:"completion",reminder:"",zone:deviceZone()});
function Privacy({value,change}:{value:Pick<Goal,"sharing"|"reminder">;change:(v:Pick<Goal,"sharing"|"reminder">)=>void}){
  return <><Field label="What your friend can see"><select value={value.sharing} onChange={e=>change({...value,sharing:e.target.value as Goal["sharing"]})}>{Object.entries(sharingOptions).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select></Field>
    <small>{value.sharing==="completion"?"Your friend sees your habit, target, and whether you reached it.":value.sharing==="progress"?"Your friend also sees the number of days you checked in.":"Your friend sees your count and each entry you explicitly attach. They can save a copy of a shared meal."}</small>
    <Field label="In-app reminder (optional)"><input type="time" value={value.reminder} onChange={e=>change({...value,reminder:e.target.value})}/></Field>
    {value.reminder&&<button type="button" className="text-btn" onClick={()=>change({...value,reminder:""})}>Turn reminder off</button>}</>;
}
function GoalForm({peer,invite,send,busy,close}:{peer:string;invite?:BuddyView;send:(g:Goal)=>Promise<boolean>;busy:boolean;close:()=>void}){
 const [g,set]=useState(()=>initial(invite?.other?.movement?foodExample:invite?.other?.goal,invite?.other?.target));
 const [kind,choose]=useState<"movement"|"food">(invite?.other&&!invite.other.movement?"food":"movement");
 const [movement,setMovement]=useState(invite?.other?.movement??defaultMovement);
 return <Modal title={invite?"Join @"+peer+"’s week":"Plan a week with @"+peer} close={close}>
  <form className="buddy-form" onSubmit={async e=>{e.preventDefault();if(await send(kind==="movement"?{...g,goal:movement.activity+" · "+movement.minutes+" min",movement}:g))close()}}>
    {invite?.other&&<div className="buddy-habit"><b>@{peer}’s plan</b><p>{invite.other.goal} · {invite.other.target} days</p><small>They share {sharingOptions[invite.other.sharing].toLowerCase()}.</small></div>}
    <Field label="Type of goal"><select value={kind} onChange={e=>choose(e.target.value as typeof kind)}><option value="movement">Movement</option><option value="food">Food habit</option></select></Field>
    {kind==="movement"?<MovementPicker activity={movement.activity} minutes={movement.minutes} changeActivity={activity=>setMovement({...movement,activity})} changeMinutes={minutes=>setMovement({...movement,minutes})}/>:<Field label="Your food habit"><input required maxLength={100} value={g.goal} onChange={e=>set({...g,goal:e.target.value})}/></Field>}
    <Field label="Days to aim for this week"><select value={g.target} onChange={e=>set({...g,target:Number(e.target.value)})}>{[1,2,3,4,5,6,7].map(n=><option key={n} value={n}>{n} of 7 days</option>)}</select></Field>
    <Privacy value={g} change={v=>set({...g,...v})}/><p className="note">Your seven days start the morning after acceptance in {g.zone.replaceAll("_"," ")}. Reminders appear while Dayplate is open.</p>
    <button className="primary full" disabled={busy||(kind==="food"?!g.goal.trim():!movement.activity||!movement.minutes)}>{invite?"Accept and start tomorrow":"Send private invitation"}</button>
  </form></Modal>;
}
function mealData(item:SharedMeal,peer:string){
 return {name:item.name+" from @"+peer,unit:"meal",yieldCount:1,lines:item.lines.map(l=>({...l,id:crypto.randomUUID()}))};
}
function MealCopy({item,peer,rows,save}:{item:SharedMeal;peer:string;rows:Stored[];save:Save}){
 const id="buddy-"+item.id,saved=rows.some(r=>r.id===id);
 const [saving,setSaving]=useState(false);
 const data=mealData(item,peer),portion=recipePortion(data);
 return <div className="buddy-habit"><b>{item.name} from @{peer}</b>
 {item.lines.map((l,i)=><small key={i}>{l.quantity} × {l.food.serving} · {l.food.name}</small>)}
 {portion&&<small>{format(portion.kcal)} kcal{portion.p!=null?" · "+format(portion.p)+" g protein":""}{portion.c!=null?" · "+format(portion.c)+" g carbs":""}{portion.f!=null?" · "+format(portion.f)+" g fat":""}</small>}
 <button className="light" disabled={saved||saving} onClick={async()=>{setSaving(true);try{await save({id,day:dateKey(),kind:"recipe",data},"Meal saved to My kitchen",0)}finally{setSaving(false)}}}>{saved?"Saved to My kitchen":"Save meal to My kitchen"}</button></div>;
}
function Plan({p,rows,save,act,busy}:{p:BuddyView;rows:Stored[];save:Save}&Actions){
 const [dialog,show]=useState<""|"join"|"settings"|"move"|"end">(""),[pick,setPick]=useState(""),[move,setMove]=useState("");
 const m=p.mine,o=p.other,peer="@"+p.peer, count=Object.keys(m?.checks??{}).length;
 const end=m?.start?plusDays(m.start,6):"",live=!!(p.active&&m&&p.today>=m.start&&p.today<=end),checked=!!m&&p.today in m.checks;
 const log=rows.filter(r=>r.day===p.today);
 const options=[...meals.flatMap(meal=>{const lines=log.filter(r=>r.kind==="food"&&r.data.meal===meal);return lines.length>0&&lines.length<=40?[{key:meal,label:meal+" · "+lines.map(r=>r.kind==="food"?r.data.quantity+" × "+r.data.food.serving+" "+r.data.food.name:"").join(", "),pick:{kind:"meal",day:p.today,meal}}]:[]}),
 ...log.flatMap(r=>r.kind==="exercise"?[{key:r.id,label:r.data.name+" · "+r.data.minutes+" min",pick:{kind:"workout",id:r.id}}]:[])];
 const action=(action:string,message:string,extra:object={})=>act({action,id:p.id,...extra},message);
 const [pref,setPref]=useState({sharing:m?.sharing??"completion",reminder:m?.reminder??""});
 return <article className="buddy-plan"><header><small>{!p.active?(p.incoming?"Invitation from ":"Invitation sent to "):"Your week with "}{peer}</small>
 <h3>{m?.goal||o?.goal}</h3></header>
 {!p.active?<><p>{m?.target??o?.target} days out of seven · {sharingOptions[(m??o)!.sharing]}</p>{p.incoming&&<button className="primary" disabled={busy} onClick={()=>show("join")}>Choose my goal and join</button>}</>:m&&<>
 <p>{dayName(m.start)} – {dayName(end)} · {p.today<m.start?"Starts tomorrow":p.today>end?"Week finished":count>=m.target?"Goal reached":"In progress"}</p>
 <div className="stamp-track" aria-label={count+" of "+m.target+" days checked in"}>{Array.from({length:m.target},(_,i)=><span className={i<count?"ink":""} key={i}>{i<count?<Check size={16}/>:i+1}</span>)}</div>
 <b>{count} of {m.target} days checked in</b>
 {o&&<p className="buddy-habit"><b>{peer}</b> {o.goal}<small>{o.count!=null?o.count+" of "+o.target+" days":o.complete?"Goal reached":"Shares goal completion only"}</small></p>}
 {reminderDue(p)&&<p role="status">Time for the habit you planned today.</p>}
 {live&&!checked&&count<m.target&&<>{m.sharing==="selected"&&<Field label={"Attach to this check-in for "+peer}><select value={pick} onChange={e=>setPick(e.target.value)}><option value="">Check-in only</option>{options.map(v=><option key={v.key} value={v.key}>{v.label}</option>)}</select></Field>}
 {pick&&m.sharing==="selected"&&<p className="note">{options.find(v=>v.key===pick)?.label}. Your friend receives the selected meal’s portions and nutrients or the workout’s name and duration.</p>}
 <button className="primary" disabled={busy} onClick={async()=>{if(await action("buddyCheck","Checked in for today.",{day:p.today,pick:m.sharing==="selected"?options.find(v=>v.key===pick)?.pick:undefined}))setPick("")}}><Check size={16}/>Check in for today</button>
 {p.today<end&&<button className="light" disabled={busy} onClick={()=>{setMove(m.next>p.today?m.next:plusDays(p.today,1));show("move")}}>Plan a later day</button>}
 {m.next>p.today&&<small>Next planned check-in · {dayName(m.next)}</small>}</>}
 {live&&checked&&<button className="light" disabled={busy} onClick={()=>void action("buddyUndo","Today’s check-in removed.",{day:p.today})}>Undo today’s check-in</button>}
 {o?.items.map((item,i)=>item.kind==="meal"?<MealCopy key={item.id} item={item} rows={rows} peer={p.peer} save={save}/>:<p key={i}>{peer} shared {item.name} · {item.minutes} min</p>)}
 <details className="buddy-more"><summary>Support and sharing</summary>{o?.ask&&<p>{peer} would like some encouragement.</p>}{o?.cheer&&<p><Heart size={15}/> {peer} is cheering you on.</p>}
 <button className="light" aria-pressed={m.cheer} disabled={busy} onClick={()=>void action("buddyCheer",m.cheer?"Cheer removed.":"Cheer sent.",{on:!m.cheer})}>{m.cheer?"Remove my cheer":"Cheer "+peer}</button>
 <button className="light" aria-pressed={m.ask} disabled={busy} onClick={()=>void action("buddyAsk","Support preference updated.",{on:!m.ask})}>{m.ask?"Cancel encouragement request":"Ask for encouragement"}</button>
 <button className="light" disabled={busy} onClick={()=>{setPref({sharing:m.sharing,reminder:m.reminder});show("settings")}}>Edit sharing and reminder</button></details></>}
 <button className="text-btn" disabled={busy} onClick={()=>show("end")}>{p.active?"End challenge":p.incoming?"Decline invitation":"Cancel invitation"}</button>
 {dialog==="join"&&<GoalForm peer={p.peer} invite={p} busy={busy} close={()=>show("")} send={settings=>action("buddyJoin","Your week starts tomorrow.",{settings})}/>}
 {dialog==="move"&&<Modal title="Choose your next check-in" close={()=>show("")}><form onSubmit={async e=>{e.preventDefault();if(await action("buddyMove","Next day updated.",{day:move}))show("")}}><Field label="Next planned day"><input required type="date" min={plusDays(p.today,1)} max={end} value={move} onChange={e=>setMove(e.target.value)}/></Field><button className="primary" disabled={busy}>Save date</button></form></Modal>}
 {dialog==="settings"&&<Modal title="Sharing and reminder" close={()=>show("")}><Privacy value={pref} change={setPref}/><p>Changing to a more private setting removes attached entries from this challenge. Copies already saved to a friend’s kitchen stay there.</p><button className="primary" disabled={busy} onClick={async()=>{if(await action("buddySettings","Settings saved.",pref))show("")}}>Save settings</button></Modal>}
 {dialog==="end"&&<Modal title="Remove this challenge?" close={()=>show("")}><p>This removes the invitation or shared week for both of you. Your personal diary entries stay in your journals.</p><button className="light" onClick={()=>show("")}>Keep it</button> <button className="danger" disabled={busy} onClick={()=>void action("buddyEnd","Challenge removed.")}>Remove challenge</button></Modal>}
 </article>;
}
export function BuddyPlans({plans,people,peer,choose,composer,compose,rows,save,...actions}:{plans:BuddyView[];people:string[];peer:string;choose:(p:string)=>void;composer:boolean;compose:(on:boolean)=>void;rows:Stored[];save:Save}&Actions){
 const [editing,setEditing]=useState(false);
 const selected=people.includes(peer)?peer:people[0];
 return <section className="panel buddy-box" id="buddy-plans"><header><CalendarDays size={20}/><h2>Buddy week</h2></header><p>Choose a habit each and check in on your own schedule for seven days.</p>
 {people.length>0?<button className="primary" onClick={()=>compose(true)}>Start a challenge with a friend</button>:<p className="note">Add a friend by username to plan your first week together.</p>}
 {composer&&selected&&<Modal title="Choose a friend" close={()=>compose(false)}><Field label="Friend"><select value={selected} onChange={e=>choose(e.target.value)}>{people.map(v=><option value={v} key={v}>@{v}</option>)}</select></Field><button className="primary" onClick={()=>{compose(false);setEditing(true)}}>Choose my habit</button></Modal>}
 {editing&&selected&&<GoalForm peer={selected} close={()=>setEditing(false)} busy={actions.busy} send={settings=>actions.act({action:"buddyInvite",id:crypto.randomUUID(),peer:selected,settings},"Private invitation sent.")}/>}
 {plans.map(p=><Plan key={p.id} p={p} rows={rows} save={save} {...actions}/>)}</section>;
}
export function BuddyReminder({open}:{open:()=>void}){
 const [goals,set]=useState<string[]>([]);
 useEffect(()=>{let live=true,seq=0;async function refresh(){if(document.visibilityState!=="visible")return;const ticket=++seq;try{const r=await pagesRequest("/api/friends?reminders=1",{cache:"no-store"});if(r.ok){const data=await r.json();if(live&&ticket===seq&&Array.isArray(data))set(data)}}catch{}}
 void refresh();const timer=setInterval(refresh,60000);document.addEventListener("visibilitychange",refresh);return()=>{live=false;clearInterval(timer);document.removeEventListener("visibilitychange",refresh)}},[]);
 return goals.length?<aside className="buddy-reminder"><span><b>Buddy week reminder</b><small>{goals.join(" · ")}</small></span><button className="light" onClick={open}>Open Friends</button></aside>:null;
}
