"use client";
import {useState} from "react";
import {MessageCircle,RotateCw} from "lucide-react";
import {scripts,replies,type Call} from "./cafe-cast";
const theme=(host:string)=>host==="Tara Tiffin"?"tara":"baron";
export function CrewAside({call,seed=""}:{call:Call,seed?:string}){
  const {host,lines}=scripts[call];
  const i=Array.from(seed).reduce((sum,c)=>sum+c.codePointAt(0)!,0)%lines.length;
  return <aside className={"crew-aside "+theme(host)}><span className="cast-portrait" aria-hidden="true"/><div><b>{host}</b><p>{lines[i]}</p></div></aside>;
}
export function CafeCounter({call,quiet,toggle,busy,missed,report}:{call:Call,quiet:boolean,toggle:()=>void,busy:boolean,missed:boolean,report:(state:"missed"|"back")=>void}){
  const [take,next]=useState(0),[rebuttal,reply]=useState(false);
  if(quiet)return <div className="cafe-muted"><button className="text-btn" onClick={toggle}><MessageCircle size={15}/>Show café characters</button></div>;
  const {host,lines}=scripts[call],other=host==="Tara Tiffin"?"Baron Crumb":"Tara Tiffin",speaker=rebuttal?other:host;
  return <section className={"cafe-counter "+theme(speaker)} aria-label="Dayplate café"><div role="img" className="counter-art" aria-label="Baron Crumb and Tara Tiffin at their Mumbai café counter"/>
    <div className="counter-copy"><div className="counter-head"><span>Dayplate Café</span><button className="text-btn" onClick={toggle}>Quiet mode</button></div>
    <div className="counter-line" aria-live="polite" aria-atomic="true"><h2>{speaker}</h2><p key={speaker+take}>{rebuttal?replies[call]:lines[take%lines.length]}</p></div>
    <div className="counter-buttons"><button className="light" onClick={()=>reply(!rebuttal)}>Ask {rebuttal?host:other}</button><button className="text-btn" onClick={()=>{reply(false);next(take+1)}}><RotateCw size={14}/>Another line</button>
    <button className="text-btn" disabled={busy} onClick={()=>{reply(false);next(0);report(missed?"back":"missed")}}>{missed?"I’m back":"I missed my routine"}</button></div></div>
  </section>;
}
