"use client";
import {shareJSON} from "./share-file";
import {useMemo,useState} from "react";
import {catalog} from "./catalog";
import foodReview from "./data/food-review.json";
import restaurantReview from "./data/restaurant-review.json";
import usReview from "./data/us-review.json";
import audit from "./data/panel-audit.json";
import {nutrients, scaled, compactNumber,unitOf,amountOf} from "./nutrition";
import {Download,ClipboardList} from "lucide-react";
type Finding={state:string,note:string,url:string};
const reviewed:Record<string,Finding>=audit;
export function auditRows(){
 const rows=catalog.map(f=>{
   const actual=reviewed[f.name]||foodReview[f.name as keyof typeof foodReview],p=f.panel;
   return {name:f.name,group:f.group,status:actual?.state||((p?.kind==="Café menu"||p?.kind==="Restaurant menu")?"Menu checked":p?.kind==="Recipe estimate"?"Recipe recalculated":p?.kind==="Published pack image"?"Pack image checked":p?.kind==="Product listing"?"Product listing checked":p?"Reference scaled":"Serving estimate"),
     serving:f.serving,size:amountOf(f),unit:unitOf(f),kcal:f.kcal,protein:f.p,potassium:scaled(f,"potassium")?.value??null,
     basis:p?p.amount+" "+p.unit:"1 stated serving",source:p?.source||f.source||"",note:[actual?.note,p?.detail].filter(Boolean).join(" "),links:p?.links||[],
     values:p?.values||{kcal:f.kcal,p:f.p,c:f.c,f:f.f},bounds:p?.bounds||{}};
 });
 const excluded=Object.entries({...reviewed,...restaurantReview,...usReview}).filter(([,f])=>f.state==="Excluded");
 return {rows,excluded};
}
export function exportAudit(){const {rows,excluded}=auditRows();return {title:"Dayplate food audit",date:"2026-11-27",units:Object.fromEntries(Object.entries(nutrients).map(([k,v])=>[k,v[1]])),coverage:"In records with a nutrition panel, values and bounds are on the stated source basis. kcal, protein and potassium columns are per logging serving. Missing potassium is null. Linked sources and the catalog's recipe assumptions identify what each value represents.",rows,excluded:excluded.map(([name,r])=>({name,...r}))}}
export default function CatalogAudit({initialOpen=false}:{initialOpen?:boolean}){
 const [open,setOpen]=useState(initialOpen),[term,search]=useState(""),[exportError,setExportError]=useState("");
 const [limit,setLimit]=useState(48);
 const {rows,excluded}=useMemo(()=>open?auditRows():{rows:[],excluded:[]},[open]);
 const matches=useMemo(()=>rows.filter(r=>r.name.toLowerCase().includes(term.toLowerCase())),[rows,term]);
 function download(){setExportError("");void shareJSON(JSON.stringify(exportAudit(),null,2),"Dayplate-food-audit.json","audit").catch(()=>setExportError("Could not export the audit. Please try again."));}
 return <section className="panel audit"><div className="section-head"><div className="title-line"><ClipboardList size={19}/><h2>Food data audit</h2></div><button className="light" onClick={()=>setOpen(!open)}>{open?"Close audit":"View audit"}</button></div>
 {open?<><p className="note">{rows.length} available foods · {rows.filter(x=>x.status==="Product listing checked"||x.status==="Pack image checked"||(reviewed[x.name]&&reviewed[x.name].state!=="Excluded")).length} packaged products reviewed · {excluded.length} review exclusions listed. Open a record for its portion, source and review findings.</p><div className="audit-tools"><input placeholder="Find an audit record" aria-label="Find an audit record" value={term} onChange={e=>{search(e.target.value);setLimit(48)}}/><button className="light" onClick={download}><Download size={15}/>Export full audit</button></div>{exportError&&<p role="alert">{exportError}</p>}<div className="audit-list">{excluded.filter(([n])=>n.toLowerCase().includes(term.toLowerCase())).map(([name,item])=><details key={name}><summary>{name} <small>Excluded</small></summary><p>{item.note}</p><a href={item.url} target="_blank" rel="noreferrer">Conflicting listing</a></details>)}{matches.slice(0,limit).map(r=><details key={r.name}><summary>{r.name} <small>{r.status}</small></summary><p>{r.serving} · {compactNumber(r.kcal)} kcal · potassium {r.potassium===null?"unknown":compactNumber(r.potassium)+" mg"}</p><p>{r.note}</p>{r.source&&<a href={r.source} target="_blank" rel="noreferrer">Source</a>}</details>)}</div>{limit<matches.length&&<button type="button" className="light" onClick={()=>setLimit(n=>n+48)}>Show more records</button>}</>:<small>See the evidence, corrections and limitations for each built-in food.</small>}</section>
}
