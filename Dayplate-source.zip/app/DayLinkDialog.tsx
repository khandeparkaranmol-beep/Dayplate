"use client";
import {useEffect,useRef,useState} from "react";
import {Copy,Link2,MessageCircle} from "lucide-react";
import {pagesRequest} from "./pages-api";
import {Modal} from "./ui";
import type {Stored} from "./model";
import {daySnapshot,dayText,snapshotDate,whatsappURL,type SnapshotState,type SnapshotLinkInfo,type DayLinkMode} from "./day-snapshot";
import {SnapshotContents} from "./SnapshotContents";
import {fullVisibility,hasSharedContent,type SnapshotVisibility} from "./snapshot-visibility";
import {DaySnapshotCard} from "./DaySnapshotCard";
import {journalURL} from "../lib/pages-origin";
import {randomToken} from "../lib/google-token";

async function ownerRequest<T>(body:object,signal?:AbortSignal):Promise<T>{
  const res=await pagesRequest("/api/day-links",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),signal});
  const data=await res.json() as {error?:string};
  if(!res.ok)throw Object.assign(new Error(data.error??"Could not open your snapshot. Try again."),{status:res.status});
  return data as T;
}
const stamp=(value:number)=>new Date(value).toLocaleString(undefined,{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});

export function DayLinkDialog({day,rows,online,close}:{day:string;rows:Stored[];online:boolean;close:()=>void}){
  const [state,setState]=useState<SnapshotState|null>(null),[reload,refresh]=useState(0);
  const [visibility,setVisibility]=useState(fullVisibility);
  const [mode,setMode]=useState<DayLinkMode>("live");
  const [result,setResult]=useState<(SnapshotLinkInfo&{url:string})|null>(null);
  const [message,say]=useState(""),[error,fail]=useState(""),[busy,setBusy]=useState(false),[manual,showManual]=useState(false);
  const lock=useRef(false),attempt=useRef<{mode:DayLinkMode;fingerprint:string|null;token:string}|null>(null);
  useEffect(()=>{
    if(!online)return;
    const req=new AbortController();
    ownerRequest<SnapshotState>({action:"preview",day,visibility},req.signal).then(s=>{
      if(!req.signal.aborted)setState(s);
    }).catch(e=>{if(!req.signal.aborted)fail(e.message)});
    return ()=>req.abort();
  },[day,online,reload,visibility]);
  const snapshot=online?state?.snapshot:daySnapshot(rows,day,visibility);
  function changeVisibility(next:SnapshotVisibility){
    setVisibility(next);setState(null);attempt.current=null;fail("");say("");showManual(false);
  }
  async function createLink(){
    if(lock.current||!state||(!state.snapshot&&mode==="snapshot"))return;
    lock.current=true;setBusy(true);fail("");say("");
    try{
      if(attempt.current?.mode!==mode||attempt.current.fingerprint!==state.fingerprint)attempt.current={mode,fingerprint:state.fingerprint,token:randomToken()};
      const {token,fingerprint}=attempt.current;
      const info=await ownerRequest<SnapshotLinkInfo>({action:"create",day,mode,token,fingerprint,visibility});
      setResult({...info,url:journalURL+"share.html#"+token});
      setState({...state,links:[info,...state.links.filter(l=>l.id!==info.id)]});
    }catch(e){
      const problem=e as Error&{status?:number};fail(problem.message);
      if(problem.status===409){attempt.current=null;setState(null);refresh(n=>n+1)}
    }finally{lock.current=false;setBusy(false)}
  }
  async function stop(id:string){
    if(lock.current)return;
    lock.current=true;setBusy(true);fail("");say("");
    try{
      await ownerRequest({action:"stop",id});setState(s=>s&&({...s,links:s.links.filter(l=>l.id!==id)}));
      if(result?.id===id){setResult(null);attempt.current=null;showManual(false);refresh(n=>n+1)}
      say("Link turned off.");
    }catch(e){fail((e as Error).message)}finally{lock.current=false;setBusy(false)}
  }
  async function copy(text:string){
    try{await navigator.clipboard.writeText(text);say(result?"Link copied.":"Summary copied.")}
    catch{showManual(true)}
  }
  const dateLabel=snapshotDate(day);
  const canCreate=hasSharedContent(visibility)&&!!state&&(mode==="live"||!!state.snapshot);
  const text=result?.url??(!online&&snapshot?dayText(snapshot):"");
  return <Modal title={result?"Your day link is ready":"Share my day"} close={()=>{if(!lock.current)close()}}>
    <div className="snapshot-dialog">
      {online&&!result&&<fieldset className="day-link-modes"><legend>What should the link show?</legend>
        <label><input type="radio" name="link-mode" checked={mode==="live"} disabled={busy} onChange={()=>setMode("live")}/><span><b>Live day link</b><small>Updates as you log this date.</small></span></label>
        <label><input type="radio" name="link-mode" checked={mode==="snapshot"} disabled={busy} onChange={()=>setMode("snapshot")}/><span><b>Fixed snapshot</b><small>Keeps the entries shown in this preview.</small></span></label>
      </fieldset>}
      {result&&<><p>{result.mode==="live"?"This link follows your log for "+dateLabel+".":"This link keeps your snapshot for "+dateLabel+"."} Anyone with the link can open it until {stamp(result.expires)}.</p>
        <div className="snapshot-actions"><a className="primary" href={whatsappURL((result.mode==="live"?"My live day on Dayplate: ":"My Dayplate snapshot: ")+result.url)} target="_blank" rel="noopener noreferrer"><MessageCircle size={17}/>Open WhatsApp</a><button className="light" onClick={()=>void copy(text)}><Copy size={16}/>Copy link</button></div></>}
      {!result&&<SnapshotContents day={day} rows={rows} value={visibility} onChange={changeVisibility} disabled={busy} live={online&&mode==="live"}/>}
      {online&&!state&&!error&&<p role="status">Opening your logged day…</p>}
      {!result&&online&&state&&<p>Anyone with the link can view {mode==="live"?"your selected entries":"this snapshot"} for {dateLabel}. The link expires in seven days.</p>}
      {!online&&snapshot&&<p>Preview the summary you can send as a WhatsApp message from your offline diary.</p>}
      {snapshot&&<div className="log-share-preview"><h4>What they’ll see</h4><DaySnapshotCard snapshot={snapshot}/></div>}
      {!snapshot&&(state||!online)&&<p className="note">{online&&mode==="live"?"Nothing to show yet. A live link will display matching entries as you log them.":"Choose a logged entry or a number to share."}</p>}
      {!result&&online&&state&&<button className="primary full" disabled={busy||!canCreate} onClick={()=>void createLink()}><Link2 size={17}/>{busy?"Working…":mode==="live"?"Create live day link":"Create snapshot link"}</button>}
      {!online&&snapshot&&<div className="snapshot-actions"><a className="primary" target="_blank" rel="noopener noreferrer" href={whatsappURL(text)}><MessageCircle size={17}/>Open WhatsApp</a><button className="light" onClick={()=>void copy(text)}>Copy summary</button></div>}
      {manual&&<label className="field">Select and copy<textarea readOnly value={text} onFocus={e=>e.target.select()}/></label>}
      {message&&<p role="status">{message}</p>}
      {error&&<div role="alert" className="error">{error}{online&&!state&&<button onClick={()=>{fail("");refresh(n=>n+1)}}>Retry</button>}</div>}
      {!!state?.links.length&&<details className="snapshot-links"><summary>Active links for this day ({state.links.length})</summary>
        <p>Each link keeps its own sharing settings. Turn off an earlier link to withdraw access.</p>
        {state.links.map(l=><div key={l.id}><span><b>{l.mode==="live"?"Live day link":"Fixed snapshot"}</b><small>Created {stamp(l.created)}</small><small>Expires {stamp(l.expires)}</small></span><button className="light" disabled={busy} onClick={()=>void stop(l.id)}>Turn off link</button></div>)}
      </details>}
    </div>
  </Modal>;
}
