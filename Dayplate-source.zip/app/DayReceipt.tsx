import {Check} from "lucide-react";
import {type Meal,type Stored,meals,format,totals} from "./model";
import {mealNutrientFact,nutrientName} from "./MealNutrients";
export function DayReceipt({foods,keys,open}:{foods:Extract<Stored,{kind:"food"}>[];keys:string[];open:(meal:Meal)=>void}){
 const logged=meals.filter(m=>foods.some(r=>r.data.meal===m));
 return <section className="day-receipt" aria-label="Completed day receipt"><header><span><Check size={16}/> Day complete</span><b>Your day on a plate</b></header>
 <div className="receipt-lines">{logged.map(m=><button key={m} onClick={()=>open(m)}><span>{m}</span><b>{format(totals(foods.filter(r=>r.data.meal===m)).kcal)} kcal</b></button>)}</div>
 <div className="receipt-total"><b>Day total</b><b>{format(totals(foods).kcal)} kcal</b></div>
 {keys.slice(0,3).map(key=>{const fact=mealNutrientFact(foods,key);return <small key={key}>{nutrientName(key)} · {fact.value} {fact.coverage}</small>})}</section>;
}
