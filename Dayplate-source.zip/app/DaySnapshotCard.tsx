import type {LoggedUpdate} from "./logged-update";
import {snapshotDate} from "./day-snapshot";

export function DaySnapshotCard({snapshot}:{snapshot:LoggedUpdate}){
  return <article className="snapshot-card" aria-label="Day snapshot preview">
    <header><span className="snapshot-mark" aria-hidden="true">◷</span><div><small>Dayplate</small><h3>{snapshotDate(snapshot.day)}</h3></div></header>
    <dl className="snapshot-stats">{snapshot.stats.map(s=><div key={s.label}><dt>{s.label}</dt><dd>{s.value}</dd></div>)}</dl>
    {snapshot.groups?.map(g=><section key={g.title}><div className="snapshot-group"><h4>{g.title}</h4>{g.total&&<small>{g.total}</small>}</div>
    <ul>{g.lines.map((l,index)=><li key={index}><span>{l.name}</span><small>{l.detail}</small></li>)}</ul></section>)}
  </article>;
}
