"use client";
import {groups} from "./catalog";
import {restaurantBrands} from "./restaurant-menu";

export function FoodFilters({value,onChange,library=false}:{value:string;onChange:(group:string)=>void;library?:boolean}) {
  const browsingRestaurants=value==="Indian fast food"||restaurantBrands.includes(value);
  const active=browsingRestaurants?"Indian fast food":value;
  return <>
    <div className={"category-pills"+(library?" library-pills":"")} aria-label="Food categories">
      {(library?[...groups,"My foods"]:groups).map(group=><button type="button" key={group}
        aria-pressed={active===group} className={active===group?"active":""} onClick={()=>onChange(group)}>
        {group}
      </button>)}
    </div>
    {browsingRestaurants&&<label className="restaurant-filter">Restaurant
      <select value={value} onChange={event=>onChange(event.target.value)}>
        <option value="Indian fast food">All restaurants</option>
        {restaurantBrands.map(brand=><option key={brand}>{brand}</option>)}
      </select>
    </label>}
  </>;
}
