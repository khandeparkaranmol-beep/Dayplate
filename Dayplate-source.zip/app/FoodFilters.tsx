"use client";
import {usBrands,usBrandFilter} from "./world-foods";
import {groups} from "./catalog";
import {restaurantBrands} from "./restaurant-menu";

export function FoodFilters({value,onChange,library=false}:{value:string;onChange:(group:string)=>void;library?:boolean}) {
  const [selection,source=""]=value.split(" | ");
  const browsingRestaurants=value==="Indian fast food"||restaurantBrands.includes(value);
  const usGroup=Object.keys(usBrands).find(group=>selection===group||selection.startsWith(group+" / "));
  const active=usGroup??(browsingRestaurants?"Indian fast food":value);
  return <details className="food-filter-fold"><summary>Filter foods <small>{value==="All"?"All categories":value}</small></summary>
    <div className={"category-pills"+(library?" library-pills":"")} aria-label="Food categories">
      {(library?[...groups,"My foods"]:groups).map(group=><button type="button" key={group}
        aria-pressed={active===group} className={active===group?"active":""} onClick={()=>onChange(group)}>
        {group}
      </button>)}
    </div>
    {usGroup&&<div className="us-menu-filters"><label className="restaurant-filter">US chain
      <select value={selection} onChange={event=>onChange(event.target.value+(source?" | "+source:""))}>
        <option value={usGroup}>All chains</option>
        {usBrands[usGroup].map(brand=><option key={brand} value={usBrandFilter(usGroup,brand)}>{brand}</option>)}
      </select>
    </label>
      <label className="restaurant-filter">Menu source
        <select value={source} onChange={e=>onChange(selection+(e.target.value?" | "+e.target.value:""))}>
          <option value="">All sources</option><option value="guide">Newer menus</option><option value="archive">2018 archive</option>
        </select>
      </label></div>}
    {browsingRestaurants&&<label className="restaurant-filter">Restaurant
      <select value={value} onChange={event=>onChange(event.target.value)}>
        <option value="Indian fast food">All restaurants</option>
        {restaurantBrands.map(brand=><option key={brand}>{brand}</option>)}
      </select>
    </label>}
  </details>;
}
