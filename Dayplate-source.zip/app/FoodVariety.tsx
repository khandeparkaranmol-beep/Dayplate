"use client";
import {useState} from "react";
import {type Entry,type Stored,foodGroups,shift} from "./model";
import {shortDay} from "./week-story";
import {Modal} from "./ui";

type Group=typeof foodGroups[number];
type Check=Extract<Stored,{kind:"variety"}>;
export function VarietySummary({rows,day,edit}:{rows:Stored[],day:string,edit:()=>void}){
  const checks=rows.filter((r):r is Check=>r.kind==="variety"&&r.day>=shift(day,-6)&&r.day<=day);
  const present=foodGroups.filter(g=>checks.some(r=>r.data.groups.includes(g)));
  return <details className="panel variety"><summary>Food variety this week</summary>
    <p>{checks.length?checks.length+" days checked · "+present.length+" different groups recorded.":"Which food groups showed up in your meals this week? Add a check for the selected diary date."}</p>
    {present.length>0&&<ul>{present.map(g=><li key={g}><b>{g}</b> · {checks.filter(r=>r.data.groups.includes(g)).map(r=>shortDay(r.day)).join(", ")}</li>)}</ul>}
    <button className="light" onClick={edit}>Check food groups for {shortDay(day)}</button></details>;
}
export function VarietyForm({rows,day,close,busy,save}:{rows:Stored[],day:string,close:()=>void,busy:boolean,save:(r:Entry,msg:string,revision?:number)=>Promise<boolean>}){
  const [old]=useState(()=>rows.find((r):r is Check=>r.kind==="variety"&&r.day===day));
  const [groups,set]=useState<Group[]>(old?.data.groups??[]);
  return <Modal title="Which food groups did you eat?" description={shortDay(day)+" · Include ingredients in mixed dishes, such as dal, vegetables and rice in khichdi."} close={close}>
    <div className="study-field">{foodGroups.map(g=><label key={g}><input type="checkbox" checked={groups.includes(g)} onChange={e=>set(e.target.checked?[...groups,g]:groups.filter(selected=>selected!==g))}/>{g}</label>)}</div>
    <button className="primary full" disabled={busy} onClick={()=>void save({id:"variety-"+day,kind:"variety",day,data:{groups}},"Food groups saved",old?.revision??0)}>Save food groups</button></Modal>;
}
