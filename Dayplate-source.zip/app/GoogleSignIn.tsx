"use client";
import {useEffect,useRef,useState} from "react";
import {pagesRequest,startSession} from "./pages-api";
type GoogleID = {
  initialize:(options:{client_id:string,nonce:string,callback:(v:{credential:string})=>void})=>void,
  renderButton:(el:HTMLElement,opts:object)=>void
};
const sdk = () => (window as Window & {google?:{accounts:{id:GoogleID}}}).google?.accounts.id;
let loading: Promise<void> | undefined;
function loadGoogle() {
  if (sdk()) return Promise.resolve();
  if (!loading) loading = new Promise<void>((resolve,reject)=>{
    const js = document.createElement("script");
    js.src = "https://accounts.google.com/gsi/client";
    js.onload = () => resolve();
    js.onerror = () => {loading=undefined; js.remove(); reject(Error("Google could not load. Check your connection."))};
    document.head.appendChild(js);
  });
  return loading;
}
export default function GoogleSignIn({signedIn}:{signedIn:()=>void}) {
  const host = useRef<HTMLDivElement>(null);
  const [status,setStatus] = useState(""), [error,setError] = useState(false), [attempt,retry] = useState(0);
  useEffect(()=>{
    let closed=false;
    setStatus("Loading Google sign-in…");setError(false);
    const failed = (message:string) => {if (!closed) {setStatus(message);setError(true)}};
    async function prepare(){
      try {
        const res = await pagesRequest("/api/google/nonce");
        if (!res.ok) throw Error("Google sign-in is unavailable. You can still use the offline diary.");
        const {client,nonce,verifier} = await res.json() as {client:string,nonce:string,verifier:string};
        await loadGoogle();
        const api = sdk();
        if (closed || !host.current) return;
        if (!api) throw Error("Google sign-in could not load.");
        api.initialize({client_id:client,nonce,callback:async({credential})=>{
          if(closed)return;
          try {
            setStatus("Opening your diary…");
            const r=await pagesRequest("/api/google/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({credential,verifier})});
            if(!r.ok) throw Error("Your sign-in expired. Try again.");
            const {token}=await r.json() as {token:string};
            if(!closed){startSession(token);signedIn()}
          } catch(e){failed((e as Error).message)}
        }});
        host.current.replaceChildren();
        api.renderButton(host.current,{type:"standard",theme:"outline",size:"large",shape:"pill",text:"signin_with",width:Math.min(310,host.current.clientWidth||280)});
        setStatus("");
      }catch(e){failed((e as Error).message)}
    }
    void prepare();return ()=>{closed=true};
  },[attempt,signedIn]);
  return <><div ref={host}/>{status&&<p role="status">{status}</p>}{error&&<button className="light" onClick={()=>retry(v=>v+1)}>Retry Google sign-in</button>}</>;
}
