"use client";
import {useEffect,useRef,useState} from "react";
type GoogleID={initialize:(options:{client_id:string,nonce:string,callback:(v:{credential:string})=>void})=>void,renderButton:(el:HTMLElement,opts:object)=>void};
export default function GoogleSignIn(){
 const host=useRef<HTMLDivElement>(null),[status,setStatus]=useState("Loading Google sign-in…");
 useEffect(()=>{let gone=false;const sdk=()=> (window as Window&{google?:{accounts:{id:GoogleID}}}).google?.accounts.id;
 async function init(){try{
  const r=await fetch("/api/google/nonce",{cache:"no-store"});if(!r.ok)throw Error("Google sign-in is unavailable.");const {client,nonce}=await r.json() as {client:string,nonce:string};
  let api=sdk();if(!api){await new Promise<void>((resolve,reject)=>{let js=document.querySelector<HTMLScriptElement>('script[src="https://accounts.google.com/gsi/client"]');if(!js){js=document.createElement("script");js.src="https://accounts.google.com/gsi/client";js.async=true;document.head.appendChild(js)}js.addEventListener("load",()=>resolve(),{once:true});js.addEventListener("error",()=>reject(Error("Could not load Google sign-in.")),{once:true})});api=sdk()}
  if(gone||!host.current)return;if(!api)throw Error("Could not load Google sign-in.");
  api.initialize({client_id:client,nonce,callback:async({credential})=>{try{setStatus("Opening your journal…");const res=await fetch("/api/google/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({credential})});if(!res.ok)throw Error("Refresh the page and try Google sign-in again.");location.replace("/")}catch(e){setStatus((e as Error).message)}}});
  api.renderButton(host.current,{type:"standard",theme:"outline",size:"large",shape:"pill",text:"signin_with",width:Math.min(320,host.current.clientWidth||300)});setStatus("");
 }catch(e){if(!gone)setStatus((e as Error).message)}}
 void init();return()=>{gone=true}},[]);
 return <><div ref={host} aria-label="Sign in with Google"/>{status&&<p role="status">{status}</p>}</>;
}
