"use client";
import {useState,useRef} from "react";
import {Upload,Heart} from "lucide-react";
import {Modal,Field} from "./ui";
import {type HealthPreview,type SourceChoice,type Metric,metrics,parseHealth,initialSources,importRows} from "./health-import";
import {dateKey,shift,type Stored,type Entry} from "./model";
import {sendEntries,type JournalRequest} from "./activity-records";

import {burnLabel} from "./workout-energy";
const labels:Record<Metric,string>={steps:"Steps",active:"Active calories",resting:"Resting calories"};
export default function HealthImport({request,refresh,rows}:{rows:Stored[],request:JournalRequest,refresh:()=>Promise<void>}){
 const [open,setOpen]=useState(false),[data,setData]=useState<HealthPreview|null>(null),[choices,setChoices]=useState<SourceChoice>({steps:"",active:"",resting:""});
 const [from,setFrom]=useState(shift(dateKey(),-29)),[to,setTo]=useState(dateKey()),[working,busy]=useState(false),[entries,setEntries]=useState<Entry[]|null>(null),[message,say]=useState("");
 const input=useRef<HTMLInputElement>(null);
 async function read(f:File){busy(true);say("Reading on this device…");setEntries(null);setData(null);try{const d=await parseHealth(f);setData(d);setChoices(initialSources(d));say("")}catch{say("Could not read this export. Choose export.zip or the export.xml file inside it.")}finally{busy(false)}}
 const close=()=>{if(!working){setOpen(false);setEntries(null);setData(null);say("")}};
 const daily=entries?.filter(e=>e.kind==="activity").sort((a,b)=>b.day.localeCompare(a.day));
 return <section className="connect-health"><Heart size={22}/><h2>Apple Health & Fitness</h2><p>Bring steps, active and resting calories, and workouts into your journal.</p><button className="light" onClick={()=>{say("");setOpen(true)}}><Upload size={16}/>Import Apple Health</button>{!open&&message&&<p role="status">{message}</p>}
 {open&&<Modal title="Import Apple Health" close={close} description="On iPhone, open Health → your profile → Export All Health Data. Save the ZIP to Files.">
 <p className="note">Dayplate reads the file on this device. Only the activity you confirm is saved to your diary. Repeat the import to update it.</p>
 <input ref={input} type="file" hidden accept=".zip,.xml,application/zip,application/xml,text/xml" onChange={e=>{const f=e.target.files?.[0];e.target.value="";if(f)void read(f)}}/>
 <button className="light full" disabled={working} onClick={()=>input.current?.click()}>{data?"Choose a different file":"Choose Health export"}</button>
 {data&&!entries&&<><div className="fields"><Field label="From"><input type="date" value={from} max={to} onChange={e=>setFrom(e.target.value)}/></Field><Field label="Through"><input type="date" value={to} min={from} max={dateKey()} onChange={e=>setTo(e.target.value)}/></Field></div>
 {metrics.filter(m=>data.sources[m].size>1).map(m=><Field key={m} label={labels[m]+" source"}><select value={choices[m]} onChange={e=>setChoices({...choices,[m]:e.target.value})}><option value="">Skip raw {labels[m].toLowerCase()}</option>{[...data.sources[m]].sort().map(s=><option key={s}>{s}</option>)}</select></Field>)}
 <p className="note">Choose one device per metric to avoid overlapping samples. The Fitness Move summary takes priority for active calories. Step totals from one source can differ from Health’s combined total.</p>
 <button className="primary full" disabled={working||!from||!to||from>to||to>dateKey()} onClick={async()=>{busy(true);try{setEntries(await importRows(data,choices,from,to));say("")}catch{say("Could not prepare these dates. Try a smaller range.")}finally{busy(false)}}}>Preview activity</button></>}
 {entries&&<><h3>Review your import</h3><p>{daily?.length} daily summaries · {entries.filter(e=>e.kind==="exercise").length} workouts</p><div className="import-list">{daily?.slice(0,6).map(e=><p key={e.id}><b>{e.day}</b><small>{[e.data.steps!=null?Math.round(e.data.steps)+" steps":null,e.data.active!=null?Math.round(e.data.active)+" active kcal":null,e.data.resting!=null?Math.round(e.data.resting)+" resting kcal":null].filter(Boolean).join(" · ")}</small></p>)}{entries.filter(e=>e.kind==="exercise").slice(0,3).map(e=><p key={e.id}><b>{e.data.name}</b><small>{e.day} · {Math.round(e.data.minutes)} min · {burnLabel(e,rows)}</small></p>)}</div>
 <button className="text-btn" disabled={working} onClick={()=>setEntries(null)}>Change dates or sources</button>
 <button className="primary full" disabled={working||!entries.length} onClick={async()=>{busy(true);try{await sendEntries(request,"healthImport",entries);await refresh();setOpen(false);setEntries(null);setData(null);say("Activity imported. Reimporting the same export keeps one copy.")}catch(e){say((e as Error).message)}finally{busy(false)}}}>{working?"Saving…":"Save to my diary"}</button></>}
 {message&&<p role="status">{message}</p>}</Modal>}</section>
}
