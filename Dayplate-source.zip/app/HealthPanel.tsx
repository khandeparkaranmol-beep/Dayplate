"use client";
import {useState} from "react";
import {type Stored,dateKey,format} from "./model";
import {healthAt} from "./health-metrics";
import {Modal,Field} from "./ui";
import type {Commit} from "./forms";
export function MeasureForm({day,rows,save,close,busy}:{day:string,rows:Stored[],save:Commit,close:()=>void,busy:boolean}){
 const at=(d:string)=>rows.filter(r=>r.kind==="measure").find(r=>r.day===d)?.data;
 const [date,setDate]=useState(day),[height,setHeight]=useState(String(at(day)?.height??"")),[waist,setWaist]=useState(String(at(day)?.waist??""));
 return <Modal title="Log measurements" close={close} description="Record either measurement. Your previous dates stay in your history."><form onSubmit={e=>{e.preventDefault();if(!height&&!waist)return;void save({id:"measure-"+date,day:date,kind:"measure",data:{...(height?{height:Number(height)}:{}),...(waist?{waist:Number(waist)}:{})}},"Measurements saved")}}>
 <Field label="Date"><input required type="date" max={dateKey()} value={date} onChange={e=>{const d=e.target.value;setDate(d);setHeight(String(at(d)?.height??""));setWaist(String(at(d)?.waist??""))}}/></Field>
 <div className="fields"><Field label="Height (cm)"><input type="number" min="100" max="250" step=".1" value={height} onChange={e=>setHeight(e.target.value)}/></Field><Field label="Waist (cm)"><input type="number" min="35" max="300" step=".1" value={waist} onChange={e=>setWaist(e.target.value)}/></Field></div>
 <button className="primary full" disabled={busy||(!height&&!waist)}>Save measurements</button></form></Modal>
}
export function HealthPanel({rows,day,measure,target}:{rows:Stored[],day:string,measure:()=>void,target:()=>void}){
 const h=healthAt(rows,day);
 const signed=(v:number)=>(v>0?"+":"")+v.toFixed(1)+" kg";
 const figures=[
 ["7-day average weight",h.week===null?"—":h.week.toFixed(1)+" kg",h.n+" measured days in the past week"],
 ["Weekly trend",h.weeklyChange===null?"—":signed(h.weeklyChange),h.weeklyChange===null?"Needs two weigh-ins in each of two consecutive weeks":"Difference between consecutive 7-day averages"],
 ["Since first weigh-in",h.sinceStart===null?"—":signed(h.sinceStart),h.baseline?"First recorded "+h.baseline.day:"Log two dates to see change"],
 ["Height",h.height?h.height.value+" cm":"—",h.height?.day||"No height recorded"],
 ["Waist",h.waist?h.waist.value+" cm":"—",h.waist?.day||"Optional circumference"],
 ["BMI",h.bmi===null?"—":h.bmi.toFixed(1),"Weight (kg) ÷ height (m)²"],
 ["Resting energy",h.energy?format(h.energy.resting)+" kcal/day":"—","Estimated RMR · Mifflin–St Jeor"],
 ["Maintenance",h.energy?format(h.energy.maintenance)+" kcal/day":"—",h.profile?"Resting estimate × "+h.profile.factor+" activity factor":"Set a calculated target to estimate"],
 ].filter(([,value])=>value!=="—");
 return <section className="panel health"><div className="section-head"><h2>Body measurements & energy</h2><button className="light" onClick={measure}>Log measurements</button></div>{!figures.length&&<p>Log a measurement to begin tracking changes over time.</p>}<div className="body-facts">{figures.map(([label,value,note])=><div key={label}><span>{label}</span><strong>{value}</strong><small>{note}</small></div>)}</div>
 <details className="method"><summary>How to read these numbers</summary><p>Resting metabolic rate (RMR) estimates the energy you use at rest. A true basal metabolic rate (BMR) requires standardized measurement. The estimate here uses your latest recorded height and weight and the age and equation setting from your latest calculated profile. Your saved calorie target changes when you update it.</p><p>BMI is a screening measure. Weekly averages use the days you actually weighed in. For more comparable readings, weigh yourself at a consistent time of day.</p><p><a href="https://pubmed.ncbi.nlm.nih.gov/2305711/" target="_blank" rel="noreferrer">Mifflin–St Jeor study</a> · <a href="https://www.cdc.gov/bmi/about/index.html" target="_blank" rel="noreferrer">CDC BMI</a> · <a href="https://www.england.nhs.uk/long-read/how-to-record-your-weight/" target="_blank" rel="noreferrer">NHS weigh-in guidance</a></p></details><button className="text-btn" onClick={target}>Review calorie target</button></section>
}
