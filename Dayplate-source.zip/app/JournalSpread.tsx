"use client";
import {useState,useRef} from "react";
import {ArrowUpRight,ChevronLeft,ChevronRight,Check,Target} from "lucide-react";
import {catalog} from "./catalog";
import {type Food,type Stored,format,shift,foodEntries} from "./model";
import {dayNutrient,formatDaily} from "./nutrition";
export const dishes=[
 {name:"Kanda pohe",cuisine:"Maharashtrian",image:"pohe",title:"Kanda pohe"},
 {name:"Goan fish curry",cuisine:"Goan",image:"curry",title:"Goan fish curry"},
 {name:"Spaghetti aglio e olio",cuisine:"Continental",image:"pasta",title:"Aglio e olio"},
] as const;
export function WeekStrip({day,today,rows,onDay}:{day:string,today:string,rows:Stored[],onDay:(d:string)=>void}){
 const weekDay=(new Date(day+"T12:00:00").getDay()+6)%7;
 const monday=shift(day,-weekDay),active=new Set(rows.filter(r=>r.kind==="food"||r.kind==="exercise").map(r=>r.day));
 return <nav className="week-film" aria-label="Journal week"><button aria-label="Previous week" onClick={()=>onDay(shift(day,-7))}><ChevronLeft size={16}/></button>
 {Array.from({length:7},(_,i)=>{const d=shift(monday,i),dt=new Date(d+"T12:00:00");return <button key={d} aria-label={dt.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long"})+(active.has(d)?", entries logged":"")} aria-pressed={d===day} disabled={d>today} onClick={()=>onDay(d)}><small>{dt.toLocaleDateString("en-GB",{weekday:"short"})}</small><b>{dt.getDate()}</b><i className={active.has(d)?"marked":""}/></button>})}
 <button disabled={shift(monday,7)>today} aria-label="Next week" onClick={()=>onDay(shift(day,7)>today?today:shift(day,7))}><ChevronRight size={16}/></button></nav>
}
type LoggedFood=Extract<Stored,{kind:"food"}>;
export function FeaturedDish({choose,entries,edit}:{choose:(f:Food)=>void,entries:LoggedFood[],edit:(row:LoggedFood)=>void}){
 const [picked,setPicked]=useState<number|null>(null),start=useRef<number|null>(null);
 const initial=dishes.findIndex(d=>entries.some(r=>r.data.food.name===d.name));
 const index=picked??Math.max(initial,0);
 const recipe=dishes[index],food=catalog.find(f=>f.name===recipe.name)!;
 const logged=entries.find(r=>r.data.food.name===food.name);
 const step=(dir:number)=>setPicked((index+dir+dishes.length)%dishes.length);
 return <section className={"dish-cover art-"+recipe.image} aria-label="Featured foods from your library"
 onTouchStart={e=>start.current=e.changedTouches[0].clientX} onTouchEnd={e=>{const delta=e.changedTouches[0].clientX-(start.current??e.changedTouches[0].clientX);if(Math.abs(delta)>55)step(delta<0?1:-1);start.current=null}}>
 <div className="dish-shade"/><span className="dish-origin">{logged?logged.data.meal+" · Logged":recipe.cuisine}</span>
 <div className="dish-copy" aria-live="polite"><h2>{recipe.title}</h2><p>{logged?Number(logged.data.quantity.toFixed(2))+" × "+logged.data.food.serving:food.serving} <span>·</span> {format(logged?logged.data.quantity*logged.data.food.kcal:food.kcal)} kcal</p><button className="cover-cta" onClick={()=>logged?edit(logged):choose(food)}>{logged?"View entry":"Choose portion"}</button></div>
 <div className="cover-pager">{dishes.map((d,i)=><button aria-label={"Show "+d.title} aria-pressed={i===index} key={d.name} onClick={()=>setPicked(i)}><i/></button>)}</div>
 </section>
}
export function DailyBudget({rows,budget,proteinGoal,target}:{rows:Stored[],budget:number,proteinGoal?:number,target:()=>void}){
 const foods=foodEntries(rows),kcal=foods.reduce((s,e)=>s+e.data.food.kcal*e.data.quantity,0),protein=dayNutrient(rows,"p");
 const remaining=budget-kcal,frac=budget?Math.min(1,kcal/budget):0;
 return <section className="paper-budget"><div className="budget-label"><span>Daily intake</span><button aria-label="Edit daily target" onClick={target}><Target size={18}/></button></div>
 <div className="energy-display">{format(kcal)} <span>kcal</span></div>
 <div className="budget-rule" role={budget?"meter":undefined} aria-label="Calorie target progress" aria-valuemin={0} aria-valuemax={budget||undefined} aria-valuenow={budget?Math.min(budget,Math.round(kcal)):undefined}><span style={{width:frac*100+"%"}}/></div>
 {budget?<p><b>{format(Math.abs(remaining))} kcal</b> {remaining<0?"over":"left of"} {format(budget)}</p>:<button className="set-budget" onClick={target}>Set a calorie target <ArrowUpRight size={15}/></button>}
 <div className="protein-line"><span>Protein</span><b>{foods.length?formatDaily(protein):"0"} g {proteinGoal?<small>/ {proteinGoal} g</small>:null}</b></div>
 {protein.missing>0&&<small>Reported for {protein.total-protein.missing} of {protein.total} entries</small>}</section>
}
