"use client";
import {distinctFoods} from "./nutrition";
import {useMemo,useState} from "react";
import {BookOpen,Plus,SlidersHorizontal,Utensils,Trash2} from "lucide-react";
import {searchFood} from "./catalog";
import {foodSchema,foodEntries,format,meals,targetAt,totals,type Meal,type Food,type Stored,type Entry} from "./model";
import {CrewAside} from "./CafeCounter";
import {foodCall} from "./cafe-cast";
import {amountOf,foodKey,unitOf,dayNutrient,nutrients} from "./nutrition";
import {defaultMealNutrients,mealNutrientFact,nutrientName} from "./MealNutrients";
import {Modal,Field} from "./ui";
import {pantry,plateRows,recipePortion,toFoodEntries,type Line,type Plan,type Recipe} from "./kitchen";
import type {FoodEntry} from "./repeat";
type Save=(entry:Entry,message:string,revision?:number)=>Promise<boolean>;

function Quantity({value,onChange,label,scale=1}:{value:number,onChange:(n:number)=>void,label:string,scale?:number}){
  return <label className="k-quantity"><span>{label}</span><input type="number" inputMode="decimal" min={.001*scale} max={1000*scale} step="any"
    value={value?Number((value*scale).toFixed(6)):""} onChange={e=>onChange(Number(e.target.value)/scale)}/></label>;
}
function Ingredients({foods,lines,change,recipe=false}:{foods:Food[],lines:Line[],change:(l:Line[])=>void,recipe?:boolean}){
  const [query,setQuery]=useState(""),[more,setMore]=useState(8);
  const results=useMemo(()=>searchFood(foods,query.trim()),[foods,query]);
  const add=(f:Food)=>{
    if(lines.length>=40)return;
    const food=foodSchema.parse(f);
    change([...lines,{id:crypto.randomUUID(),food,quantity:1}]);setQuery("");setMore(8);
  };
  return <><div className="k-lines">{lines.map((l,i)=>{
    const unit=unitOf(l.food),size=amountOf(l.food);
    const scale=recipe&&size&&(unit==="g"||unit==="ml")?size:1;
    return <div className="k-line" key={l.id}><div><b>{l.food.name}</b><small>{l.food.serving} · {l.food.panel?.kind??"Your food"}</small>
      {recipe&&l.food.panel?.source&&<a className="k-source" href={l.food.panel.source} target="_blank" rel="noreferrer">Nutrition source</a>}</div>
      <Quantity label={scale!==1?unit:l.food.serving==="1 serving"?"Servings":"× "+l.food.serving} scale={scale} value={l.quantity} onChange={quantity=>change(lines.map((v,j)=>j===i?{...v,quantity}:v))}/>
      <button type="button" className="icon-btn" aria-label={"Remove "+l.food.name} onClick={()=>change(lines.filter(v=>v.id!==l.id))}><Trash2 size={15}/></button></div>;
  })}</div>
  <Field label={recipe?"Find an ingredient":"Add a food or recipe"}><input type="search" value={query} placeholder={recipe?"Search dal, dry rice, cooking oil…":"Search your usual foods…"} onChange={e=>{setQuery(e.target.value);setMore(8)}}/></Field>
  <div className="k-results">{results.slice(0,query?more:4).map(f=><button type="button" key={foodKey(f)} disabled={lines.length>=40} onClick={()=>add(f)}><span>{f.name}<small>{f.serving} · {format(f.kcal)} kcal</small></span><Plus size={15}/></button>)}</div>
  {query&&results.length>more&&<button type="button" className="text-btn" onClick={()=>setMore(more+12)}>Show more matches</button>}
  {query&&!results.length&&<p className="note">No match. You can create this food in Foods using its label.</p>}</>;
}
function RemoveSaved({entry,busy,remove,label}:{entry:Stored,busy:boolean,remove:(r:Stored)=>Promise<boolean>,label:string}){
  const [asked,ask]=useState(false);
  return <button type="button" className="text-btn" disabled={busy} onClick={()=>asked?void remove(entry):ask(true)}>{asked?"Confirm removal":label}</button>;
}
export function RecipeForm({rows,foods,edit,day,busy,close,save,remove}:{rows:Stored[],foods:Food[],edit?:Recipe,day:string,busy:boolean,close:()=>void,save:Save,remove:(r:Stored)=>Promise<boolean>}){
  const [id]=useState(()=>edit?.id??crypto.randomUUID()),[name,setName]=useState(edit?.data.name??"");
  const [unit,setUnit]=useState(edit?.data.unit??"katori"),[y,setYield]=useState(String(edit?.data.yieldCount??4));
  const [lines,setLines]=useState<Line[]>(edit?.data.lines??[]);
  const data={name:name.trim(),unit:unit.trim(),yieldCount:Number(y),lines};
  const portion=recipePortion(data);
  const ingredients=useMemo(()=>distinctFoods([...pantry,...foods]),[foods]);
  const duplicate=rows.some(r=>r.kind==="recipe"&&r.id!==id&&r.data.name.toLowerCase()===data.name.toLowerCase());
  const valid=!!portion&&!!data.name&&!!data.unit&&!duplicate&&lines.every(l=>l.quantity>=.001&&l.quantity<=1000)&&Number(y)>=.001&&Number(y)<=1000;
  return <Modal title={edit?"Edit kitchen recipe":"New kitchen recipe"} close={close} description="Enter the whole batch and how many of your portions it makes. For a personal measure, use one ingredient and the amount your cup or ladle holds.">
    <form onSubmit={e=>{e.preventDefault();if(valid)void save({kind:"recipe",id,day:edit?.day??day,data},"Recipe saved to your kitchen",edit?.revision??0)}}>
      <Field label="Recipe or portion name"><input maxLength={100} required value={name} placeholder="Our fish curry" onChange={e=>setName(e.target.value)}/></Field>
      <div className="fields"><Field label="Batch makes"><input required type="number" step="any" min=".001" max="1000" value={y} onChange={e=>setYield(e.target.value)}/></Field>
      <Field label="My portion is one"><input required maxLength={85} value={unit} placeholder="ladle, katori, dabba…" onChange={e=>setUnit(e.target.value)}/></Field></div>
      <Ingredients foods={ingredients} lines={lines} change={setLines} recipe/>
      {portion&&<p className="k-preview">1 {unit} ≈ <b>{format(portion.kcal)} kcal</b>{portion.p!=null?" · "+Number(portion.p.toFixed(1))+" g protein":""}</p>}
      {duplicate&&<p role="alert">A recipe already uses this name.</p>}
      <button type="submit" className="primary full" disabled={busy||!valid}>Save recipe</button>
      {edit&&<RemoveSaved entry={edit} busy={busy} remove={remove} label="Remove recipe"/>}
    </form></Modal>;
}
export function MealPlanner({crew,rows,foods,day,initial,edit,busy,close,save,eat,remove}:{crew:boolean,rows:Stored[],foods:Food[],day:string,initial:Meal,edit?:Plan,busy:boolean,close:()=>void,save:Save,remove:(r:Stored)=>Promise<boolean>,eat:(entries:FoodEntry[],consume?:{id:string,revision:number})=>Promise<boolean>}){
  const [id]=useState(()=>edit?.id??crypto.randomUUID()),[meal,setMeal]=useState<Meal>(edit?.data.meal??initial),[lines,setLines]=useState<Line[]>(edit?.data.lines??[]);
  const [original,keep]=useState<Line[]|null>(null);
  const before=plateRows(original??[],day,meal);
  const planned=plateRows(lines,day,meal),logged=foodEntries(rows).filter(r=>r.day===day),dayAfter=[...logged,...planned];
  const keys=rows.find(r=>r.kind==="mealNutrients")?.data.keys??defaultMealNutrients;
  const list=useMemo(()=>distinctFoods([...rows.filter(r=>r.kind==="recipe").flatMap(r=>recipePortion(r.data)??[]),...foodEntries(rows).filter(r=>r.day<=day).sort((a,b)=>b.day.localeCompare(a.day)).map(r=>r.data.food),...foods]),[rows,day,foods]);
  const valid=lines.length>0&&lines.every(l=>l.quantity>=.001&&l.quantity<=1000);
  const target=targetAt(rows,day)?.data;
  const budget=target?.calories;
  const last=lines.at(-1);
  const swap=()=>{if(original){setLines(original);keep(lines)}};
  const delta=(key:string)=>{
    const a=dayNutrient(before,key),b=dayNutrient(planned,key);
    if(!a.total||!b.total||a.known!==a.total||b.known!==b.total)return "—";
    const change=Number((b.sum-a.sum).toFixed(1));
    return (change>0?"+":"")+change+" "+nutrients[key][1];
  };
  return <Modal title="Plan my next meal" close={close} description="Try portions before you eat. Only Ate this adds them to your diary.">
    <Field label="Meal"><select value={meal} onChange={e=>setMeal(e.target.value as Meal)}>{meals.map(m=><option key={m}>{m}</option>)}</select></Field>
    {original&&<div className="comparison-note"><b>Trying another plate</b><small>Original · {original.map(l=>l.quantity+" × "+l.food.name).join(", ")}</small><button type="button" className="light" onClick={swap} disabled={!valid}>Switch plates</button><button type="button" className="text-btn" onClick={()=>{setLines(original);keep(null)}}>Return to original</button></div>}
    <Ingredients foods={list} lines={lines} change={setLines}/>
    {valid&&!original&&<button className="light compare-start" onClick={()=>keep(lines)}>Compare another plate</button>}
    {original&&valid&&<div className="k-projection"><table><caption>Compare plates</caption><thead><tr><th>Nutrient</th><th>Original</th><th>Current</th><th>Change</th></tr></thead><tbody>{["kcal",...keys].map(k=><tr key={k}><th>{nutrientName(k)}</th>{[before,planned].map((set,i)=>{const fact=mealNutrientFact(set,k);return <td key={i}>{fact.value}<small>{fact.coverage}</small></td>})}<td>{delta(k)}</td></tr>)}</tbody></table><small>Save or log the current plate. A dash means a comparable total is unavailable.</small></div>}
    {crew&&valid&&last&&<CrewAside call={foodCall(last.food,last.quantity,target?.proteinGoal)} seed={last.food.name}/>}
    {valid&&<div className="k-projection"><table><caption>Portion preview</caption><thead><tr><th>Nutrient</th><th>This plan</th><th>Day after meal</th></tr></thead><tbody>
    <tr><th>Energy</th><td>{format(totals(planned).kcal)} kcal</td><td>{format(totals(dayAfter).kcal)} kcal</td></tr>
    {keys.map(k=><tr key={k}><th>{nutrientName(k)}</th>{[planned,dayAfter].map((set,i)=>{const f=mealNutrientFact(set,k);return <td key={i}>{f.value}<small>{f.coverage}</small></td>})}</tr>)}</tbody></table>
    {budget&&<small>Daily target · {format(budget)} kcal</small>}</div>}
    <div className="k-actions"><button className="light" disabled={busy||!valid} onClick={()=>void save({kind:"plan",id,day,data:{meal,lines}},"Plan saved",edit?.revision??0)}>Save for later</button>
    <button className="primary" disabled={busy||!valid} onClick={()=>void eat(toFoodEntries(planned),edit&&{id:edit.id,revision:edit.revision})}>Ate this</button></div>
    {edit&&<RemoveSaved entry={edit} busy={busy} remove={remove} label="Discard plan"/>}
  </Modal>;
}
export function KitchenCard({rows,day,plan,kitchen,review}:{rows:Stored[],day:string,plan:(p?:Plan)=>void,kitchen:()=>void,review:()=>void}){
  const drafts=rows.filter((r):r is Plan=>r.kind==="plan"&&r.day===day);
  return <section className="k-counter"><div className="k-copy"><Utensils size={21}/><h2>What’s for your next meal?</h2></div>
    <div className="k-actions"><button className="primary" onClick={()=>plan()}>Plan my next meal</button><button className="light" onClick={kitchen}><BookOpen size={16}/>My kitchen</button><button className="text-btn" onClick={review}>Weekly review</button></div>
    {drafts.map(p=><button className="k-draft" key={p.id} onClick={()=>plan(p)}><SlidersHorizontal size={15}/><b>Planned {p.data.meal.toLowerCase()}</b><span>{p.data.lines.map(l=>l.food.name).join(", ")}</span></button>)}</section>;
}
export function KitchenShelf({rows,create,edit,log}:{rows:Stored[],create:()=>void,edit:(r:Recipe)=>void,log:(f:Food)=>void}){
  const recipes=rows.filter(r=>r.kind==="recipe");
  return <section className="panel k-shelf"><div className="section-head"><h2>My kitchen</h2><button className="light" onClick={create}><Plus size={16}/>New recipe</button></div>
    {!recipes.length&&<p>Save your family recipes and the portions you actually serve.</p>}
    {recipes.map(r=>{const f=recipePortion(r.data);return <div className="k-shelf-row" key={r.id}><div><b>{r.data.name}</b><small>{r.data.yieldCount} × {r.data.unit} per batch</small></div><button className="text-btn" onClick={()=>edit(r)}>Edit recipe</button>{f&&<button className="light" onClick={()=>log(f)}>Log portion</button>}</div>})}</section>;
}
