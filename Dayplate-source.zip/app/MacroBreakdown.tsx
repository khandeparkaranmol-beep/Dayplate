"use client";
import {useState} from "react";
import {Beef,Wheat,Droplet,ChevronDown} from "lucide-react";
import {type Stored,type Meal,foodEntries,meals} from "./model";
import {dayNutrient,formatDaily} from "./nutrition";

const macros=[
  {key:"p",title:"Protein",tone:"protein",factor:4,Icon:Beef},
  {key:"c",title:"Carbs",tone:"carbs",factor:4,Icon:Wheat},
  {key:"f",title:"Fat",tone:"fat",factor:9,Icon:Droplet}
];
export function MacroBreakdown({rows,openMeal}:{rows:Stored[],openMeal:(meal:Meal)=>void}){
  const [picked,pick]=useState("");
  const foods=foodEntries(rows);
  const facts=macros.map(m=>({...m,fact:dayNutrient(foods,m.key)}));
  const complete=foods.length>0&&facts.every(m=>m.fact.known===foods.length);
  const calories=facts.reduce((s,m)=>s+m.fact.sum*m.factor,0);
  return <details className="macro-detail"><summary>Macronutrient breakdown</summary>
    {foods.length===0?<p className="note">Log a food to see its contribution.</p>:<div className="macro-list">{facts.map(({key,title,Icon,tone,fact,factor})=>{
      const pct=complete&&calories>0?100*fact.sum*factor/calories:null;
      return <div key={key} className={"macro "+tone}><button className="macro-toggle" aria-expanded={picked===key} onClick={()=>pick(picked===key?"":key)}>
        <span className="macro-name"><i><Icon size={15}/></i><span>{title}</span><b>{fact.known+fact.bounded?formatDaily(fact)+" g":"Unlisted"}</b>{pct!=null&&<span className="macro-pct">{Math.round(pct)}%</span>}<ChevronDown size={13}/></span>
        {pct!=null&&<span className="track" aria-hidden="true"><span style={{width:pct+"%"}}/></span>}</button>
        {picked===key&&<div className="macro-sources">{meals.flatMap(meal=>{
          const items=foods.filter(r=>r.data.meal===meal);
          if(!items.length)return [];
          const d=dayNutrient(items,key);
          return [<button key={meal} onClick={()=>openMeal(meal)}><span>{meal}</span><span>{d.known+d.bounded?formatDaily(d)+" g":"Unlisted"}{d.missing>0&&d.known+d.bounded>0?" · partial":""}</span></button>];
        })}</div>}</div>;
    })}</div>}
    {foods.length>0&&<small className="macro-foot">{!complete?"Some macro values are missing or reported as limits. Open a macro for the meal totals.":calories>0?"Percentages show the share of energy from protein, carbs and fat. Open a macro to see its meals.":"Logged macros total 0 g."}</small>}
  </details>;
}
