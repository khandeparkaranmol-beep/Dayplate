"use client";
import {useState} from "react";
import {Apple, ChevronDown, MoonStar, Plus, Share2, Sun, Sunrise} from "lucide-react";
import {format, totals, type Meal, type Stored} from "./model";
import {compactNumber, scaled, dayNutrient} from "./nutrition";
import {MealNutrients, mealNutrientFact, nutrientName, columnStyle} from "./MealNutrients";

type MealFood = Extract<Stored, {kind:"food"}>;
const mealIcons = {Breakfast: Sunrise, Lunch: Sun, Dinner: MoonStar, Snacks: Apple};

type Props = {
  meal: Meal; foods: MealFood[]; keys: string[]; columns?: number; expanded: boolean;
  toggle: () => void; add: () => void; edit: (row: MealFood) => void; share?: () => void;
};

function portionText({data: {food, quantity}}: MealFood) {
  if (quantity === 1) return food.serving;
  const weight = food.serving.match(/^([0-9]+(?:\.[0-9]+)?) (g|ml)(?: (?:weighed )?portion)?$/i);
  if (weight) return compactNumber(Number(weight[1]) * quantity) + " " + weight[2];
  const count = food.serving.match(/^1 ((?:(?:small|medium|large) )?(?:biscuit|cup|bowl|handful|slice|piece|glass))( \(.+\))?$/i);
  if (count) {
    const unit = quantity > 1 ? count[1] + (count[1].endsWith("glass") ? "es" : "s") : count[1];
    return compactNumber(quantity) + " " + unit + (count[2] ?? "");
  }
  return compactNumber(quantity) + " × " + food.serving;
}

const photos = new Map<string, string>([
  ["Peanuts, roasted", "peanuts"], ["Haldiram’s Moong Dal", "moong"],
  ["Britannia Treat Jim Jam Biscuits", "biscuit"], ["Masala chai, sweetened", "chai"],
  ["Steamed basmati rice", "rice"], ["Plain dosa", "dosa"], ["Roti / chapati", "roti"],
  ["Dal tadka", "dal"], ["Banana", "banana"]
]);

export function MealCard({meal, foods, keys, columns, expanded, toggle, add, edit, share}: Props) {
  const [choice, setChoice] = useState("kcal");
  const all = choice === "all" && keys.length > 0;
  const metric = keys.includes(choice) ? choice : "kcal";
  const Icon = mealIcons[meal];
  const populated = foods.length > 0;
  const open = populated && expanded;
  const total = totals(foods).kcal;
  const metricTotal = dayNutrient(foods, metric);
  const canCompare = metricTotal.missing === 0 && metricTotal.bounded === 0 && metricTotal.sum > 0;
  const listId = "meal-foods-" + meal;
  const numberOfFoods = foods.length + (foods.length === 1 ? " food" : " foods");
  return <section className="meal-card" data-meal={meal} data-filled={populated} data-open={open}
    id={"journal-meal-" + meal} aria-label={meal}>
    <header className="mc-head">
      <button className="mc-toggle" type="button" onClick={populated ? toggle : add}
        aria-expanded={populated ? open : undefined} aria-controls={populated ? listId : undefined}>
        <span className="mc-icon"><Icon size={24} aria-hidden="true"/></span>
        <span className="mc-heading"><strong>{meal}</strong>
          <span>{populated ? numberOfFoods + " logged" : "Add " + meal.toLowerCase()}</span>
        </span>
        {populated && <ChevronDown className="mc-disclosure" size={16} aria-hidden="true"/>}
      </button>
      {populated && <span className="mc-total">{format(total)} <small>kcal</small></span>}
      <button className="mc-add" type="button" onClick={add} aria-label={"Add food to " + meal}>
        <Plus size={17} aria-hidden="true"/><span>Add food</span>
      </button>
    </header>
    <MealNutrients foods={foods} keys={keys} columns={columns} meal={meal}/>
    {populated && <div id={listId} hidden={!open}>
      {open && <div className="mc-foods">
        <div className="mc-toolbar"><span>Food &amp; portion</span>
          {keys.length > 0 ? <label className="mc-select"><span>View by</span>
            <select aria-label={"Compare " + meal.toLowerCase() + " foods by"} value={all ? "all" : metric}
              onChange={e => setChoice(e.target.value)}>
              <option value="kcal">Calories</option>
              {keys.map(k => <option value={k} key={k}>{nutrientName(k)}</option>)}
              <option value="all">All nutrients</option>
            </select><ChevronDown size={14} aria-hidden="true"/>
          </label> : <span>Calories</span>}
        </div>
        <ul aria-label={meal + " foods"}>{foods.map(row => {
          const {food, quantity} = row.data;
          const value = metric === "kcal" ? format(food.kcal * quantity) + " kcal" : mealNutrientFact([row], metric).value;
          const amount = scaled(food, metric, quantity);
          const photo = photos.get(food.name);
          return <li key={row.id}>
            <button type="button" className="mc-food" onClick={() => edit(row)} title={"Edit " + food.name}>
              <span className="mc-thumb" aria-hidden="true" data-photo={photo}>{!photo && food.icon}</span>
              <span className="mc-food-title"><strong>{food.name}</strong><span className="mc-portion">{portionText(row)}</span></span>
              <span className="mc-reading" data-missing={!amount}>
                <span className="mc-sr">{metric === "kcal" ? "Energy" : nutrientName(metric)} </span>{value}
                {canCompare && amount && !all && <span className="mc-track" aria-hidden="true">
                  <i style={{width: Math.min(100,100 * amount.value / metricTotal.sum) + "%"}}/>
                </span>}
              </span>
              {all && <span className="mc-facts" style={columnStyle(columns)}>
                {keys.map(k => <span key={k}><span>{nutrientName(k)}</span><b>{mealNutrientFact([row], k).value}</b></span>)}
              </span>}
              <span className="mc-sr">Edit {food.name}</span>
            </button>
          </li>;
        })}</ul>
        {share && <div className="mc-share"><button type="button" className="light" onClick={share}>
          <Share2 size={15} aria-hidden="true"/>Share {meal.toLowerCase()}
        </button></div>}
      </div>}
    </div>}
  </section>;
}
