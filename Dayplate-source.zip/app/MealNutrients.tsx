"use client";
import {useState,type CSSProperties} from "react";
import type {Stored} from "./model";
import {compactNumber,dayNutrient,formatDaily,nutrients,scaled} from "./nutrition";
import {Modal} from "./ui";

type LoggedFood=Extract<Stored,{kind:"food"}>;
export const defaultMealNutrients=["p","sugar"];
const common=["p","c","f","fiber","sugar","sodium","addedSugar","potassium"];
const shortNames:Record<string,string>={p:"Protein",c:"Carbs",f:"Fat",fiber:"Fiber",sugar:"Total sugar",addedSugar:"Added sugar"};
export const nutrientName=(key:string)=>shortNames[key]??nutrients[key][0];
const searchable=(text:string)=>text.toLowerCase().replaceAll("fibre","fiber").replace(/\bfats\b/g,"fat");
export function columnStyle(columns:number|undefined){
  return columns?{"--meal-grid":`repeat(${columns},minmax(min(4.5rem,100%),1fr))`} as CSSProperties:undefined;
}
const displayAmount=(n:number)=>n>0&&n<0.1?"<0.1":Number(n.toFixed(1)).toLocaleString("en-IN");

export function mealNutrientFact(foods:LoggedFood[],key:string){
  const d=dayNutrient(foods,key);
  const present=d.known+d.bounded;
  if(!present)return {value:"Unlisted",coverage:""};
  const one=foods.length===1?scaled(foods[0].data.food,key,foods[0].data.quantity):null;
  const amount=one?.relation?one.relation+compactNumber(one.value):d.bounded?formatDaily(d):displayAmount(d.sum);
  const estimated=foods.some(({data})=>data.food.panel?.kind==="Recipe estimate"&&scaled(data.food,key)!=null);
  return {
    value:(estimated?"≈ ":"")+amount+" "+nutrients[key][1],
    coverage:d.missing?"from "+present+" of "+d.total+" foods":"",
  };
}
export function MealNutrients({foods,keys,meal,columns}:{foods:LoggedFood[],keys:string[],meal:string,columns?:number}){
  if(!foods.length||!keys.length)return null;
  return <dl className="meal-nutrients" data-dense={(columns??0)>=4} style={columnStyle(columns)} aria-label={meal+" nutrient totals"}>{keys.map(key=>{
    const fact=mealNutrientFact(foods,key);
    return <div key={key} data-nutrient={key}><dt><span>{nutrientName(key)}</span></dt>
      <dd data-missing={fact.value==="Unlisted"}>{fact.value}{fact.coverage&&<small>{fact.coverage}</small>}</dd></div>;
  })}</dl>;
}
export function MealNutrientPicker({keys,columns,busy,close,save}:{keys:string[],columns?:number,busy:boolean,close:()=>void,save:(keys:string[],columns?:number)=>void}){
  const [draft,setDraft]=useState(keys),[width,setWidth]=useState(columns??0),[search,setSearch]=useState("");
  const all=[...new Set([...common,...Object.keys(nutrients)])].filter(k=>k!=="kcal");
  const query=searchable(search.trim());
  const matches=all.filter(k=>searchable(nutrientName(k)+" "+nutrients[k][0]).includes(query));
  const shownColumns=Math.min(width,draft.length);
  return <Modal title="Customize meal columns" description="Choose the nutrients you want to see at every meal." close={close}>
    <label className="field"><span>Find a nutrient</span><input type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="e.g. Carbs, fiber or sodium"/></label>
    <div className="meal-nutrient-options">{matches.map(k=>
      <label key={k}><input type="checkbox" checked={draft.includes(k)} onChange={e=>setDraft(e.target.checked?[...draft,k]:draft.filter(v=>v!==k))}/>{nutrientName(k)}</label>
    )}{!matches.length&&<p>No matching nutrients.</p>}</div>
    {draft.length>0&&<><label className="field"><span>Columns per row</span><select value={shownColumns} onChange={e=>setWidth(Number(e.target.value))}>
      <option value={0}>Auto · fit my screen</option>{draft.map((_,i)=><option key={i} value={i+1}>{i+1}</option>)}
    </select></label>
    <div className="meal-layout-preview" aria-label="Meal column preview" style={columnStyle(shownColumns)}>{draft.map(k=><span key={k}>{nutrientName(k)}</span>)}</div></>}
    {!draft.length&&<p className="note">Each meal will show calories only.</p>}
    <button type="button" className="primary full" disabled={busy} onClick={()=>save(draft,shownColumns||undefined)}>{busy?"Saving…":"Save columns"}</button>
  </Modal>;
}
