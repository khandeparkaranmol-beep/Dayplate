"use client";
import {useEffect,useState} from "react";
import {Activity,ArrowUpRight,Heart,Plus,RefreshCw} from "lucide-react";
import {type Stored,shift,format} from "./model";
import HealthImport from "./HealthImport";
import type {JournalRequest} from "./activity-records";
type Exercise=Extract<Stored,{kind:"exercise"}>;
export const duration=(mins:number)=>mins>0&&mins<1?"<1 min":format(mins)+" min";
export function Movement({rows,day,log,journal,request,refresh}:{request:JournalRequest,refresh:()=>Promise<void>,rows:Stored[],day:string,log:()=>void,journal:(day:string)=>void}){
 const [picked,pick]=useState(day);
 useEffect(()=>{pick(day)},[day]);
 const activity=rows.find((r):r is Extract<Stored,{kind:"activity"}>=>r.kind==="activity"&&r.day===picked)?.data;
 const workouts=rows.filter((r):r is Exercise=>r.kind==="exercise");
 const days=Array.from({length:7},(_,i)=>shift(day,i-6));
 const week=workouts.filter(w=>days.includes(w.day));
 const amounts=days.map(d=>week.filter(w=>w.day===d).reduce((s,w)=>s+w.data.minutes,0));
 const max=Math.max(1,...amounts),minutes=amounts.reduce((a,b)=>a+b,0);
 const records=week.filter(w=>w.day===picked).sort((a,b)=>(a.data.health?.start||"").localeCompare(b.data.health?.start||""));
 return <div className="move-layout"><section className="move-week"><div className="move-title"><Activity size={22}/><span>Last seven days</span></div><div className="move-number">{format(minutes)} <span>min</span></div><p>{week.length} {week.length===1?"workout":"workouts"} · {amounts.filter(n=>n>0).length} active days</p>
 <div className="move-bars">{days.map((d,i)=><button key={d} aria-pressed={picked===d} aria-label={d+" · "+duration(amounts[i])} onClick={()=>pick(d)}><span className="bar-well"><i style={{height:Math.max(amounts[i]?6:2,amounts[i]/max*100)+"%"}}/></span><span>{new Date(d+"T12:00:00").toLocaleDateString("en-GB",{weekday:"short"})}</span></button>)}</div></section>
 <HealthImport request={request} refresh={refresh}/>
 <section className="panel activity-card"><div className="section-head"><h2>Daily activity</h2><small>{picked}</small></div><div className="activity-values">{([["Steps",activity?.steps,"steps"],["Active energy",activity?.active,"kcal"],["Resting energy",activity?.resting,"kcal"],["Total energy",activity?.active!=null&&activity?.resting!=null?activity.active+activity.resting:undefined,"kcal"]] as const).map(([label,value,unit])=><div key={label}><small>{label}</small><b>{value==null?"—":format(value)}</b><span>{unit}</span></div>)}</div>{activity?<p className="note">{[...new Set(Object.values(activity.sources))].join(" · ")}</p>:<p className="note">Import a Health export to fill in this date.</p>}</section>
 <section className="panel move-sessions"><div className="section-head"><h2>{new Date(picked+"T12:00:00").toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"short"})}</h2><button className="text-btn" onClick={()=>journal(picked)}>Open journal <ArrowUpRight size={15}/></button></div>
 {records.length?records.map(r=><div className="session-row" key={r.id}><Activity/><span><b>{r.data.name}</b><small>{r.data.health?"Apple Health · "+new Date(r.data.health.start).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):"Logged by hand"}</small></span><strong>{duration(r.data.minutes)}</strong></div>):<p className="empty">No workouts logged on this date.</p>}</section></div>
}
