import {Field} from "./ui";
import {workoutTypes} from "./workout-energy";

export function MovementPicker({activity,minutes,changeActivity,changeMinutes,locked=false,original}:{activity:string;minutes:number;changeActivity:(v:string)=>void;changeMinutes:(v:number)=>void;locked?:boolean;original?:{name:string;minutes:number}}){
 const hours=Math.floor(minutes/60),mins=Number((minutes-hours*60).toFixed(6));
 const minutesList=hours===24?[0]:Array.from({length:60},(_,i)=>i);
 if(!minutesList.includes(mins))minutesList.push(mins);
 return <><Field label="Activity"><select required disabled={locked} value={activity} onChange={e=>changeActivity(e.target.value)}><option value="">Select a movement</option>
 {original&&!workoutTypes.some(w=>w.name===original.name)&&<option value={original.name}>{original.name} (recorded)</option>}{workoutTypes.map(w=><option key={w.name}>{w.name}</option>)}</select></Field>
 <fieldset className="duration-picker"><legend>Duration</legend><div className="fields">
 <Field label="Hours"><select disabled={locked} value={hours} onChange={e=>{const h=Number(e.target.value);changeMinutes(h===24?1440:h*60+Math.floor(mins))}}>{Array.from({length:Math.max(24,hours)+1},(_,i)=><option key={i} value={i}>{i} hr</option>)}</select></Field>
 <Field label="Minutes"><select disabled={locked||hours>=24} value={mins} onChange={e=>changeMinutes(hours*60+Number(e.target.value))}>{minutesList.map(m=><option key={m} value={m}>{m} min</option>)}</select></Field></div>
 {!locked&&<div className="habit-picks">{[10,20,30,45,60].map(n=><button type="button" key={n} aria-pressed={minutes===n} onClick={()=>changeMinutes(n)}>{n} min</button>)}</div>}
 </fieldset></>;
}
