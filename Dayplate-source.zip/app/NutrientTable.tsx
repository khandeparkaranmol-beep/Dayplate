"use client";
import { useState } from "react";
import type {Food, Stored} from "./model";
import {nutrients, scaled, dayNutrient, formatDaily, compactNumber, amountOf, unitOf} from "./nutrition";
const focus=["p","fiber","potassium","sodium","calcium","iron","sugar","addedSugar","satFat"];
export function NutrientTable({food,quantity=1}:{food:Food,quantity?:number}){
  const [basis,setBasis]=useState<"portion"|"source">("portion");
  const panel=food.panel;
  const active=basis==="source"&&panel;
  const keys=Object.keys(nutrients).filter(k=>["kcal","p","c","f","fiber","sugar","addedSugar","satFat","sodium","potassium","calcium","iron"].includes(k)||panel?.values[k]!==undefined);
  return <details className="nutri-details"><summary>Nutrition facts <small>{panel?.kind||"Portion estimate"}</small></summary>
    {panel&&<div className="quick-tabs"><button type="button" className={!active?"active":""} onClick={()=>setBasis("portion")}>Your portion</button><button type="button" className={active?"active":""} onClick={()=>setBasis("source")}>Source · {panel.amount} {panel.unit}</button></div>}
    <dl className="facts">{keys.map(k=>{const n=active?(panel.values[k]===undefined?null:{value:panel.values[k],relation:panel.bounds?.[k]}):scaled(food,k,quantity);return <div key={k}><dt>{nutrients[k][0]}</dt><dd>{n?(n.relation||"")+compactNumber(n.value)+" "+nutrients[k][1]:"Unknown"}</dd></div>})}</dl>
    {panel&&<div className="source-note">{panel.variant&&<b>{panel.variant}</b>}{panel.detail&&<p>{panel.detail}</p>}{panel.barcode&&<p>Barcode {panel.barcode}</p>}{panel.checked&&<p>Source checked {panel.checked}</p>}{panel.source&&<a href={panel.source} target="_blank" rel="noreferrer">Open nutrition source</a>}{panel.links?.map((link,i)=><span key={link}> · <a href={link} target="_blank" rel="noreferrer">Supporting source {i+1}</a></span>)}</div>}
  </details>
}
export function DailyNutrients({rows,proteinGoal}:{rows:Stored[],proteinGoal?:number}){
 const [expanded,setExpanded]=useState(false);
 const protein=dayNutrient(rows,"p");
 const total=rows.filter(r=>r.kind==="food").length;
 const keys=expanded?Object.keys(nutrients).filter(k=>focus.includes(k)||dayNutrient(rows,k).known+dayNutrient(rows,k).bounded>0):["p","fiber","potassium","sodium"];
 return <section className="panel daily-nutrients"><div className="section-head"><h2>Daily nutrients</h2><button className="light" onClick={()=>setExpanded(!expanded)}>{expanded?"Show less":"See all"}</button></div>{total===0?<p className="empty">Log a food to see your nutrient totals.</p>:<><div className="daily-facts">{keys.map(k=>{const d=dayNutrient(rows,k);return <div key={k}><span>{nutrients[k][0]}</span><strong>{formatDaily(d)}{d.known+d.bounded>0?" "+nutrients[k][1]:""}</strong><small>{d.known+d.bounded} of {d.total} entries{d.missing?" · partial":""}</small></div>})}</div>{proteinGoal&&<p className="note">Protein goal · {proteinGoal} g/day. {protein.missing?"Some logged foods have unknown protein.":protein.bounded?"Some labels report a limit for protein.":Math.max(0,proteinGoal-protein.sum).toFixed(1)+" g remaining."}</p>}<p className="note">Totals cover entries with a reported amount. A range reflects a limit printed on a label.</p></>}</section>
}
