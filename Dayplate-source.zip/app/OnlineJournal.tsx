"use client";
import Journal from "./journal";
import AccountBackup from "./AccountBackup";
export default function OnlineJournal(){return <Journal online backup={AccountBackup}/>}
