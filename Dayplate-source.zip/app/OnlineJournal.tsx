"use client";
import {pagesRequest} from "./pages-api";
import Journal from "./journal";
import AccountBackup from "./AccountBackup";
export default function OnlineJournal(){return <Journal online request={pagesRequest} backup={AccountBackup}/>}
