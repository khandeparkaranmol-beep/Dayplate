"use client";
import {useState,useRef,useEffect} from "react";
import {Field} from "./ui";
import {nutrients,panelSchema,makePanelFood,validBarcode,type NutritionPanel} from "./nutrition";
import type {Food} from "./model";
import {lookupBarcode} from "./label-lookup";
import {cachedDirectory,installDirectory,indexRelease,marketMatches,searchIndiaMarket,type IndexItem} from "./market-index";
type Props={accept:(f:Food)=>void,busy:boolean,prefill?:Food;productName?:string};
export default function PackageForm({accept,busy,prefill,productName=""}:Props){
 const initial=prefill?.panel;
 const [barcode,code]=useState(initial?.barcode||""),[name,setName]=useState(prefill?prefill.name+" (my pack)":productName),[size,setSize]=useState(String(prefill?.ml||prefill?.grams||"")),[basis,setBasis]=useState(String(initial?.amount||100)),[unit,setUnit]=useState<"g"|"ml">(initial?.unit==="ml"?"ml":"g"),[serving,setServing]=useState(prefill?.serving||"1 serving"),[values,setValues]=useState<Record<string,string>>(Object.fromEntries(Object.entries(initial?.values||{}).map(([k,v])=>[k,(initial?.bounds?.[k]||"")+v]))),[source,setSource]=useState(""),[picture,setPicture]=useState(""),[checked,setChecked]=useState(false),[more,setMore]=useState(false),[status,setStatus]=useState(""),[fetching,wait]=useState(false);
 const [remoteResults,setRemoteResults]=useState<IndexItem[]>([]),[remoteBusy,setRemoteBusy]=useState(false);
 const [items,setItems]=useState<IndexItem[]>([]),[search,setSearch]=useState(""),[directoryMessage,setDirectoryMessage]=useState(""),[loadingIndex,setLoadingIndex]=useState(false),file=useRef<HTMLInputElement>(null);
 useEffect(()=>{let live=true;void cachedDirectory().then(a=>{if(live)setItems(a)});return()=>{live=false}},[]);
 async function getIndex(selected?:File){setLoadingIndex(true);setDirectoryMessage("");try{const d=await installDirectory(selected);setItems(d.entries);setDirectoryMessage(d.entries.length.toLocaleString()+" food candidates "+(d.cached?"saved for offline search.":"loaded for this session."))}catch(e){setDirectoryMessage((e as Error).message+" You can also download and import the snapshot.")}finally{setLoadingIndex(false)}}
 async function searchOnline(){
  setRemoteBusy(true);setRemoteResults([]);setDirectoryMessage("");
  try{const hits=await searchIndiaMarket(search);setRemoteResults(hits);setDirectoryMessage(hits.length?hits.length+" online candidates. Compare the packet before logging.":"No verified India-market match in these results. Try a barcode.")}catch(e){setDirectoryMessage((e as Error).message)}finally{setRemoteBusy(false)}
 }
 async function lookup(picked?:IndexItem){
  const b=picked?.code||barcode.trim();if(!validBarcode(b)){setStatus("Enter the complete 8-, 12-, 13- or 14-digit barcode.");return}
  wait(true);setStatus("");setChecked(false);setPicture("");setSource("");setValues({});setSize("");setBasis("100");setUnit("g");setServing("1 serving");setName(picked?.name||"");code(b);
  try{const product=await lookupBarcode(b);if(!product){setStatus("No provider record for this barcode. Transcribe the package below.");return}setName(product.name||picked?.name||"");setValues(product.values);setUnit(product.unit);setSource(product.source);setPicture(product.image||"");setStatus("Compare the variant, units and nutrients below with your pack. You can correct any field.")}catch(e){setStatus((e as Error).message+" Manual entry is available.")}finally{wait(false)}
 }
 function submit(e:React.FormEvent){e.preventDefault();if(!checked||!name.trim())return;
  const entries:Record<string,number>={},bounds:NonNullable<NutritionPanel["bounds"]>={};
  for(const [k,raw] of Object.entries(values)){if(!raw.trim())continue;const m=raw.trim().match(/^(<=|>=|≤|≥|<|>)?\s*(\d+(?:\.\d*)?|\.\d+)$/);if(!m){setStatus("Check "+nutrients[k][0]+". Enter a number or a printed limit such as <0.1.");return}entries[k]=Number(m[2]);if(m[1])bounds[k]=(m[1]==="<="?"≤":m[1]===">="?"≥":m[1]) as "<"|"≤"|">"|"≥";}
  if(entries.kcal==null||bounds.kcal){setStatus("Enter the energy value printed on the label in kcal.");return}
  if(barcode&&!validBarcode(barcode)){setStatus("Check the barcode or leave it empty.");return}
  const result=panelSchema.safeParse({kind:"Your package",amount:Number(basis),unit,values:entries,bounds,barcode:barcode||undefined,source:source||undefined,detail:source?"Barcode lookup reviewed against your package.":"Entered from your package."});
  if(!result.success){setStatus("Check the label basis and nutrient values.");return}
  accept(makePanelFood(name.trim(),serving.trim(),Number(size),result.data,unit==="ml"?"🥛":"📦"));
 }
 const core=["kcal","p","c","f","fiber","sugar","addedSugar","satFat","transFat","sodium","potassium","calcium","iron"];
 const keys=more?Object.keys(nutrients):Object.keys(nutrients).filter(k=>core.includes(k)||values[k]);
 return <div className="package-editor"><details className="directory"><summary>Search the Indian market directory</summary><p>Search Open Food Facts for Indian products or download the November 2026 PackSense index for offline searching. Check each match against the packet.</p>
 <div className="directory-actions"><input aria-label="Search national directory" placeholder="Brand or product name" value={search} disabled={remoteBusy} onChange={e=>{setSearch(e.target.value);setRemoteResults([]);setDirectoryMessage("")}}/><button type="button" className="light" disabled={remoteBusy||search.trim().length<3} onClick={()=>void searchOnline()}>{remoteBusy?"Searching…":"Search online"}</button></div>
 <div className="market-hits">{[...new Map([...marketMatches(items,search),...remoteResults].map(h=>[h.code,h])).values()].map(r=><button type="button" disabled={fetching} key={r.code} onClick={()=>void lookup(r)}><b>{r.name}</b><small>{r.brand} · {r.code}</small></button>)}</div>
 {!items.length&&<div className="directory-actions"><button type="button" className="text-btn" disabled={loadingIndex} onClick={()=>void getIndex()}>{loadingIndex?"Loading…":"Download offline index · 5.7 MB"}</button><button type="button" className="text-btn" disabled={loadingIndex} onClick={()=>file.current?.click()}>Import index CSV</button></div>}
 <input hidden type="file" ref={file} accept=".csv,text/csv" onChange={e=>{const f=e.target.files?.[0];if(f)void getIndex(f);e.target.value=""}}/><p role="status">{directoryMessage}</p><small>Open Food Facts contributors · PackSense India · ODbL. <a href={indexRelease.url} target="_blank" rel="noreferrer">Snapshot CSV</a> · <a href={indexRelease.source} target="_blank" rel="noreferrer">Source & licence</a></small></details>
 <div className="barcode-lookup"><Field label="Package barcode (optional)"><input inputMode="numeric" value={barcode} disabled={fetching} onChange={e=>{code(e.target.value.trim());setSource("");setPicture("");setChecked(false)}} placeholder="Digits printed under the barcode"/></Field><button type="button" className="light" disabled={fetching||!barcode} onClick={()=>void lookup()}>{fetching?"Searching…":"Look up"}</button></div>
 <form onSubmit={submit}><fieldset disabled={fetching||busy}><Field label="Brand, product and flavour"><input required maxLength={100} value={name} onChange={e=>setName(e.target.value)} placeholder="As printed on the pack"/></Field>
 <div className="fields"><Field label="Label values per"><input required type="number" min=".01" max="10000" step="any" value={basis} onChange={e=>setBasis(e.target.value)}/></Field><Field label="Label unit"><select value={unit} onChange={e=>setUnit(e.target.value as "g"|"ml")}><option value="g">Grams (g)</option><option value="ml">Millilitres (ml)</option></select></Field></div>
 <div className="fields"><Field label="Serving name"><input required maxLength={100} value={serving} onChange={e=>setServing(e.target.value)}/></Field><Field label={"Serving size ("+unit+")"}><input required type="number" min=".01" max="10000" step="any" value={size} onChange={e=>setSize(e.target.value)}/></Field></div>
 <p className="note">Enter amounts per {basis||"…"} {unit}. Leave unlisted nutrients blank. Limits such as &lt;0.1 are supported.</p>
 <div className="label-inputs">{keys.map(k=><Field key={k} label={nutrients[k][0]+" ("+nutrients[k][1]+")"}><input aria-label={nutrients[k][0]+" per label"} required={k==="kcal"} value={values[k]||""} onChange={e=>setValues({...values,[k]:e.target.value})}/></Field>)}</div><button type="button" className="text-btn" onClick={()=>setMore(!more)}>{more?"Show common nutrients":"More vitamins, minerals & fats"}</button>
 {picture&&<p><a href={picture} target="_blank" rel="noreferrer">View package photo</a></p>}{source&&<small><a href={source} target="_blank" rel="noreferrer">Open Food Facts product record · ODbL</a></small>}
 <label className="label-check"><input required type="checkbox" checked={checked} onChange={e=>setChecked(e.target.checked)}/>I checked the variant, units and amounts against my package.</label><button className="primary full" disabled={!checked}>Use this label</button></fieldset></form>{status&&<p className="source-note" role="status">{status}</p>}</div>
}
