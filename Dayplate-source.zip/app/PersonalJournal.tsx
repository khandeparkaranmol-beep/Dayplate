"use client";
import Journal from "./journal";
import Backup from "./backup";
import { deviceRequest } from "./device-store";

export default function PersonalJournal() {
  return <Journal request={deviceRequest} backup={Backup}/>;
}
