"use client";
import {useState} from "react";
import {Modal,Field} from "./ui";
import {format,meals,type Stored,type Meal} from "./model";
import {previousMeals,type FoodEntry} from "./repeat";

export function RepeatMeal({rows,day,busy,close,save,meal}:{rows:Stored[],day:string,busy:boolean,close:()=>void,save:(items:FoodEntry[])=>Promise<boolean>,meal:Meal}){
 const choices=previousMeals(rows,day);
 const first=choices.findIndex(g=>g.meal===meal);
 const [which,choose]=useState(first<0?0:first);
 const group=choices[which];
 const [dest,move]=useState<Meal>(meal);
 const [groupId]=useState(()=>crypto.randomUUID());
 const initial=(i:number)=>choices[i]?.entries.map(e=>({keep:true,qty:String(e.data.quantity)}))??[];
 const [parts,setParts]=useState(()=>initial(which));
 if(!group)return <Modal title="Repeat a meal" close={close}><p>No meals in the previous 30 days.</p></Modal>;
 const items:FoodEntry[]=group.entries.flatMap((e,i)=>parts[i].keep?[{kind:"food",id:groupId+"-"+i,day,data:{...e.data,meal:dest,quantity:Number(parts[i].qty)}}]:[]);
 const valid=items.length>0&&items.every(r=>r.data.quantity>=.001&&r.data.quantity<=1000);
 return <Modal title="Repeat a meal" close={close} description={"Add to your diary for "+day+"."}><form onSubmit={e=>{e.preventDefault();if(valid)void save(items)}}>
 <Field label="Start from"><select value={which} onChange={e=>{const i=Number(e.target.value);choose(i);setParts(initial(i))}}>{choices.map((g,i)=><option key={g.day+g.meal} value={i}>{g.meal} · {g.day} · {g.entries.map(e=>e.data.food.name).join(", ").slice(0,85)}</option>)}</select></Field>
 <Field label="Add to"><select value={dest} onChange={e=>move(e.target.value as Meal)}>{meals.map(m=><option key={m}>{m}</option>)}</select></Field>
 <div className="repeat-parts">{group.entries.map((e,i)=><div key={e.id}><label><input type="checkbox" checked={parts[i].keep} onChange={ev=>setParts(p=>p.map((v,j)=>i===j?{...v,keep:ev.target.checked}:v))}/><span><b>{e.data.food.name}</b><small>{e.data.food.serving}</small></span></label><input aria-label={e.data.food.name+" servings"} type="number" min=".001" max="1000" step="any" disabled={!parts[i].keep} value={parts[i].qty} onChange={ev=>setParts(p=>p.map((v,j)=>j===i?{...v,qty:ev.target.value}:v))}/></div>)}</div>
 <div className="portion-total"><strong>{format(items.reduce((a,e)=>a+e.data.food.kcal*e.data.quantity,0))} kcal</strong><small>{items.length} selected for {dest.toLowerCase()}</small></div>
 <button className="primary full" disabled={!valid||busy}>{busy?"Saving…":"Add to "+dest.toLowerCase()}</button></form></Modal>
}
