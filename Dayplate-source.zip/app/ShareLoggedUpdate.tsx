"use client";
import {useEffect,useRef,useState} from "react";
import {Activity,Footprints,Send,Utensils} from "lucide-react";
import {SnapshotContents} from "./SnapshotContents";
import {fullVisibility} from "./snapshot-visibility";
import {daySnapshot} from "./day-snapshot";
import {DaySnapshotCard} from "./DaySnapshotCard";
import {pagesRequest} from "./pages-api";
import {loggedChoices,loggedDayLabel,shareableRecord,type LogPick,type LoggedUpdate,type UpdatePreview} from "./logged-update";
import type {Stored} from "./model";
import type {Circle} from "./social";
import {Field,Modal} from "./ui";

export function LoggedUpdateCard({update}:{update:LoggedUpdate}){
  if(update.kind==="day")return <DaySnapshotCard snapshot={update}/>;
  const Icon=update.kind==="exercise"?Activity:update.kind==="steps"?Footprints:Utensils;
  const category=update.kind==="exercise"?"Workout":update.kind==="steps"?"Movement":update.kind==="meal"?"Meal":"Food";
  return <div className="log-update-card">
    <div className="log-update-header"><span className="log-update-icon"><Icon aria-hidden="true" size={20}/></span>
      <div><small>{category} · {loggedDayLabel(update.day)}</small><h3>{update.title}</h3></div></div>
    {update.items.length>0&&<ul>{update.items.map((item,i)=><li key={i}><span>{item.name}</span><small>{item.portion}</small></li>)}</ul>}
    <dl>{update.stats.map(stat=><div key={stat.label}><dt>{stat.label}</dt><dd>{stat.value}</dd></div>)}</dl>
  </div>;
}

async function friendRequest<T>(body?:object,signal?:AbortSignal):Promise<T>{
  const res=await pagesRequest("/api/friends",body?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),signal}:{signal});
  const data=await res.json() as {error?:string};
  if(!res.ok)throw Object.assign(new Error(data.error||"Could not reach Friends. Please try again."),{status:res.status});
  return data as T;
}

export function ShareLoggedUpdate({rows,day,initial,close,shared,openFriends,personalSharing=false}:{personalSharing?:boolean;rows:Stored[];day:string;initial?:LogPick;close:()=>void;shared:(message:string)=>void;openFriends:()=>void}){
  const days=[...new Set(rows.filter(shareableRecord).map(r=>r.day))].sort().reverse();
  const [date,setDate]=useState(initial?.day??(days.includes(day)?day:days[0]??""));
  const [choice,choose]=useState(initial?JSON.stringify(initial):"");
  const options=loggedChoices(rows,date);
  const [visibility,setVisibility]=useState(fullVisibility);
  const pick:LogPick|null=choice?JSON.parse(choice):null;
  const isDay=pick?.kind==="day";
  const shareChoice=isDay&&personalSharing?JSON.stringify({...pick,visibility}):choice;
  const empty=isDay&&!daySnapshot(rows,date,visibility);
  const [peers,setPeers]=useState<string[]|null>(null),[peer,selectPeer]=useState("");
  const [preview,setPreview]=useState<(UpdatePreview&{choice:string})|null>(null);
  const [error,setError]=useState(""),[listError,setListError]=useState(""),[reload,refresh]=useState(0),[busy,setBusy]=useState(false);
  const inFlight=useRef(false),retry=useRef<{key:string;id:string}|null>(null);
  useEffect(()=>{
    const req=new AbortController();
    setListError("");
    friendRequest<Circle>(undefined,req.signal).then(circle=>{
      if(req.signal.aborted)return;
      const names=circle.people.filter(p=>p.state==="friend").map(p=>p.peer);
      setPeers(names);selectPeer(previous=>names.includes(previous)||(previous==="*"&&names.length>1)?previous:names.length===1?names[0]:"");
    }).catch(e=>{if(!req.signal.aborted)setListError(e.message)});
    return ()=>req.abort();
  },[reload]);
  useEffect(()=>{
    const req=new AbortController();
    setPreview(null);
    if(shareChoice&&!empty)friendRequest<UpdatePreview>({action:"previewPost",pick:JSON.parse(shareChoice)},req.signal)
      .then(p=>{if(!req.signal.aborted)setPreview({...p,choice:shareChoice})})
      .catch(e=>{if(!req.signal.aborted)setError(e.message)});
    return ()=>req.abort();
  },[shareChoice,empty,reload]);
  const current=preview?.choice===shareChoice&&!empty?preview:null;
  const destination=peer==="*"?"all "+(peers?.length??0)+" friends":"@"+peer;
  function changeChoice(value:string){setError("");setVisibility(fullVisibility);choose(value)}
  async function publish(){
    if(inFlight.current||!current||!peer||!peers?.length)return;
    inFlight.current=true;setBusy(true);setError("");
    const key=JSON.stringify([shareChoice,current.fingerprint,peer]);
    if(retry.current?.key!==key)retry.current={key,id:crypto.randomUUID()};
    try{
      await friendRequest({action:"post",id:retry.current.id,pick:JSON.parse(shareChoice),fingerprint:current.fingerprint,audience:peer});
      shared("Shared with "+destination+".");
    }catch(e){
      const failure=e as Error&{status?:number};
      setError(failure.message);
      if(failure.status===409||failure.status===404){setPreview(null);refresh(n=>n+1)}
    }finally{inFlight.current=false;setBusy(false)}
  }
  return <Modal title="Share from your diary" close={()=>{if(!inFlight.current)close()}}>
    {listError?<div role="alert"><p>{listError}</p><button className="light" onClick={()=>refresh(n=>n+1)}>Retry</button></div>
    :peers===null?<p role="status">Checking your friends…</p>
    :!peers.length?<div><p>Add a friend by username. Once they accept, you can share entries with them.</p><button className="primary" onClick={openFriends}>Open Friends</button></div>
    :!days.length?<p>Log a meal, workout or step count first. It will appear here when you’re ready to share it.</p>
    :<form onSubmit={e=>{e.preventDefault();void publish()}}>
      <Field label="Logged date"><select disabled={busy} value={date} onChange={e=>{setDate(e.target.value);changeChoice("")}}>{days.map(d=><option key={d} value={d}>{loggedDayLabel(d)}</option>)}</select></Field>
      <Field label="Diary entry"><select disabled={busy} value={choice} onChange={e=>changeChoice(e.target.value)}><option value="">Choose a logged entry</option>{options.map(o=>{const value=JSON.stringify(o.pick);return <option key={value} value={value}>{o.label}</option>})}</select></Field>
      <Field label="Share with"><select disabled={busy} value={peer} onChange={e=>selectPeer(e.target.value)}><option value="" disabled>Choose a friend</option>{peers.map(name=><option value={name} key={name}>@{name}</option>)}{peers.length>1&&<option value="*">All {peers.length} current friends</option>}</select></Field>
      {isDay&&personalSharing&&<SnapshotContents rows={rows} day={date} value={visibility} onChange={v=>{setError("");setVisibility(v)}} disabled={busy}/>}
      {empty?<p role="status">Choose a logged entry or a number to share.</p>:current?<div className="log-share-preview"><h4>What they’ll see</h4><LoggedUpdateCard update={current.snapshot}/></div>:choice&&!error?<p role="status">Loading your logged entry…</p>:null}
      {error&&<div className="error" role="alert">{error}{!current&&<button type="button" onClick={()=>{setError("");refresh(n=>n+1)}}>Retry preview</button>}</div>}
      <button className="primary full" disabled={!current||!peer||busy} type="submit"><Send size={16}/>{busy?"Sharing…":peer?"Share with "+destination:"Share update"}</button>
    </form>}
  </Modal>;
}
