import type {Stored} from "./model";
import {fullVisibility,snapshotFields,snapshotFieldKeys,snapshotSections,type SnapshotVisibility} from "./snapshot-visibility";

function toggle<T>(values:T[],item:T){return values.includes(item)?values.filter(v=>v!==item):[...values,item]}

export function SnapshotContents({rows,day,value,onChange,disabled=false,live=false}:{
  rows:Stored[];day:string;value:SnapshotVisibility;onChange:(next:SnapshotVisibility)=>void;disabled?:boolean;live?:boolean
}){
  const entries=rows.filter(r=>r.day===day).filter(r=>r.kind==="food"||r.kind==="exercise");
  function toggleSection(section:typeof snapshotSections[number]){
    const showNames=section!=="Workouts"&&!value.sections.includes(section)&&
      !value.fields.some(f=>f==="foodDetails"||f==="foodEnergy"||f==="protein"||f==="sugar");
    onChange({...value,sections:toggle(value.sections,section),fields:showNames?[...value.fields,"foodDetails"]:value.fields});
  }
  return <fieldset className="snapshot-contents" disabled={disabled}>
    <legend>Choose what to share</legend>
    <p>Food and workout totals use selected entries. Steps and daily active calories cover the whole day.</p>
    <div className="snapshot-selection-actions"><button type="button" className="light" onClick={()=>onChange({sections:[],fields:[],hiddenIds:[]})}>Clear selection</button>
      <button type="button" className="light" onClick={()=>onChange(fullVisibility)}>Select all</button></div>
    {snapshotSections.map(section=>{
      const items=entries.filter(r=>(r.kind==="exercise"?"Workouts":r.data.meal)===section);
      const included=value.sections.includes(section);
      if(!live&&!items.length)return null;
      return <div className="snapshot-section-choice" key={section}>
        <label><input type="checkbox" checked={included} onChange={()=>toggleSection(section)}/>{section}</label>
        {!!items.length&&included&&<details><summary>Choose entries ({items.filter(r=>!value.hiddenIds.includes(r.id)).length}/{items.length})</summary>
          {items.map(r=><label key={r.id}><input type="checkbox" checked={!value.hiddenIds.includes(r.id)} onChange={()=>onChange({...value,hiddenIds:toggle(value.hiddenIds,r.id)})}/>
            <span>{r.kind==="food"?r.data.food.name:r.data.name}<small>{r.kind==="food"?r.data.quantity+" × "+r.data.food.serving:r.data.minutes+" min"}</small></span></label>)}
        </details>}
      </div>;
    })}
    <details className="snapshot-field-choices"><summary>Numbers and details</summary>
      {snapshotFieldKeys.map(key=><label key={key}><input type="checkbox" checked={value.fields.includes(key)}
        onChange={()=>onChange({...value,fields:toggle(value.fields,key)})}/>{snapshotFields[key]}</label>)}
    </details>
    {live&&<p>New entries appear in selected meals and workouts. Hidden entries stay hidden when edited.</p>}
  </fieldset>;
}
