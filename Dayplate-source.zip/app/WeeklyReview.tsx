"use client";
import {useState} from "react";
import {ArrowUpRight,CalendarDays} from "lucide-react";
import {type Stored,format} from "./model";
import {nutrients} from "./nutrition";
import {nutrientName} from "./MealNutrients";
import {shortDay,rounded,weekStory,breakfastNotes,boxingLabel} from "./week-story";

function Change({points,unit}:{points:{day:string,value:number}[],unit:string}){
  if(!points.length)return <>No measurements</>;
  const first=points[0],last=points[points.length-1];
  if(first.day===last.day)return <>{last.value} {unit} · one date</>;
  return <>{first.value} → {last.value} {unit}<small>{shortDay(first.day)} – {shortDay(last.day)}</small></>;
}
export function WeeklyReview({rows,day,keys,openDay,configure}:{rows:Stored[],day:string,keys:string[],openDay:(d:string)=>void,configure:()=>void}){
  const week=weekStory(rows,day,keys),[picked,pick]=useState("");
  const key=keys.includes(picked)?picked:keys[0]??"kcal";
  const notes=breakfastNotes(week,key),boxing=week.sessions.filter(r=>r.data.boxing);
  const dayOfWeek=(d:string)=>new Date(d+"T12:00:00").toLocaleDateString("en-IN",{weekday:"short"});
  return <section className="panel week-story">
    <div className="section-head"><div><div className="week-range"><CalendarDays size={15}/>{shortDay(week.start)} – {shortDay(day)}</div><h2>Your weekly review</h2></div><button className="text-btn" onClick={configure}>Choose nutrients</button></div>
    <div className="week-days">{week.daily.map(d=><button key={d.day} aria-label={d.day+" · "+(d.complete?"Complete":d.foods.length?"Partial":"No food logged")+". Open diary"} onClick={()=>openDay(d.day)}><span>{dayOfWeek(d.day)}</span><i className={d.complete?"finished":d.foods.length?"partial":""}/></button>)}</div>
    <p>{week.complete} complete · {week.logged-week.complete} partially logged · {7-week.logged} without food logs</p>
    <div className="week-facts"><div><small>Workouts logged</small><b>{week.sessions.length} · {format(week.minutes)} min</b></div><div><small>Weight</small><b><Change points={week.weights} unit="kg"/></b></div><div><small>Waist</small><b><Change points={week.waists} unit="cm"/></b></div></div>
    {keys.length>0&&<><h3>Average per complete day</h3><div className="week-facts">{week.averages.map(a=><div key={a.key}><small>{nutrientName(a.key)}</small><b>{a.value==null?"—":rounded(a.value)+" "+nutrients[a.key][1]}</b><small>{a.days} of {week.complete} complete days usable</small></div>)}</div>
    <p className="note">An average uses days you marked complete where every food has a numeric value for that nutrient. Recipe values are estimates.</p></>}
    <div className="week-question"><h3>What did breakfast contribute?</h3>{keys.length>1&&<select aria-label="Compare breakfast nutrient" value={key} onChange={e=>pick(e.target.value)}>{keys.map(k=><option key={k} value={k}>{nutrientName(k)}</option>)}</select>}</div>
    {notes.length>0?<><p className="note">{notes.length} {notes.length===1?"breakfast":"breakfasts"} with {nutrientName(key).toLowerCase()} totals on complete days. Open a meal to inspect the portions.</p><div className="week-evidence">{notes.map(d=><button key={d.day} onClick={()=>openDay(d.day)}><span><small>{shortDay(d.day)}</small>{d.names}</span><b>{rounded(d.value)} {nutrients[key][1]}</b><ArrowUpRight size={14}/></button>)}</div></>:<p className="note">Log breakfast and mark the day complete in your journal to compare meals here.</p>}
    {boxing.length>0&&<><h3>Boxing sessions</h3><div className="week-evidence">{boxing.map(r=><button key={r.id} onClick={()=>openDay(r.day)}><span><small>{shortDay(r.day)} · {r.data.name}</small>{boxingLabel(r.data.boxing!)}</span><ArrowUpRight size={14}/></button>)}</div></>}
  </section>;
}
