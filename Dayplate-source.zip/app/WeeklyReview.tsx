"use client";
import {useState} from "react";
import {ArrowUpRight,CalendarDays} from "lucide-react";
import {type Stored,format} from "./model";
import {nutrients} from "./nutrition";
import {nutrientName} from "./MealNutrients";
import {shortDay,rounded,weekStory,breakfastNotes,boxingLabel} from "./week-story";

function Change({points,unit}:{points:{day:string,value:number}[],unit:string}){
  if(!points.length)return <>No measurements</>;
  const first=points[0],last=points[points.length-1];
  if(first.day===last.day)return <>{last.value} {unit} · one date</>;
  return <>{first.value} → {last.value} {unit}<small>{shortDay(first.day)} – {shortDay(last.day)}</small></>;
}
export function WeeklyReview({rows,day,keys,openDay,configure}:{rows:Stored[],day:string,keys:string[],openDay:(d:string)=>void,configure:()=>void}){
  const week=weekStory(rows,day,keys),[picked,pick]=useState("");
  const key=keys.includes(picked)?picked:keys[0]??"kcal";
  const notes=breakfastNotes(week,key),boxing=week.sessions.filter(r=>r.data.boxing);
  const dayOfWeek=(d:string)=>new Date(d+"T12:00:00").toLocaleDateString("en-IN",{weekday:"short"});
  return <section className="panel week-story">
    <header className="week-title"><div className="week-range"><CalendarDays size={16}/>{shortDay(week.start)} – {shortDay(day)}</div><h2>Your weekly review</h2></header>
    {!week.logged&&!week.sessions.length&&!week.weights.length&&!week.waists.length?<div className="week-first"><p>Your first meal, workout or weigh-in starts this week’s story.</p><button className="light" onClick={()=>openDay(day)}>Open this day’s journal</button></div>:<>
    <div className="week-days">{week.daily.map(d=><button key={d.day} aria-label={d.day+" · "+(d.complete?"Complete":d.foods.length?"Partial":"No food logged")+". Open diary"} onClick={()=>openDay(d.day)}><span>{dayOfWeek(d.day)}</span><i className={d.complete?"finished":d.foods.length?"partial":""}/></button>)}</div>
    <p className="week-caption">{week.logged?week.complete===week.logged?week.complete+" complete "+(week.complete===1?"day":"days")+" logged.":week.complete+" complete · "+(week.logged-week.complete)+" partially logged.":"No meals logged this week."}</p>
    {(!!week.sessions.length||!!week.weights.length||!!week.waists.length)&&<div className="week-readings">
      {!!week.sessions.length&&<div><small>Movement</small><b>{format(week.minutes)} min</b><small>{week.sessions.length} {week.sessions.length===1?"workout":"workouts"}</small></div>}
      {!!week.weights.length&&<div><small>Weight</small><b><Change points={week.weights} unit="kg"/></b></div>}
      {!!week.waists.length&&<div><small>Waist</small><b><Change points={week.waists} unit="cm"/></b></div>}
    </div>}
    <section className="review-section"><header><h3>Daily nutrient averages</h3><button className="light" onClick={configure}>Choose nutrients</button></header>
    {week.complete>0&&keys.length>0?<><div className="week-readings">{week.averages.map(a=><div key={a.key}><small>{nutrientName(a.key)}</small><b>{a.value==null?"Unlisted":rounded(a.value)+" "+nutrients[a.key][1]}</b>{a.days!==week.complete&&<small>{a.days} of {week.complete} days with values</small>}</div>)}</div>
    <details className="review-method"><summary>Based on {week.complete} complete {week.complete===1?"day":"days"}</summary><p>Each average uses days marked complete where every logged food listed that nutrient. Recipe values are estimates.</p></details></>:<p>{keys.length?"Mark a day complete to see your averages.":"Choose the nutrients you want to follow."}</p>}</section>
    <details className="breakfast-detail"><summary>What did breakfast contribute?</summary>
    {keys.length>1&&<select aria-label="Compare breakfast nutrient" value={key} onChange={e=>pick(e.target.value)}>{keys.map(k=><option key={k} value={k}>{nutrientName(k)}</option>)}</select>}
    {notes.length>0?<div className="week-evidence">{notes.map(d=><button key={d.day} onClick={()=>openDay(d.day)}><span><small>{shortDay(d.day)}</small>{d.names}</span><b>{rounded(d.value)} {nutrients[key][1]}</b><ArrowUpRight size={14}/></button>)}</div>:<p>Log breakfast and mark the day complete to compare meals here.</p>}</details>
    {boxing.length>0&&<><h3>Boxing sessions</h3><div className="week-evidence">{boxing.map(r=><button key={r.id} onClick={()=>openDay(r.day)}><span><small>{shortDay(r.day)} · {r.data.name}</small>{boxingLabel(r.data.boxing!)}</span><ArrowUpRight size={14}/></button>)}</div></>}
    </>}
  </section>;
}
