"use client";
import {useState} from "react";
import {dateKey,format,type Stored} from "./model";
import type {Commit} from "./forms";
import {Modal,Field} from "./ui";
import {estimateActive,matchWorkout,workoutTypes,workoutWeight,type Workout} from "./workout-energy";

export function WorkoutForm({day,rows,edit,busy,close,save}:{day:string,rows:Stored[],edit?:Workout,busy:boolean,close:()=>void,save:Commit}){
  const [id]=useState(()=>edit?.id??crypto.randomUUID());
  const [date,setDate]=useState(edit?.day??day);
  const original=edit?.data;
  const initialType=original&&matchWorkout(original.basis?.activity??original.name)?.name;
  const [type,setType]=useState(original?(initialType===original.name?initialType:"custom"):"");
  const [name,setName]=useState(original?.name??"");
  const [similar,setSimilar]=useState(initialType??"");
  const [minutes,setMinutes]=useState(original?String(original.minutes):"");
  const [weight,setWeight]=useState(original?.basis?.kg?.toString());
  const [roundsOn,setRoundsOn]=useState(!!original?.boxing);
  const [rounds,setRounds]=useState(String(original?.boxing?.rounds??3)),[length,setLength]=useState(String(original?.boxing?.roundMinutes??3));
  const [rest,setRest]=useState(String(original?.boxing?.restSeconds??60)),[effort,setEffort]=useState(String(original?.boxing?.effort??""));
  const kg=weight??String(workoutWeight(rows,date)??"");
  const activity=matchWorkout(type==="custom"?similar:type);
  const device=original?.health?.activeKcal;
  const imported=!!original?.health;
  const validWeight=Number(kg)>=20&&Number(kg)<=500;
  const count=Number(minutes);
  const isBoxing=activity?.name.startsWith("Boxing")||type==="custom"&&/boxing|sparring|bag work/i.test(name);
  const boxing=roundsOn&&isBoxing?{rounds:Number(rounds),roundMinutes:Number(length),restSeconds:Number(rest),effort:Number(effort)}:undefined;
  const roundTime=boxing?boxing.rounds*boxing.roundMinutes:0;
  const kcal=device??(activity&&validWeight&&count>0?estimateActive(activity.met,Number(kg),count):undefined);
  const choices=workoutTypes.map(w=><option key={w.name}>{w.name}</option>);
  return <Modal close={close} title={edit?"Workout details":"Log workout"}>
    <form onSubmit={e=>{
      e.preventDefault();
      const workoutName=type==="custom"?name.trim():type;
      if(!workoutName||roundTime>count)return;
      const basis=activity?{activity:activity.name,...(validWeight?{kg:Number(kg)}:{})}:undefined;
      void save({id,day:date,kind:"exercise",data:{name:workoutName,minutes:count,basis,boxing,health:original?.health}},"Workout saved");
    }}>
      <Field label="Date"><input required disabled={imported} type="date" max={dateKey()} value={date} onChange={e=>{setDate(e.target.value);setWeight(undefined)}}/></Field>
      <Field label="Workout"><select required disabled={imported} value={type} onChange={e=>setType(e.target.value)}><option value="">Choose a workout</option>{choices}<option value="custom">Other workout</option></select></Field>
      {type==="custom"&&<><Field label="Workout name"><input required disabled={imported} value={name} maxLength={100} onChange={e=>setName(e.target.value)}/></Field>
      {device==null&&<Field label="Similar activity for calorie estimate"><select value={similar} onChange={e=>setSimilar(e.target.value)}><option value="">Log duration only</option>{choices}</select></Field>}</>}
      <div className="fields"><Field label="Duration (minutes)"><input type="number" required disabled={imported} min={0.01} max={1440} step="any" value={minutes} onChange={e=>setMinutes(e.target.value)}/></Field>
      {device==null&&<Field label="Body weight (kg)"><input type="number" min={20} max={500} step="any" placeholder="For this estimate" value={kg} onChange={e=>setWeight(e.target.value)}/></Field>}</div>
      {isBoxing&&<div className="boxing-setup"><label className="check-label"><input type="checkbox" checked={roundsOn} onChange={e=>setRoundsOn(e.target.checked)}/> Record boxing rounds</label>{roundsOn&&<>
      <div className="fields"><Field label="Rounds completed"><input required type="number" min="1" max="200" value={rounds} onChange={e=>setRounds(e.target.value)}/></Field><Field label="Minutes per round"><input required type="number" min=".01" max="60" step="any" value={length} onChange={e=>setLength(e.target.value)}/></Field></div>
      <div className="fields"><Field label="Rest between rounds (seconds)"><input required type="number" min="0" max="3600" step="any" value={rest} onChange={e=>setRest(e.target.value)}/></Field><Field label="Perceived effort (1–10)"><input required type="number" min="1" max="10" value={effort} onChange={e=>setEffort(e.target.value)} placeholder="1 easy · 10 hardest"/></Field></div>
      {roundTime>count&&<p className="note">Round time exceeds the session duration. Check the duration or rounds.</p>}</>}</div>}
      <div className="workout-burn" role="status"><small>{device!=null?"Active calories from Apple Health":"Estimated active calories"}</small><strong>{kcal==null?"—":format(kcal)} <span>kcal</span></strong>
      <small>{device!=null?"Reported for this workout":!activity?"Choose a matching activity.":!validWeight?"Enter your weight to see an estimate.":count<=0?"Enter the workout duration.":activity.name+" · "+kg+" kg"}</small></div>
      {device==null&&<details className="method"><summary>How is this estimated?</summary><p>Dayplate estimates calories burned above rest from your weight, duration and the typical intensity of the activity you selected. Pace and breaks can change your actual burn.</p><a href="https://pacompendium.com/adult-compendium/" target="_blank" rel="noreferrer">2024 Adult Compendium of Physical Activities</a></details>}
      <button className="primary full" type="submit" disabled={busy||roundTime>count||!type||(type==="custom"&&!name.trim())}>{busy?"Saving…":"Save workout"}</button>
    </form>
  </Modal>;
}
