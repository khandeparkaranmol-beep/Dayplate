import {env} from "cloudflare:workers";
import {cookies} from "next/headers";
import {getChatGPTUser} from "./chatgpt-auth";
import {digest} from "../lib/google-token";
export const googleClient=()=>String((env as unknown as {GOOGLE_CLIENT_ID?:string}).GOOGLE_CLIENT_ID||"").trim();
export const sessionCookie="__Host-dayplate_session",nonceCookie="__Host-dayplate_nonce";
export const cookieOptions={httpOnly:true,secure:true,sameSite:"lax" as const,path:"/"};
export async function getDiaryUser(){
 const jar=await cookies(),token=jar.get(sessionCookie)?.value;
 if(token&&/^[0-9a-f]{64}$/.test(token)){
   const session=await env.DB!.prepare("SELECT owner FROM google_sessions WHERE digest=? AND expires>?").bind(await digest(token),Date.now()).first<{owner:string}>();
   if(session)return {userId:session.owner,provider:"google"};
 }
 const legacy=await getChatGPTUser();return legacy?{userId:legacy.userId,provider:"chatgpt"}:null;
}
