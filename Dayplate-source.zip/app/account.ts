import {env} from "cloudflare:workers";
import {digest} from "../lib/google-token";
export const googleClient = () => String((env as unknown as {GOOGLE_CLIENT_ID?: string}).GOOGLE_CLIENT_ID || "").trim();
export function sessionToken(req: Request) {
  return req.headers.get("authorization")?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
}
export async function getDiaryUser(req: Request) {
  const token = sessionToken(req);
  if (!token) return null;
  const session = await env.DB!.prepare(`SELECT CASE WHEN a.owner LIKE 'device:%' THEN d.owner ELSE a.owner END AS owner
    FROM google_sessions a LEFT JOIN google_sessions d ON d.digest=a.owner AND d.expires>? WHERE a.digest=? AND a.expires>?`)
    .bind(Date.now(), await digest(token), Date.now()).first<{owner: string}>();
  return session?.owner?.startsWith("google:") ? {userId: session.owner} : null;
}
