import {z} from "zod";
import {recordSchema,estimate,type Entry} from "./model";
export function canonical(entry:Entry){
 if(["weight","target","review","measure","activity","routine","variety","crewDay"].includes(entry.kind)&&entry.id!==entry.kind+"-"+entry.day)return false;
 if(entry.kind==="hunger"&&entry.id!=="h-"+entry.data.experiment+"-"+entry.day)return false;
 if(entry.kind==="experiment"&&(!z.string().uuid().safeParse(entry.id).success||(entry.data.end&&entry.data.end<entry.day)))return false;
 if(entry.kind==="target"&&entry.data.profile){const e=estimate(entry.data.profile);if(!e.safe||e.target!==entry.data.calories)return false}
 return true;
}
export const workoutBatch=z.object({action:z.literal("healthImport"),entries:z.array(recordSchema.refine(e=>canonical(e)&&(e.kind==="activity"||e.kind==="exercise"&&e.data.health&&e.id==="apple-"+e.data.health.uuid))).min(1).max(100)});
export const restoreBatch=z.object({action:z.literal("restore"),entries:z.array(recordSchema.and(z.object({revision:z.number().int().positive()})).refine(canonical)).min(1).max(50)});
export type JournalRequest=(url:string,init?:RequestInit)=>Promise<Response>;
export async function sendEntries(request:JournalRequest,action:"healthImport"|"restore",entries:Entry[]){
 const size=action==="restore"?25:75;
 for(let i=0;i<entries.length;){
   let end=Math.min(i+size,entries.length);
   while(end>i+1&&JSON.stringify(entries.slice(i,end)).length>600000)end=i+Math.ceil((end-i)/2);
  const response=await request("/api/journal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,entries:entries.slice(i,end)})});
  i=end;
   if(!response.ok)throw Error("Some entries could not be saved. You can retry this import without duplicating entries.");
 }
}
