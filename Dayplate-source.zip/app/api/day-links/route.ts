import {env} from "cloudflare:workers";
import {dayLink} from "../../../lib/day-links";
import {pagesOrigin} from "../../../lib/pages-origin";
import {getDiaryUser} from "../../account";
export const dynamic="force-dynamic";
export async function POST(request:Request){
  if(request.headers.get("origin")!==pagesOrigin)return Response.json({error:"Invalid origin."},{status:403});
  const text=await request.text();
  if(text.length>100000)return Response.json({error:"Too large."},{status:413});
  let body;
  try{body=JSON.parse(text)}catch{return Response.json({error:"Invalid request."},{status:400})}
  const user=body?.action==="read"?null:await getDiaryUser(request);
  return dayLink(env.DB!,user?.userId??null,body);
}
