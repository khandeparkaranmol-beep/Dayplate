import {pagesOrigin} from "../../../lib/pages-origin";
import {env} from "cloudflare:workers";
import {getDiaryUser} from "../../account";
import {social} from "../../../lib/friends";
export const dynamic="force-dynamic";
export async function GET(request:Request){return social(env.DB!,(await getDiaryUser(request))?.userId||null)}
export async function POST(request:Request){
 const origin=request.headers.get("origin");
 if(origin!==pagesOrigin)return Response.json({error:"Invalid origin."},{status:403});
 const body=await request.text();if(body.length>3000)return Response.json({error:"Too large."},{status:413});
 let value;try{value=JSON.parse(body)}catch{return Response.json({error:"Invalid request."},{status:400})}
 return social(env.DB!,(await getDiaryUser(request))?.userId||null,value);
}
