import {env} from "cloudflare:workers";
import {sessionToken} from "../../../account";
import {digest,randomToken} from "../../../../lib/google-token";
import {pagesOrigin} from "../../../../lib/pages-origin";
import {accessLifetime,deviceAlgorithm,deviceLifetime,deviceMessage,proofAlgorithm,unhex} from "../../../../lib/remembered-browser";

const reply=(status:number,body:object={})=>Response.json(body,{status,headers:{"Cache-Control":"no-store"}});
export async function POST(req:Request){
  if(req.headers.get("origin")!==pagesOrigin||!req.headers.get("content-type")?.startsWith("application/json"))return reply(403);
  const raw=await req.text();
  if(raw.length>1400)return reply(413);
  let input;
  try{input=JSON.parse(raw)}catch{return reply(400)}
  if(!input||typeof input.publicKey!=="string"||!/^04[0-9a-f]{128}$/.test(input.publicKey))return reply(400);
  let key;
  try{key=await crypto.subtle.importKey("raw",unhex(input.publicKey),deviceAlgorithm,false,["verify"])}catch{return reply(400)}
  const db=env.DB!,device="device:"+await digest(input.publicKey),now=Date.now();
  if(input.action==="remember"){
    const token=sessionToken(req);
    if(!token)return reply(401);
    const access=await digest(token);
    // Only a Google-authenticated session can enroll a key. Bind its original access
    // token to the same device so sign-out revokes earlier tabs as well.
    const [,bound]=await db.batch([
      db.prepare("INSERT OR IGNORE INTO google_sessions(digest,owner,expires) SELECT ?,owner,? FROM google_sessions WHERE digest=? AND owner LIKE 'google:%' AND expires>?").bind(device,now+deviceLifetime,access,now),
      db.prepare("UPDATE google_sessions SET owner=? WHERE digest=? AND expires>? AND EXISTS (SELECT 1 FROM google_sessions d WHERE d.digest=? AND d.owner=google_sessions.owner AND d.expires>?)").bind(device,access,now,device,now)
    ]);
    return reply(bound.meta.changes===1?200:401);
  }
  if(input.action!=="resume"||typeof input.verifier!=="string"||!/^[a-f0-9]{64}$/.test(input.verifier)||typeof input.proof!=="string"||!/^[a-f0-9]{128}$/.test(input.proof))return reply(400);
  const nonce=await digest(input.verifier);
  if(!await crypto.subtle.verify(proofAlgorithm,key,unhex(input.proof),deviceMessage(nonce)))return reply(401);
  const token=randomToken(),access=await digest(token);
  const [created]=await db.batch([
    db.prepare("UPDATE google_sessions SET digest=?,owner=?,expires=? WHERE digest=? AND owner='challenge' AND expires>? AND EXISTS (SELECT 1 FROM google_sessions d WHERE d.digest=? AND d.expires>?)").bind(access,device,now+accessLifetime,"nonce:"+nonce,now,device,now),
    db.prepare("UPDATE google_sessions SET expires=? WHERE digest=? AND EXISTS (SELECT 1 FROM google_sessions a WHERE a.digest=? AND a.owner=?)").bind(now+deviceLifetime,device,access,device)
  ]);
  if(created.meta.changes===1)return reply(200,{token});
  const active=await db.prepare("SELECT 1 FROM google_sessions WHERE digest=? AND expires>?").bind(device,now).first();
  return reply(active?409:410);
}
