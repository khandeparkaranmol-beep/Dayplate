import {cookies} from "next/headers";
import {nonceCookie,cookieOptions,googleClient} from "../../../account";
import {randomToken} from "../../../../lib/google-token";
export const dynamic="force-dynamic";
export async function GET(){const client=googleClient();if(!client)return Response.json({error:"Google sign-in is awaiting configuration."},{status:503,headers:{"Cache-Control":"no-store"}});const nonce=randomToken();(await cookies()).set(nonceCookie,nonce,{...cookieOptions,maxAge:600});return Response.json({nonce,client},{headers:{"Cache-Control":"private, no-store"}})}
