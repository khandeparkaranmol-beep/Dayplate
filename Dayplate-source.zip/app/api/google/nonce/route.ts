import {env} from "cloudflare:workers";
import {googleClient} from "../../../account";
import {randomToken,digest} from "../../../../lib/google-token";
import {pagesOrigin} from "../../../../lib/pages-origin";
export const dynamic="force-dynamic";
export async function GET(req: Request) {
  if(req.headers.get("origin") !== pagesOrigin) return new Response(null,{status:403});
  const client = googleClient();
  if (!client) return Response.json({error:"Google sign-in is awaiting configuration."},{status:503});
  const verifier = randomToken(), nonce = await digest(verifier), now = Date.now();
  await env.DB!.batch([
    env.DB!.prepare("DELETE FROM google_sessions WHERE expires<=?").bind(now),
    env.DB!.prepare("INSERT INTO google_sessions(digest,owner,expires) VALUES(?,?,?)").bind("nonce:"+nonce,"challenge",now+600000)
  ]);
  return Response.json({client,nonce,verifier},{headers:{"Cache-Control":"no-store"}});
}
