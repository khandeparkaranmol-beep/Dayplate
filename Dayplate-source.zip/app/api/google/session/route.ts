import {env} from "cloudflare:workers";
import {googleClient} from "../../../account";
import {randomToken,digest,verifyGoogle} from "../../../../lib/google-token";
import {accessLifetime} from "../../../../lib/remembered-browser";
import {pagesOrigin} from "../../../../lib/pages-origin";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== pagesOrigin || !req.headers.get("content-type")?.startsWith("application/json"))
    return new Response(null,{status:403});
  const body = await req.text();
  if (body.length > 12000) return new Response(null,{status:413});
  let owner: string, nonce: string;
  try {
    const {credential,verifier} = JSON.parse(body);
    if (typeof verifier !== "string" || !/^[a-f0-9]{64}$/.test(verifier)) throw Error();
    nonce = await digest(verifier);
    owner = await verifyGoogle(credential,googleClient(),nonce);
  } catch { return Response.json({error:"Google sign-in could not be verified."},{status:401}); }
  const token = randomToken(), now = Date.now();
  const result = await env.DB!.prepare("UPDATE google_sessions SET digest=?,owner=?,expires=? WHERE digest=? AND owner='challenge' AND expires>?")
    .bind(await digest(token),owner,now+accessLifetime,"nonce:"+nonce,now).run();
  if (result.meta.changes !== 1) return Response.json({error:"Refresh and sign in again."},{status:401});
  return Response.json({token},{headers:{"Cache-Control":"no-store"}});
}
