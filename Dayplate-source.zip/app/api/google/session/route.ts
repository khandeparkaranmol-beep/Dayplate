import {env} from "cloudflare:workers";
import {cookies} from "next/headers";
import {nonceCookie,sessionCookie,cookieOptions,googleClient} from "../../../account";
import {randomToken,digest,verifyGoogle} from "../../../../lib/google-token";
export async function POST(req:Request){
 const client=googleClient();if(!client)return Response.json({error:"Google sign-in is awaiting configuration."},{status:503});
 if(req.headers.get("origin")!==new URL(req.url).origin||!req.headers.get("content-type")?.startsWith("application/json"))return Response.json({error:"Invalid origin."},{status:403});
 const text=await req.text();if(text.length>12000)return new Response(null,{status:413});
 const jar=await cookies(),nonce=jar.get(nonceCookie)?.value||"";if(!/^[0-9a-f]{64}$/.test(nonce))return Response.json({error:"Refresh and sign in again."},{status:401});
 let owner;try{const {credential}=JSON.parse(text);owner=await verifyGoogle(credential,client,nonce)}catch{return Response.json({error:"Google sign-in could not be verified. Refresh and try again."},{status:401})}
 const token=randomToken(),age=30*86400,now=Date.now();
 await env.DB!.batch([env.DB!.prepare("DELETE FROM google_sessions WHERE expires<=?").bind(now),env.DB!.prepare("INSERT INTO google_sessions(digest,owner,expires) VALUES(?,?,?)").bind(await digest(token),owner,now+age*1000)]);
 jar.set(nonceCookie,"",{...cookieOptions,maxAge:0});jar.set(sessionCookie,token,{...cookieOptions,maxAge:age});
 return Response.json({saved:true},{headers:{"Cache-Control":"no-store"}});
}
