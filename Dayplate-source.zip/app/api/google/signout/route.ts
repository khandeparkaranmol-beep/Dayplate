import {env} from "cloudflare:workers";
import {sessionToken} from "../../../account";
import {digest} from "../../../../lib/google-token";
import {pagesOrigin,journalURL} from "../../../../lib/pages-origin";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== pagesOrigin) return new Response(null,{status:403});
  const token = sessionToken(req);
  if(!token)return new Response(null,{status:401});
  {
    const db=env.DB!,access=await digest(token);
    const [,removed]=await db.batch([
      db.prepare("DELETE FROM google_sessions WHERE digest LIKE 'device:%' AND digest=(SELECT owner FROM google_sessions WHERE digest=?)").bind(access),
      db.prepare("DELETE FROM google_sessions WHERE digest=?").bind(access)
    ]);
    if(!removed.meta.changes)return new Response(null,{status:401});
  }
  return Response.json({next:journalURL},{headers:{"Cache-Control":"no-store"}});
}
