import {env} from "cloudflare:workers";
import {sessionToken} from "../../../account";
import {digest} from "../../../../lib/google-token";
import {pagesOrigin,journalURL} from "../../../../lib/pages-origin";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== pagesOrigin) return new Response(null,{status:403});
  const token = sessionToken(req);
  if (token) await env.DB!.prepare("DELETE FROM google_sessions WHERE digest=?").bind(await digest(token)).run();
  return Response.json({next:journalURL},{headers:{"Cache-Control":"no-store"}});
}
