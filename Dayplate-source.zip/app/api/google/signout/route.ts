import {cookies} from "next/headers";
import {env} from "cloudflare:workers";
import {sessionCookie,cookieOptions} from "../../../account";
import {digest} from "../../../../lib/google-token";
export async function POST(req:Request){
 if(req.headers.get("origin")!==new URL(req.url).origin)return new Response(null,{status:403});
 const jar=await cookies(),token=jar.get(sessionCookie)?.value;
 if(token){await env.DB!.prepare("DELETE FROM google_sessions WHERE digest=?").bind(await digest(token)).run();jar.set(sessionCookie,"",{...cookieOptions,maxAge:0});return Response.json({next:"/"})}
 return Response.json({next:"/signout-with-chatgpt?return_to=%2F"});
}
