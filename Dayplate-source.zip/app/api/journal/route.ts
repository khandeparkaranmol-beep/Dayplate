import { env } from "cloudflare:workers";
import { z } from "zod";
import { getChatGPTUser } from "../../chatgpt-auth";
import {canonical,restoreBatch,workoutBatch} from "../../activity-records";
import {repeatSchema,sameEntry} from "../../repeat";
import {type Stored,recordSchema, estimate } from "../../model";
export const dynamic="force-dynamic";
const success=(data:unknown,status=200)=>Response.json(data,{status,headers:{"Cache-Control":"private, no-store"}});
export async function GET() {
  const owner=(await getChatGPTUser())?.userId;
  if(!owner) return success({error:"Sign in to open your diary."},401);
  const rows=await env.DB!.prepare("SELECT id,kind,day,data,revision FROM journal_records WHERE owner=? ORDER BY day, rowid").bind(owner).all<{id:string,kind:string,day:string,data:string,revision:number}>();
  return success(rows.results.map(r=>({...r,data:JSON.parse(r.data)})));
}
const mutation=z.discriminatedUnion("action",[
  z.object({action:z.literal("put"),entry:recordSchema,revision:z.number().int().min(0)}),
  z.object({action:z.literal("delete"),id:z.string().min(1).max(80),revision:z.number().int().positive()})
]);
export async function POST(request:Request) {
  const owner=(await getChatGPTUser())?.userId;
  if(!owner)return success({error:"Sign in to update your diary."},401);
  const origin=request.headers.get("origin");
  if(origin && origin!==new URL(request.url).origin && new URL(origin).host!==request.headers.get("host"))return success({error:"Invalid origin."},403);
  const body=await request.text();
  if(body.length>640000)return success({error:"Entry is too long."},413);
  let raw; try{raw=JSON.parse(body)}catch{return success({error:"Invalid entry."},400)}
  if(raw?.action==="restore"||raw?.action==="healthImport"){
   const restore=raw.action==="restore",parsed=restore?restoreBatch.safeParse(raw):workoutBatch.safeParse(raw);
   if(!parsed.success)return success({error:"Invalid import."},400);
   const db=env.DB!;
   const conflict=restore?"DO NOTHING":"DO UPDATE SET data=json_patch(journal_records.data,excluded.data),revision=journal_records.revision+1 WHERE journal_records.kind=excluded.kind AND journal_records.data<>json_patch(journal_records.data,excluded.data)";
   const statement=db.prepare("INSERT INTO journal_records(owner,id,kind,day,data,revision) VALUES(?,?,?,?,?,?) ON CONFLICT(owner,id) "+conflict);
   await db.batch(parsed.data.entries.map(e=>statement.bind(owner,e.id,e.kind,e.day,JSON.stringify(e.data),restore&&"revision" in e?e.revision:1)));
   return success({saved:true});
 }
 if(raw?.action==="repeat"){
   const parsed=repeatSchema.safeParse(raw);
   if(!parsed.success)return success({error:"Review your meal and portions."},400);
   const rows=parsed.data.entries,db=env.DB!;
   try{
     await db.prepare("INSERT INTO journal_records(owner,id,kind,day,data,revision) SELECT ?,json_extract(value,'$.id'),'food',json_extract(value,'$.day'),json_extract(value,'$.data'),1 FROM json_each(?)").bind(owner,JSON.stringify(rows)).run();
   }catch(err){
     const seen=await db.prepare("SELECT id,day,kind,data,revision FROM journal_records WHERE owner=? AND id IN (SELECT value FROM json_each(?))").bind(owner,JSON.stringify(rows.map(r=>r.id))).all<{id:string,day:string,kind:string,data:string,revision:number}>();
     if(!seen.results.length)throw err;
     const existing=new Map(seen.results.map(r=>[r.id,{...r,data:JSON.parse(r.data)} as Stored]));
     if(!rows.every(r=>existing.has(r.id)&&sameEntry(existing.get(r.id)!,r)))return success({error:"This meal has changed. Reopen it to review."},409);
   }
   return success({revision:1});
 }
 if(body.length>16000)return success({error:"Entry is too long."},413);
 const parsed=mutation.safeParse(raw);
  if(!parsed.success)return success({error:"Check the serving, date, and values."},400);
  const change=parsed.data,db=env.DB!;
  let result;
  if(change.action==="delete") {
    result=await db.prepare("DELETE FROM journal_records WHERE owner=? AND id=? AND revision=?").bind(owner,change.id,change.revision).run();
  } else {
    const {id,kind,day,data}=change.entry;
    if(!canonical(change.entry))return success({error:"Invalid daily record."},400);
    if(change.entry.kind==="target"&&change.entry.data.profile) {
      const e=estimate(change.entry.data.profile);
      if(!e.safe||e.target!==change.entry.data.calories)return success({error:"Check your calorie estimate."},400);
    }
    const json=JSON.stringify(data);
    result=change.revision===0
      ?await db.prepare("INSERT INTO journal_records(owner,id,kind,day,data,revision) VALUES(?,?,?,?,?,1) ON CONFLICT(owner,id) DO NOTHING").bind(owner,id,kind,day,json).run()
      :await db.prepare("UPDATE journal_records SET data=?,day=?,revision=revision+1 WHERE owner=? AND id=? AND kind=? AND revision=?").bind(json,day,owner,id,kind,change.revision).run();
  }
  if(result.meta.changes!==1)return success({error:"This entry changed on another device. Review the refreshed diary and try again."},409);
  return success({revision:change.revision+1});
}
