"use client";
import { useState,useRef } from "react";
import { Download,Upload } from "lucide-react";
import { Modal } from "./ui";
import {exportBackup,importBackup} from "./device-store";
export default function Backup({close,refresh}:{close:()=>void,refresh:()=>Promise<void>}) {
 const [message,setMessage]=useState(""),[working,setWorking]=useState(false),input=useRef<HTMLInputElement>(null);
 async function run(fn:()=>Promise<void>){setWorking(true);setMessage("");try{await fn()}catch(e){setMessage((e as Error).message)}finally{setWorking(false)}}
 return <Modal close={()=>{if(!working)close()}} title="Backup & restore" description="Your diary is stored on this device. Export a copy to keep it when switching browsers or devices.">
 <div className="backup-buttons"><button className="primary full" disabled={working} onClick={()=>void run(async()=>{await exportBackup();setMessage("Backup download started.")})}><Download size={16}/>Export diary</button><button className="light full" disabled={working} onClick={()=>input.current?.click()}><Upload size={16}/>Import backup</button></div><input ref={input} type="file" accept=".json,application/json" hidden onChange={e=>{const f=e.target.files?.[0];if(!f)return;e.target.value="";void run(async()=>{const r=await importBackup(f);await refresh();setMessage("Imported "+r.added+" entries. "+r.skipped+" existing entries kept.")})}}/><p className="note">Import adds missing entries and keeps the records already on this device.</p>{message&&<div className="portion-total" role="status">{message}</div>}</Modal>
}
