import type {Food} from "./model";

export const sharingOptions = {
  completion:"Goal completion only",
  progress:"Check-in count and progress",
  selected:"Progress and entries I choose"
} as const;
export type Sharing = keyof typeof sharingOptions;
export type Goal = {movement?:{activity:string;minutes:number};goal:string;target:number;sharing:Sharing;zone:string;reminder:string};
export type SharedMeal = {id:string;kind:"meal";name:string;lines:{food:Food;quantity:number}[]};
export type SharedItem = SharedMeal | {kind:"workout";name:string;minutes:number};
export type Member = Goal & {start:string;next:string;checks:Record<string,SharedItem|null>;ask:boolean;cheer:boolean};
export type BuddyView = {
  id:string;peer:string;incoming:boolean;active:boolean;
  mine:Member|null;today:string;clock:string;
  other:{movement?:Goal["movement"];goal:string;target:number;sharing:Sharing;complete:boolean;count?:number;items:SharedItem[];ask:boolean;cheer:boolean}|null;
};
export function localClock(zone:string,time=new Date()) {
  const parts=new Intl.DateTimeFormat("en-US",{timeZone:zone,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(time);
  const get=(key:string)=>parts.find(p=>p.type===key)!.value;
  return {day:get("year")+"-"+get("month")+"-"+get("day"),clock:get("hour")+":"+get("minute")};
}
export function plusDays(day:string,n:number) {
  const date=new Date(day+"T12:00:00Z");
  date.setUTCDate(date.getUTCDate()+n);
  return date.toISOString().slice(0,10);
}
export const deviceZone=()=>Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC";
export function reminderDue(p:BuddyView) {
  const m=p.mine;
  return !!(p.active&&m?.reminder&&m.next<=p.today&&p.today>=m.start&&p.today<=plusDays(m.start,6)&&
    Object.keys(m.checks).length<m.target&&!(p.today in m.checks)&&p.clock>=m.reminder);
}
