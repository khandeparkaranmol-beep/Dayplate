import {type Food,type Stored,completeDay,foodEntries} from "./model";
import {scaled} from "./nutrition";

export type Call="welcome"|"dessert"|"fried"|"vegetable"|"protein"|"usual"|"missed"|"back"|"workout"|"finish"|"logged";
type Host="Baron Crumb"|"Tara Tiffin";
export const scripts:Record<Call,{host:Host,lines:string[]}> = {
  welcome:{host:"Baron Crumb",lines:["Table for one? Excellent. Table for two if you count my opinion. I always do.","I have reserved the best seat in the café. It is on top of the biscuit tin."]},
  dessert:{host:"Baron Crumb",lines:["You read the dessert menu first. Finally, someone who reads a document in order of importance.","Interesting. The dessert has requested a lawyer. Apparently the spoon has a history.","There appears to be a crumb on the evidence. As a professional courtesy, I shall remove it."]},
  fried:{host:"Baron Crumb",lines:["I object to these fries on the grounds that nobody ordered any for the esteemed inspector.","I heard that crunch from the kitchen. My compliments to the sound department."]},
  vegetable:{host:"Tara Tiffin",lines:["That deserves the shiny compartment. I polished it with my own little oven mitt.","Lovely pick! I saved a place for it. The Baron tried to reserve all three tiers for biscuits."]},
  protein:{host:"Tara Tiffin",lines:["That portion puts something towards the protein goal you chose. I’m giving the lid a little celebratory tap.","Protein for your plan, and a satisfying little click from my lid. That click was for you."]},
  usual:{host:"Tara Tiffin",lines:["You showed up for your breakfast routine. I set out your usual katori.","Look at that. Your breakfast plan made it all the way to the table. I saved your seat."]},
  missed:{host:"Baron Crumb",lines:["Your routine called. I put it on hold. It has been listening to one teaspoon striking a glass for twenty minutes.","Scheduling irregularity! I have opened an inquiry. First witness: the calendar. So far, its days are numbered."]},
  back:{host:"Tara Tiffin",lines:["There you are. Your seat’s still here, and so is your favourite katori.","Welcome back. I kept lunch warm. The Baron kept a list of everyone who tried to sit in your chair."]},
  workout:{host:"Tara Tiffin",lines:["Workout logged. Hear that little steel drumroll? That’s me and two teaspoons.","You made time to move today. I’m taking a whole shelf to applaud."]},
  finish:{host:"Tara Tiffin",lines:["Day packed. Lid clicked. That last little tick in the diary is all yours.","Diary complete! The Baron wanted to stamp the paperwork. He stamped his own wing."]},
  logged:{host:"Baron Crumb",lines:["One entry in the ledger. One signature from me. One small ink stain that looks uncannily like a crow.","Recorded. I was going to commit the order to memory, but my memory currently contains one entire samosa."]}
};
export const replies:Record<Call,string>={
  welcome:"He promoted himself. The biscuit tin is the only department that reports to him.",
  dessert:"He’s been ‘examining the evidence’ for three spoons now.",
  fried:"I counted the fries before he put on that inspector’s badge.",
  vegetable:"I have petitioned for a fourth compartment. For documents. And one biscuit.",
  protein:"She does this with a teaspoon. The acoustics in here are intolerably cheerful.",
  usual:"The usual katori has a better attendance record than my staff.",
  missed:"I’ve rescued the phone from him. Want to start again? Your place is right here.",
  back:"That seat was under my personal protection. I invoiced one pigeon.",
  workout:"I count moving the sugar jar as office relocation. The authorities disagree.",
  finish:"The stamp on my wing is confidential.",
  logged:"He charges by the signature. Luckily he accepts payment in imaginary rupees."
};
export function foodCall(food:Food,quantity:number,proteinGoal?:number):Call{
  const name=food.name.toLowerCase();
  if(/brownie|tiramisu|ice cream|bebinca|rasgulla|gulab jamun|cheesecake|sundae|doughnut/.test(name))return "dessert";
  if(/\bfries\b|\bpakora\b|\bbhajiya\b|fried chicken|popcorn chicken|chicken popcorn|zinger burger/.test(name))return "fried";
  if(/\b(spinach|salad|cucumber|carrot|sprouts|beans|broccoli|apple|banana|mango|fruit)\b/.test(name))return "vegetable";
  const p=scaled(food,"p",quantity);
  if(proteinGoal&&p&&!p.relation&&p.value>=proteinGoal*.1)return "protein";
  return "logged";
}
export function dayCall(rows:Stored[],day:string):Call{
  const check=rows.find(r=>r.kind==="crewDay"&&r.day===day);
  if(check?.kind==="crewDay")return check.data.routine;
  if(completeDay(rows,day))return "finish";
  const foods=foodEntries(rows).filter(r=>r.day===day);
  const routine=rows.filter(r=>r.kind==="routine"&&r.day<=day).sort((a,b)=>b.day.localeCompare(a.day))[0];
  if(routine?.kind==="routine"&&!routine.data.paused&&routine.data.days.includes(new Date(day+"T12:00:00").getDay())&&foods.some(f=>f.data.meal==="Breakfast"))return "usual";
  if(rows.some(r=>r.kind==="exercise"&&r.day===day))return "workout";
  return foods.length?"logged":"welcome";
}
