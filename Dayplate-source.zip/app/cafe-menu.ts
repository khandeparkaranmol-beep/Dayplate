import type {LibraryFood} from "./regional";
import {makePanelFood,type NutritionPanel} from "./nutrition";

export type Recipe = [string,string,number,string,string,string?];
export const mumbaiCafe:Recipe[]=[
  ["Chicken pot pie","1 individual pie",240,"chicken (cooked):65,vegetables:45,mushrooms:15,onion:15,milk:35,white flour:35,butter:20","🥧","chicken pot pies potpie potpie ramekin pastry lid"],
  ["Nutella brownie","1 square",60,"nutella india:43,raw egg:12,egg yolk:2,white flour:8","🍫","nutella brownies chocolate hazelnut brownie bakery"],
  ["Coffee Rasgulla Tiramisu (Bombay Sweet Shop)","1 dessert cup",200,"rasgulla:70,mascarpone:55,cream:32,coffee:21,sugar:15,almonds:5,cocoa:2","🍮","rasgulla tiramisu rasagulla tiramisu roshogolla Bombay Sweet Shop Mumbai coffee dessert jar"],
  ["Chicken puff","1 pastry",85,"white flour:28,butter:16,chicken (cooked):28,onion:11,raw egg:3,oil:2","🥐","chicken puffs chicken patties pattis bakery puff pastry"],
  ["Mushroom and cheese puff","1 pastry",85,"white flour:28,butter:16,mushrooms:27,cheese:12,onion:8,raw egg:2","🥐","mushroom puffs cheese patties pattis"],
  ["Bun maska","1 buttered bun",70,"pav:55,butter:15","🍞","Irani cafe Mumbai Bombay brun maska pav maska buttered bun"],
  ["Akuri on toast","2 eggs with 1 slice",175,"raw egg:100,bread:30,onion:22,tomato:22,butter:7,coriander:2","🍳","akoori akuri eggs Parsi Irani breakfast scrambled eggs"],
  ["Bombay grilled vegetable sandwich","1 sandwich",190,"bread:65,potato:40,cucumber:25,tomato:35,onion:16,butter:10,coriander:4","🥪","Mumbai Bombay veg grilled sandwich green chutney"],
  ["Chilli cheese toast","2 small slices",105,"bread:55,cheese:35,butter:6,onion:10,coriander:2,dried red chilli:0.5","🧀","chili cheese toast chilli cheese toasties"],
];
export const goanCafe:Recipe[]=[
  ["Prawn rissóis","1 small fried pastry",45,"prawns:10,white flour:10,milk:9,butter:2,onion:3,bread:5,raw egg:3,oil:4","🍤","prawn rissois rissoys rissoes prawn pockets Goan cafe"],
  ["Chicken cafreal poi","1 filled roll",160,"wheat flour:30,white flour:16,chicken (cooked):75,coriander:9,onion:9,garlic:2,oil:5,vinegar:3","🥪","cafreal poie poee poiee pao sandwich Goa cafe"],
  ["Goan beef croquette","1 croquette",45,"beef (cooked):22,potato:8,onion:5,bread:5,raw egg:3,oil:4","🥩","beef croquettes croquetes Goa cafe mince"],
  ["Goan bolinha","1 coconut cookie",30,"coconut:10,semolina:8,sugar:8,raw egg:4,butter:2","🥥","bolinhas bolina bolinnas coconut semolina biscuits Goa"],
  ["Alle belle","1 filled pancake",75,"white flour:15,raw egg:8,milk:16,coconut:18,jaggery:13,butter:2","🥞","alebele ale belle coconut jaggery crepe Goan pancake"],
  ["Prawn balchão cheese tart","100 g weighed portion",100,"white flour:19,butter:13,prawns:26,cheese:14,onion:10,tomato:10,vinegar:4,garlic:2,dried red chilli:1,sugar:2,oil:2","🥧","prawn balchao cheese tart"],
  ["Goan egg chop","100 g weighed portion",100,"boiled egg:40,potato:40,bread:10,raw egg:5,onion:4,oil:5","🥚","egg chops"],
  ["Goan chicken chilli turnover","100 g weighed portion",100,"white flour:30,butter:19,chicken (cooked):28,onion:12,tomato:5,oil:3,raw egg:3,dried red chilli:1","🥐","chilly turn over turnover puff"],
  ["Vegetable cutlet poi","100 g weighed portion",100,"wheat flour:18,white flour:10,potato:24,vegetables:18,bread:4,oil:4,coriander:1","🥪","vegetable cutlets poie poee veg cutlet roll"],
  ["Serradura","100 g weighed portion",100,"cream:50,milk:45,sugar:17,white flour:15,butter:5","🍮","sawdust pudding biscuit cream"],
  ["Date and dodol scroll","100 g weighed portion",100,"white flour:26,butter:9,dates:17,jaggery:10,coconut milk:14,rice flour:4,milk:10,sugar:3","🥐","dates dodol swirl"],
];

export const tiramisuName="Coffee Rasgulla Tiramisu (Bombay Sweet Shop)";
export const tiramisuPage="https://bombaysweetshop.com/products/coffee-rasgulla-tiramisu";

// Per 100 g. These substitutions are confined to the illustrative café recipes.
const sugarProxies:Record<string,{values:Record<string,number>,source:string,note:string}>={
  "nutella india":{values:{addedSugar:56.3*19/21},source:"https://www.ferrerofoodservice.com/us/en/brands/nutella/nutella-jar-26oz",note:"Total sugar uses Ferrero India’s 56.3 g per 100 g. Added sugar uses the US label’s ratio of 19 g added to 21 g total sugar."},
  bread:{values:{addedSugar:3.2},source:"https://goodbite.ai/product/english-oven-sandwich-bread",note:"Added sugar in bread is estimated using the English Oven sandwich bread label."},
  "coconut milk":{values:{sugar:1.4},source:"https://www.marksandspencer.com/food/COCONUT%20MILK./p/fdp20059273",note:"Coconut milk sugar is estimated from the M&S canned coconut milk label."},
  semolina:{values:{sugar:0.1},source:"https://www.culpepers.com.au/uploaded/files/product_documents/semolina_euro_-_fine.pdf",note:"Semolina sugar uses the Culpepers fine semolina specification."},
  prawns:{values:{sugar:0.1},source:"https://www.tesco.com/shop/en-GB/products/297648931",note:"Prawn sugar uses Tesco’s cooked, peeled king prawn label."},
};
const unsweetenedIngredients=new Set(["oil","white flour","wheat flour","rice flour","semolina","raw egg","egg yolk","boiled egg","chicken (cooked)","beef (cooked)","prawns","vegetables","mushrooms","onion","milk","butter","cheese","tomato","cucumber","coriander","potato","dried red chilli","garlic","vinegar","coconut","coconut milk","cream","dates","almonds","cocoa","mascarpone","coffee"]);
export function cafeIngredient(key:string,base:Record<string,number>){
  const proxy=sugarProxies[key];
  const values={...base,...proxy?.values};
  if(key==="oil"&&values.c===0)values.sugar=0;
  if(key==="sugar"||key==="jaggery")values.addedSugar=values.sugar;
  else if(unsweetenedIngredients.has(key))values.addedSugar=0;
  return {values,source:proxy?.source,note:proxy?.note};
}

const qminMenu="https://www.vivantahotels.com/content/dam/restaurants/vivanta-panaji/qmin-shop-menu-march-2025.pdf";
const qminItems:[string,number,string,string][]=[
  ["Prawn balchão cheese tart",124,"🥧","prawn balchao cheese tart"],
  ["Goan egg chop",230,"🥚","egg chops"],
  ["Goan chicken chilli turnover",102,"🥐","chilly turn over turnover puff"],
  ["Vegetable cutlet poi",165,"🥪","vegetable cutlets poie poee veg cutlet roll"],
  ["Serradura",102,"🍮","sawdust pudding biscuit cream"],
  ["Date and dodol scroll",110,"🥐","dates dodol swirl"],
];
export const panajiMenu:LibraryFood[]=qminItems.map(([dish,kcal,icon,aliases])=>{
  const panel:NutritionPanel={
    kind:"Café menu",amount:100,unit:"g",values:{kcal},brand:"Qmin Shop, Vivanta Panaji",
    source:qminMenu,checked:"2026-11-24",
    detail:"Qmin Shop, Vivanta Panaji lists energy per 100 g. Enter the weight you ate. The menu gives no item-specific piece weight or nutrient breakdown.",
  };
  return {...makePanelFood(dish+" (Qmin Panaji)","100 g weighed portion",100,panel,icon),group:"Goan cafés",aliases:"Goa cafe "+aliases,portionKind:panel.kind,source:qminMenu,note:panel.detail};
});
