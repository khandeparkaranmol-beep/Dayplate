import {additionalItems,biscuitGroup,isDarkMagicQuery,individualGroup,itemMeasure,withItemMeasure} from "./countable-foods";
import {regional, primaryGroups, type LibraryFood} from "./regional";
import {kebabFoods,kebabGroup,includeExistingKebab} from "./kebabs";
import {mealCollections,existingMealFoods} from "./indian-meals";
import {worldFoods,worldGroups} from "./world-foods";
import {restaurantFoods} from "./restaurant-menu";
import {applyReference} from "./references";
import type { Food, Stored } from "./model";
import staplePanels from "./data/staples.json";
import {makePanelFood, panelSchema} from "./nutrition";
const portions:[string,string,number,string][]=[
  ["Roti / chapati", "1 medium roti", 40, "🫓"],
  ["Dal tadka", "1 katori", 150, "🥣"],
  ["Steamed basmati rice", "1 cup cooked", 158, "🍚"],
  ["Boiled egg", "1 large egg", 50, "🥚"],
  ["Banana", "1 medium", 118, "🍌"],
  ["Greek yogurt, plain", "1 small bowl", 170, "🥛"],
  ["Idli", "1 medium idli", 40, "🍘"],
  ["Plain dosa", "1 medium dosa", 85, "🫓"],
  ["Sambar", "1 katori", 150, "🥣"],
  ["Rajma masala", "1 katori", 150, "🫘"],
  ["Chana masala", "1 katori", 150, "🫘"],
  ["Paneer", "1 portion", 100, "🧀"],
  ["Paneer bhurji", "1 katori", 150, "🥘"],
  ["Curd / dahi", "1 katori", 150, "🥛"],
  ["Masala chai, sweetened", "1 small cup", 120, "☕"],
  ["Vegetable upma", "1 bowl cooked", 150, "🥣"],
  ["Aloo paratha", "1 medium paratha", 100, "🫓"],
  ["Bhindi sabzi", "1 katori", 120, "🥬"],
  ["Mixed vegetable sabzi", "1 katori", 125, "🥕"],
  ["Vegetable khichdi", "1 bowl", 200, "🥣"],
  ["Chicken biryani", "1 bowl", 250, "🍛"],
  ["Chicken curry", "1 katori", 180, "🍛"],
  ["Samosa", "1 medium", 80, "🥟"],
  ["Thepla", "1 medium", 45, "🫓"],
  ["Coconut chutney", "1 tbsp", 15, "🥥"],
  ["Peanuts, roasted", "1 handful", 28, "🥜"],
  ["Almonds", "1 handful", 28, "🌰"],
  ["Ghee", "1 tsp", 5, "🧈"],
  ["Cooking oil", "1 tsp", 4.5, "🫗"],
  ["Butter", "1 tsp", 5, "🧈"],
  ["Milk, whole", "1 glass", 244, "🥛"],
  ["Rolled oats, dry", "½ cup dry", 40, "🥣"],
  ["Whole wheat bread", "1 slice", 28, "🍞"],
  ["Brown rice", "1 cup cooked", 195, "🍚"],
  ["Quinoa", "1 cup cooked", 185, "🌾"],
  ["Pasta, plain", "1 cup cooked", 140, "🍝"],
  ["Chicken breast, cooked", "1 portion", 100, "🍗"],
  ["Tofu, firm", "1 portion", 100, "🧊"],
  ["Egg white", "1 large", 33, "🥚"],
  ["Salmon, cooked", "1 fillet portion", 100, "🐟"],
  ["Lentils, plain", "1 cup cooked", 198, "🫘"],
  ["Chickpeas, cooked", "1 cup", 164, "🫘"],
  ["Apple", "1 medium", 182, "🍎"],
  ["Mango", "1 cup sliced", 165, "🥭"],
  ["Orange", "1 medium", 131, "🍊"],
  ["Papaya", "1 cup cubed", 145, "🍈"],
  ["Grapes", "1 cup", 151, "🍇"],
  ["Watermelon", "1 cup cubed", 152, "🍉"],
  ["Avocado", "½ medium", 75, "🥑"],
  ["Potato, boiled", "1 medium", 150, "🥔"],
  ["Cucumber", "1 cup sliced", 104, "🥒"],
  ["Carrot", "1 medium", 61, "🥕"],
  ["Tomato", "1 medium", 123, "🍅"],
  ["Spinach, cooked", "1 cup", 180, "🥬"],
  ["Peanut butter", "1 tbsp", 16, "🥜"],
  ["Black coffee", "1 cup", 240, "☕"],
  ["Sugar", "1 tsp", 4, "🥄"],
  ["Jaggery", "1 tsp grated", 5, "🥄"],
  ["Buttermilk / chaas", "1 glass", 200, "🥛"],
];
const basics:LibraryFood[]=portions.map(([name,serving,grams,icon])=>{
  const recipe=staplePanels[name as keyof typeof staplePanels];
  const food=recipe?makePanelFood(name,serving,grams,panelSchema.parse(recipe),icon):applyReference(name,serving,grams,icon);
  const aliases=name==="Steamed basmati rice"?"boiled basmati unsalted":undefined;
  return {...food,group:"Everyday staples",aliases,portionKind:food.panel!.kind,source:food.panel!.source,note:food.panel!.detail};
});
export const catalog:LibraryFood[]=[...[...regional,...basics,...additionalItems].map(withItemMeasure),...kebabFoods,...restaurantFoods,...worldFoods].map(includeExistingKebab);
const catalogByName=new Map(catalog.map(f=>[f.name,f]));
const mealMembership=new Map<string,Set<string>>(mealCollections.map(group=>[group,new Set(existingMealFoods[group])]));
export const groups=["All",individualGroup,biscuitGroup,...mealCollections,kebabGroup,"Indian fast food",...worldGroups,...primaryGroups,"Mumbai cafés","Goan cafés","Protein bars","Protein shakes","Packaged goods","Everyday staples"];
const norm=(s:string)=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[’']/g,"").replace(/[^\p{L}\p{M}\p{N}]+/gu," ").trim();
const americanStandards=new Set(["French toast","Pancakes, plain","Baked potato with butter","Grilled cheese sandwich","Macaroni and cheese","Chicken club sandwich","Chicken pot pie"]);
export function inGroup(food:Food,group:string){
 if(group==="All")return true;
 const item=catalogByName.get(food.name);
 const split=group.indexOf(" | ");
 if(split!==-1){
   if(item?.group!=="US restaurants")return false;
   const archive=item.serving.endsWith(" archive");
   if(archive!==(group.slice(split+3)==="archive"))return false;
   group=group.slice(0,split);
 }
 return item?.tags?.includes(group)===true||(group==="Tofu"&&item?.name==="Tofu, firm")||(group==="American"&&americanStandards.has(food.name))||(item?.group==="Indian fast food"&&item.panel?.brand===group)||item?.group===group||item?.cuisine===group||mealMembership.get(group)?.has(food.name)===true||(group==="Indian snacks"&&item?.group==="Indian market snacks")||(group==="Goan"&&item?.group==="Goan cafés")||(group==="Indian market snacks"&&item?.group==="Protein bars")||(group==="My foods"&&(!item||food.panel?.kind==="Your package"));
}
export function collectionFoods(foods:Food[],group:string):Food[] {
 if(group==="All")return foods;
 const matches=foods.filter(food=>inGroup(food,group));
 if(group.split(" | ")[0]!=="US restaurants")return matches;
 const buckets:Food[][]=[[],[],[],[]];
 for(const food of matches){
   const rank=(food.serving.endsWith(" archive")?2:0)+(inGroup(food,"US drinks")?1:0);
   buckets[rank].push(food);
 }
 return buckets.flat();
}
const searchIndex=new WeakMap<Food,string>();
export function searchFood(foods:Food[],query:string) {
 const text=norm(query);
 if(!text)return foods;
 // A counted staple should appear before similarly named composite dishes.
 const itemQuery=text.replace(/^(?:one|1) /,"");
 const words=text.split(/\s+/);
 const darkMagic=isDarkMagicQuery(text);
 const priority:Food[]=[];
 const matches=foods.filter(food=>{
   let indexed=searchIndex.get(food);
   if(indexed===undefined){
     const item=catalogByName.get(food.name);
     indexed=norm([food.name,food.serving,item?.aliases,item?.group,item?.tags?.join(" "),item?.cuisine,food.panel?.brand,food.panel?.variant,food.panel?.barcode].filter(Boolean).join(" "));
     searchIndex.set(food,indexed);
   }
   const m=itemMeasure(food);
   if(m&&(itemQuery===m.one||itemQuery===m.many||itemQuery===m.alternate?.one||itemQuery===m.alternate?.many||itemQuery===norm(food.name))){
     priority.push(food);return false;
   }
   if(words.every(word=>indexed.includes(word)))return true;
   return darkMagic&&/^(Britannia Pure Magic|Sunfeast Dark Fantasy)\b/i.test(food.name);
 });
 return priority.length?[...priority,...matches]:matches;
}

// Previously logged built-in recipes keep their portions and calories when sugar coverage improves.
export function refreshCafeSugars(entry:Stored):Stored {
 if(entry.kind!=="food"||entry.data.custom)return entry;
 const food=entry.data.food,panel=food.panel;
 if(panel?.kind!=="Recipe estimate"||(panel.values.sugar!==undefined&&panel.values.addedSugar!==undefined))return entry;
 const current=catalog.find(f=>f.group.endsWith("cafés")&&f.name===food.name&&f.grams===food.grams&&f.kcal===food.kcal&&f.serving===food.serving);
 const replacement=current?.panel;
 if(!replacement||replacement.amount!==panel.amount||replacement.unit!==panel.unit||!Object.entries(panel.values).every(([key,value])=>replacement.values[key]===value))return entry;
 return {...entry,data:{...entry.data,food:{...food,panel:replacement}}};
}
