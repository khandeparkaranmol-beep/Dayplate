import {regional, primaryGroups, type LibraryFood} from "./regional";
import {applyReference} from "./references";
import type { Food } from "./model";
import staplePanels from "./data/staples.json";
import {makePanelFood, panelSchema} from "./nutrition";
const portions:[string,string,number,string][]=[
  ["Roti / chapati", "1 medium roti", 40, "🫓"],
  ["Dal tadka", "1 katori", 150, "🥣"],
  ["Steamed basmati rice", "1 cup cooked", 158, "🍚"],
  ["Boiled egg", "1 large egg", 50, "🥚"],
  ["Banana", "1 medium", 118, "🍌"],
  ["Greek yogurt, plain", "1 small bowl", 170, "🥛"],
  ["Idli", "1 medium idli", 40, "🍘"],
  ["Plain dosa", "1 medium dosa", 85, "🫓"],
  ["Sambar", "1 katori", 150, "🥣"],
  ["Rajma masala", "1 katori", 150, "🫘"],
  ["Chana masala", "1 katori", 150, "🫘"],
  ["Paneer", "1 portion", 100, "🧀"],
  ["Paneer bhurji", "1 katori", 150, "🥘"],
  ["Curd / dahi", "1 katori", 150, "🥛"],
  ["Masala chai, sweetened", "1 small cup", 120, "☕"],
  ["Vegetable upma", "1 bowl cooked", 150, "🥣"],
  ["Aloo paratha", "1 medium paratha", 100, "🫓"],
  ["Bhindi sabzi", "1 katori", 120, "🥬"],
  ["Mixed vegetable sabzi", "1 katori", 125, "🥕"],
  ["Vegetable khichdi", "1 bowl", 200, "🥣"],
  ["Chicken biryani", "1 bowl", 250, "🍛"],
  ["Chicken curry", "1 katori", 180, "🍛"],
  ["Samosa", "1 medium", 80, "🥟"],
  ["Thepla", "1 medium", 45, "🫓"],
  ["Coconut chutney", "1 tbsp", 15, "🥥"],
  ["Peanuts, roasted", "1 handful", 28, "🥜"],
  ["Almonds", "1 handful", 28, "🌰"],
  ["Ghee", "1 tsp", 5, "🧈"],
  ["Cooking oil", "1 tsp", 4.5, "🫗"],
  ["Butter", "1 tsp", 5, "🧈"],
  ["Milk, whole", "1 glass", 244, "🥛"],
  ["Rolled oats, dry", "½ cup dry", 40, "🥣"],
  ["Whole wheat bread", "1 slice", 28, "🍞"],
  ["Brown rice", "1 cup cooked", 195, "🍚"],
  ["Quinoa", "1 cup cooked", 185, "🌾"],
  ["Pasta, plain", "1 cup cooked", 140, "🍝"],
  ["Chicken breast, cooked", "1 portion", 100, "🍗"],
  ["Tofu, firm", "1 portion", 100, "🧊"],
  ["Egg white", "1 large", 33, "🥚"],
  ["Salmon, cooked", "1 fillet portion", 100, "🐟"],
  ["Lentils, plain", "1 cup cooked", 198, "🫘"],
  ["Chickpeas, cooked", "1 cup", 164, "🫘"],
  ["Apple", "1 medium", 182, "🍎"],
  ["Mango", "1 cup sliced", 165, "🥭"],
  ["Orange", "1 medium", 131, "🍊"],
  ["Papaya", "1 cup cubed", 145, "🍈"],
  ["Grapes", "1 cup", 151, "🍇"],
  ["Watermelon", "1 cup cubed", 152, "🍉"],
  ["Avocado", "½ medium", 75, "🥑"],
  ["Potato, boiled", "1 medium", 150, "🥔"],
  ["Cucumber", "1 cup sliced", 104, "🥒"],
  ["Carrot", "1 medium", 61, "🥕"],
  ["Tomato", "1 medium", 123, "🍅"],
  ["Spinach, cooked", "1 cup", 180, "🥬"],
  ["Peanut butter", "1 tbsp", 16, "🥜"],
  ["Black coffee", "1 cup", 240, "☕"],
  ["Sugar", "1 tsp", 4, "🥄"],
  ["Jaggery", "1 tsp grated", 5, "🥄"],
  ["Buttermilk / chaas", "1 glass", 200, "🥛"],
];
const basics:LibraryFood[]=portions.map(([name,serving,grams,icon])=>{
  const recipe=staplePanels[name as keyof typeof staplePanels];
  const food=recipe?makePanelFood(name,serving,grams,panelSchema.parse(recipe),icon):applyReference(name,serving,grams,icon);
  const aliases=name==="Steamed basmati rice"?"boiled basmati unsalted":undefined;
  return {...food,group:"Everyday staples",aliases,portionKind:food.panel!.kind,source:food.panel!.source,note:food.panel!.detail};
});
export const catalog:LibraryFood[]=[...regional,...basics];
export const groups=["All",...primaryGroups,"Mumbai cafés","Goan cafés","Protein bars","Protein shakes","Packaged goods","Everyday staples"];
const norm=(s:string)=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[’']/g,"").replace(/[^\p{L}\p{M}\p{N}]+/gu," ").trim();
export function inGroup(food:Food,group:string){
 if(group==="All")return true;
 const item=catalog.find(r=>r.name===food.name);
 return item?.group===group||(group==="Goan"&&item?.group==="Goan cafés")||(group==="Indian market snacks"&&item?.group==="Protein bars")||(group==="My foods"&&(!item||food.panel?.kind==="Your package"));
}
export function searchFood(foods:Food[],query:string) {
 const words=norm(query).split(/\s+/);
 return foods.filter(f=>{const item=catalog.find(v=>v.name===f.name);const hay=norm([f.name,f.serving,item?.aliases,item?.group,f.panel?.brand,f.panel?.variant,f.panel?.barcode].filter(Boolean).join(" "));return words.every(word=>hay.includes(word))});
}
