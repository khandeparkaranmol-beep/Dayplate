import portions from "./data/counted-portions.json";
import products from "./data/piece-foods.json";
import biscuitData from "./data/indian-biscuits.json";
import {applyReference} from "./references";
import {makePanelFood,panelSchema} from "./nutrition";
import type {Food} from "./model";
import type {LibraryFood} from "./regional";

export const biscuitGroup="Indian biscuits";
export function isDarkMagicQuery(query:string){
  return /\bdark[\s-]*magic\b/i.test(query);
}
type Biscuit = {name:string, aliases:string, grams:number|null, labelServing?:number, panel:unknown};
const biscuits: Biscuit[]=biscuitData;
const existingBiscuits=new Set(["Parle-G Original Gluco Biscuits","Britannia Good Day Butter Cookies",
  "Britannia NutriChoice Digestive","Britannia Marie Gold Biscuits","Britannia Vita Marie Gold Biscuits"]);
const measures=new Map(portions.map(p=>[p.name,p]));
const biscuitFoods:LibraryFood[]=biscuits.map(b=>{
  const panel=panelSchema.parse(b.panel);
  const serving=b.grams!==null?"1 biscuit (approx.)":b.labelServing?b.labelServing+" g label serving":"100 g weighed portion";
  if(b.grams!==null){
    measures.set(b.name,{name:b.name,one:"biscuit",many:"biscuits",serving,grams:b.grams,
      source:panel.source!,note:"",aliases:"",icon:""});
  }
  return {...makePanelFood(b.name,serving,b.grams??b.labelServing??100,panel,"🍪"),group:"Indian market snacks",
    tags:[biscuitGroup],aliases:b.aliases,source:panel.source,portionKind:panel.kind};
});
const weighedBiscuits=new Set(biscuits.filter(b=>b.grams===null&&!b.labelServing).map(b=>b.name));
export function needsBiscuitWeight(food?:Food){
  return !!food&&food.serving==="100 g weighed portion"&&weighedBiscuits.has(food.name)&&food.panel?.kind!=="Your package";
}
export const fruitGroup="Indian fruits";
export const individualGroup="Individual items";

export function itemMeasure(food:Food) {
  const measure=measures.get(food.name);
  // A diary entry or a saved recipe can carry a previous serving with the same name.
  return measure&&food.grams===measure.grams&&food.serving===measure.serving?measure:undefined;
}

export function withItemMeasure(food:LibraryFood):LibraryFood {
  const m=measures.get(food.name);
  if(existingBiscuits.has(food.name))food={...food,tags:[...(food.tags??[]),biscuitGroup]};
  if(!m||!food.panel)return food;
  const links=[...new Set([...(food.panel.links??[]),m.source])].filter(url=>url!==food.panel!.source);
  const panel={...food.panel,detail:[food.panel.detail,m.note].filter(Boolean).join(" "),links};
  const aliases=[food.aliases,m.aliases,m.fruitAliases?.join(" "),m.one,m.many,m.alternate?.one,m.alternate?.many].filter(Boolean).join(" ");
  return {...food,...makePanelFood(food.name,m.serving,m.grams,panel,food.icon),aliases,
    tags:[...new Set([...(food.tags??[]),individualGroup,...(m.fruitAliases?[fruitGroup]:[]),...(food.group==="Goan"?["Indian snacks"]:[])])]};
}

export const additionalItems:LibraryFood[]=[
  ...biscuitFoods,
  ...portions.filter(p=>p.icon).map(p=>({
    ...applyReference(p.name,p.serving,p.grams,p.icon),group:"Everyday staples",portionKind:"Food composition reference"
  })),
  ...products.map(p=>{
    const m=measures.get(p.name)!;
    const panel=panelSchema.parse(p.panel);
    return {...makePanelFood(p.name,m.serving,m.grams,panel,p.icon),group:p.group,source:panel.source,portionKind:panel.kind};
  })
];
