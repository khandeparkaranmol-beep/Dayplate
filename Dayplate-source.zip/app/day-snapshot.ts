import {meals,type Stored} from "./model";
import {compactNumber,dayNutrient,formatDaily} from "./nutrition";
import type {LoggedUpdate} from "./logged-update";
import {workoutBurn,strengthDetail} from "./workout-energy";

export type SnapshotGroup={title:string; lines:{name:string; detail:string}[]; total?:string};
export type SnapshotLinkInfo={id:string; created:number; expires:number};
export type SnapshotState={snapshot:LoggedUpdate|null; fingerprint:string|null; links:SnapshotLinkInfo[]};
export type SharedDay={snapshot:LoggedUpdate; created:number; expires:number};
export const snapshotDate=(day:string)=>new Date(day+"T12:00:00").toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"long",year:"numeric"});
export const whatsappURL=(message:string)=>"https://wa.me/?text="+encodeURIComponent(message);

export function daySnapshot(entries:Stored[],day:string):LoggedUpdate|null {
  const rows=entries.filter(r=>r.day===day);
  const foods=rows.filter(r=>r.kind==="food");
  const activity=rows.find(r=>r.kind==="activity");
  const workouts=rows.filter(r=>r.kind==="exercise");
  const groups:SnapshotGroup[]=[],stats:LoggedUpdate["stats"]=[];
  if(foods.length){
    const energy=(items:typeof foods)=>
      (items.some(r=>r.data.food.panel?.kind==="Recipe estimate")?"≈ ":"")+
      Math.round(items.reduce((n,r)=>n+r.data.quantity*r.data.food.kcal,0)).toLocaleString("en-US")+" kcal";
    stats.push({label:"Food energy",value:energy(foods)});
    for(const [key,label] of [["p","Protein"],["sugar","Total sugar"]]){
      const n=dayNutrient(foods,key);
      if(!n.missing)stats.push({label,value:(foods.some(r=>r.data.food.panel?.kind==="Recipe estimate")?"≈ ":"")+formatDaily(n)+" g"});
    }
    for(const meal of meals){
      const items=foods.filter(r=>r.data.meal===meal);
      if(items.length)groups.push({title:meal,total:energy(items),lines:items.map(({data:{food,quantity}})=>({
        name:food.name,detail:(quantity===1?"":compactNumber(quantity)+" × ")+food.serving
      }))});
    }
  }
  if(workouts.length){
    stats.push({label:"Workout time",value:compactNumber(workouts.reduce((n,r)=>n+r.data.minutes,0))+" min"});
    groups.push({title:"Workouts",lines:workouts.map(r=>{
      const burn=workoutBurn(r,[]);
      const energy=burn.kcal==null?"":" · "+(burn.source==="estimate"?"≈ ":"")+Math.round(burn.kcal)+" active kcal";
      return {name:r.data.name,detail:[compactNumber(r.data.minutes)+" min"+energy,strengthDetail(r.data)].filter(Boolean).join(" · ")};
    })});
  }
  if(activity?.data.steps!=null)stats.push({label:"Steps",value:compactNumber(activity.data.steps)});
  if(activity?.data.active!=null)stats.push({label:"Daily active energy",value:compactNumber(activity.data.active)+" kcal"});
  if(!stats.length)return null;
  return {kind:"day",day,title:"Day snapshot",stats,items:[],groups};
}
export function dayText(update:LoggedUpdate){
  return ["My Dayplate snapshot · "+snapshotDate(update.day),update.stats.map(s=>s.label+" "+s.value).join(" · "),
    ...(update.groups??[]).map(g=>g.title+"\n"+g.lines.map(l=>l.name+" · "+l.detail).join("\n"))].join("\n\n");
}
