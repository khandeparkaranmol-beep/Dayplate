import { recordSchema, type Stored, type Entry, estimate } from "./model";
import {workoutBatch} from "./activity-records";
import {repeatSchema,sameEntry} from "./repeat";
import { z } from "zod";
import {shareJSON} from "./share-file";
const savedSchema=z.intersection(recordSchema,z.object({revision:z.number().int().positive()}));
const backupSchema=z.object({app:z.literal("dayplate"),format:z.literal(1),entries:z.array(savedSchema).max(250000)});
const storeName="entries";
let connection:Promise<IDBDatabase>|undefined;
function database():Promise<IDBDatabase>{
 if(!connection){connection=new Promise<IDBDatabase>((resolve,reject)=>{
 const req=indexedDB.open("dayplate-personal-journal",1);
 req.onupgradeneeded=()=>req.result.createObjectStore(storeName,{keyPath:"id"});
 req.onsuccess=()=>resolve(req.result);
 req.onerror=()=>reject(new Error("Browser storage is unavailable. Open the downloaded file in a full browser and allow local storage."));
 }).catch(err=>{connection=undefined;throw err})}
 return connection;
}
function done(tx:IDBTransaction){return new Promise<void>((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onabort=tx.onerror=()=>reject(new Error("The browser could not save this change. Check available storage and retry."))})}
function read<T>(req:IDBRequest<T>){return new Promise<T>((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function all(){const db=await database();return read<Stored[]>(db.transaction(storeName).objectStore(storeName).getAll())}
type Mutation={action:"put",entry:Entry,revision:number}|{action:"delete",id:string,revision:number};
export async function deviceRequest(_url:string,init?:RequestInit) {
 if(init?.method!=="POST")return Response.json(await all());
 const raw=JSON.parse(String(init.body));
 if(raw.action==="healthImport"){
   const batch=workoutBatch.safeParse(raw);
   if(!batch.success)return Response.json({error:"Invalid activity import."},{status:400});
   const db=await database(),tx=db.transaction(storeName,"readwrite"),finished=done(tx),store=tx.objectStore(storeName);
   const rows=batch.data.entries;
   const old=await Promise.all(rows.map(e=>read<Stored|undefined>(store.get(e.id))));
   rows.forEach((e,i)=>{
    const previous=old[i];if(previous&&previous.kind!==e.kind)return;
    const data=e.kind==="activity"&&previous?.kind==="activity"?{...previous.data,...e.data,sources:{...previous.data.sources,...e.data.sources}}:e.data;
    if(!previous||JSON.stringify(previous.data)!==JSON.stringify(data))store.put({...e,data,revision:(previous?.revision||0)+1});
   });
   await finished;return Response.json({saved:true});
 }
 if(raw.action==="repeat"){
   const batch=repeatSchema.safeParse(raw);
   if(!batch.success)return Response.json({error:"Review the meal and portions."},{status:400});
   const entries=batch.data.entries;
   const db=await database(),tx=db.transaction(storeName,"readwrite"),finished=done(tx),store=tx.objectStore(storeName);
   const found=await Promise.all(entries.map(e=>read<Stored|undefined>(store.get(e.id))));
   if(found.some(Boolean)){
     await finished;
     return found.every((old,i)=>old&&sameEntry(old,entries[i]))?Response.json({revision:1}):Response.json({error:"This meal has changed. Reopen it to review."},{status:409});
   }
   for(const e of entries)store.add({...e,revision:1});
   await finished;return Response.json({revision:1});
 }
 const m=raw as Mutation;
 if(m.action==="put"&&!recordSchema.safeParse(m.entry).success)return Response.json({error:"Check your entry."},{status:400});
 const db=await database(),tx=db.transaction(storeName,"readwrite"),finished=done(tx),store=tx.objectStore(storeName);
 const id=m.action==="put"?m.entry.id:m.id;
 const existing=await read<Stored|undefined>(store.get(id));
 if((existing?.revision||0)!==m.revision){await finished;return Response.json({error:"This entry changed in another tab. Review the refreshed diary."},{status:409})}
 if(m.action==="put"){store.put({...recordSchema.parse(m.entry),revision:m.revision+1})}else{store.delete(id)}
 await finished;
 return Response.json({revision:m.revision+1});
}
export async function exportBackup(){
 const entries=await all();
 await shareJSON(JSON.stringify({app:"dayplate",format:1,exportedAt:new Date().toISOString(),entries},null,2),"dayplate-backup-"+new Date().toISOString().slice(0,10)+".json","backup");
}
export async function importBackup(file:File){
 if(file.size>50_000_000)throw Error("Choose a Dayplate backup under 50 MB.");
 let raw:unknown;try{raw=JSON.parse(await file.text())}catch{throw Error("Choose a Dayplate JSON backup.")}
 const parsed=backupSchema.safeParse(raw);if(!parsed.success)throw Error("This file is not a valid Dayplate backup.");
 const ids=new Set<string>();for(const r of parsed.data.entries){
 if(ids.has(r.id)||((r.kind==="target"||r.kind==="weight"||r.kind==="measure"||r.kind==="review")&&r.id!==r.kind+"-"+r.day))throw Error("The backup contains inconsistent entries.");
 if(r.kind==="target"&&r.data.profile){const e=estimate(r.data.profile);if(!e.safe||e.target!==r.data.calories)throw Error("The backup contains an invalid target.")}
 ids.add(r.id);
 }
 const db=await database(),tx=db.transaction(storeName,"readwrite"),finished=done(tx),store=tx.objectStore(storeName);
 const present=new Set(await read(store.getAllKeys()));let added=0;
 for(const row of parsed.data.entries){if(!present.has(row.id)){store.add(row);added++}}
 await finished;return {added,skipped:parsed.data.entries.length-added};
}

