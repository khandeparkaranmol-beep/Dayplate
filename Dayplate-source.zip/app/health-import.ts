import {Unzip,UnzipInflate} from "fflate";
import {parser} from "../vendor/xml/sax.cjs";
import {type Entry,validDate} from "./model";

export const metrics=["steps","active","resting"] as const;
export type Metric=typeof metrics[number];
export type ActivityDay={values:Record<Metric,Map<string,number>>,move?:number};
type Workout={day:string,start:string,end:string,name:string,minutes:number,source:string};
export type HealthPreview={days:Map<string,ActivityDay>,sources:Record<Metric,Set<string>>,workouts:Map<string,Workout>};
export type SourceChoice=Record<Metric,string>;
const keys:Record<string,Metric>={HKQuantityTypeIdentifierStepCount:"steps",HKQuantityTypeIdentifierActiveEnergyBurned:"active",HKQuantityTypeIdentifierBasalEnergyBurned:"resting"};
const energy=(v:number,u:string)=>u==="kcal"||u==="Cal"?v:u==="kJ"?v/4.184:u==="cal"?v/1000:undefined;
const names:Record<string,string>={TraditionalStrengthTraining:"Strength training",HighIntensityIntervalTraining:"HIIT",Other:"Other workout"};
function dayData(result:HealthPreview,day:string){
 let record=result.days.get(day);
 if(!record){record={values:{steps:new Map(),active:new Map(),resting:new Map()}};result.days.set(day,record)}
 return record;
}
function sourceOf(a:Record<string,string>){
 const device=a.device?.match(/(?:^|,\s*)name:([^,>]+)/)?.[1]?.trim();
 return [a.sourceName||"Health",device].filter(Boolean).join(" · ").slice(0,100);
}
function utcTime(value:string){const d=new Date(value.replace(/^(\d{4}-\d\d-\d\d) (\d\d:\d\d:\d\d) ([+-]\d\d)(\d\d)$/,"$1T$2$3:$4"));return Number.isFinite(+d)?d.toISOString():""}
export async function parseHealth(file:File):Promise<HealthPreview>{
 const result:HealthPreview={days:new Map(),sources:{steps:new Set(),active:new Set(),resting:new Set()},workouts:new Map()};
 const xml=parser(true),decoder=new TextDecoder();let root=false,bytes=0;
 xml.onopentag=({name,attributes:a})=>{
  if(name==="HealthData"){root=true;return}
  if(!root||!["Record","ActivitySummary","Workout"].includes(name))return;
  if(name==="Record"&&!Object.hasOwn(keys,a.type))return;
  const day=(name==="ActivitySummary"?a.dateComponents:a.startDate)?.slice(0,10);
  if(!day||!validDate.safeParse(day).success)return;
  if(name==="ActivitySummary"){
   if(a.activeEnergyBurned==null)return;
   const n=energy(Number(a.activeEnergyBurned),a.activeEnergyBurnedUnit);
   if(n!=null&&Number.isFinite(n)&&n>=0)dayData(result,day).move=n;
   return;
  }
  const source=sourceOf(a);
  if(name==="Workout"){
   const raw=(a.workoutActivityType||"").replace(/^HKWorkoutActivityType/,"");
   const start=utcTime(a.startDate||""),end=utcTime(a.endDate||"");
   if(!start||!end||!raw)return;
   const v=Number(a.duration),unit=a.durationUnit;
   const minutes=a.duration!=null&&["min","s","hr","h"].includes(unit)?v*(unit==="s"?1/60:unit==="min"?1:60):(+new Date(end)-+new Date(start))/60000;
   if(!Number.isFinite(minutes)||minutes<=0)return;
   const name=names[raw]||raw.replace(/([a-z])([A-Z])/g,"$1 $2").toLowerCase().replace(/^./,v=>v.toUpperCase());
   const key=JSON.stringify([raw,start,end,source]);
   result.workouts.set(key,{day,start,end,name,minutes,source});return;
  }
  const metric=keys[a.type],v=Number(a.value);
  const value=metric==="steps"?(a.unit==="count"?v:undefined):energy(v,a.unit);
  if(value==null||!Number.isFinite(value)||value<0)return;
  const totals=dayData(result,day).values[metric];
  totals.set(source,(totals.get(source)||0)+value);result.sources[metric].add(source);
 };
 function consume(chunk:Uint8Array){bytes+=chunk.length;if(bytes>3_000_000_000)throw Error("This export is too large for this device.");xml.write(decoder.decode(chunk,{stream:true}))}
 const sig=new Uint8Array(await file.slice(0,4).arrayBuffer()),zip=sig[0]===80&&sig[1]===75;
 let found=!zip,finished=!zip;
 const unpack=zip?new Unzip(item=>{
  if(!/(?:^|\/)export\.xml$/i.test(item.name)||found)return;
  found=true;item.ondata=(err,chunk,final)=>{if(err)throw err;consume(chunk);finished=final};item.start();
 }):null;
 unpack?.register(UnzipInflate);
 for(let i=0;i<file.size;i+=131072){const chunk=new Uint8Array(await file.slice(i,i+131072).arrayBuffer());if(unpack)unpack.push(chunk,i+chunk.length===file.size);else consume(chunk)}
 if(!found||!finished)throw Error("The archive must contain Apple Health’s export.xml.");
 xml.write(decoder.decode());xml.close();
 if(!root)throw Error("Choose an Apple Health export.");
 return result;
}
export function initialSources(preview:HealthPreview):SourceChoice{
 const choice=(m:Metric)=>preview.sources[m].size===1?[...preview.sources[m]][0]:"";
 return {steps:choice("steps"),active:choice("active"),resting:choice("resting")};
}
export async function importRows(preview:HealthPreview,pick:SourceChoice,from:string,through:string):Promise<Entry[]>{
 const inRange=(day:string)=>day>=from&&day<=through;
 const out:Entry[]=[];
 for(const [day,row] of preview.days){
  if(!inRange(day))continue;
  const data:{steps?:number,active?:number,resting?:number,sources:Partial<Record<Metric,string>>}={sources:{}};
  for(const metric of metrics){
   const summary=metric==="active"&&row.move!==undefined;
   const amount=summary?row.move:row.values[metric].get(pick[metric]);
   if(amount===undefined)continue;
   data[metric]=metric==="steps"?Math.round(amount):Math.round(amount*100)/100;
   data.sources[metric]=summary?"Apple Fitness · Move":pick[metric];
  }
  if(Object.keys(data.sources).length)out.push({id:"activity-"+day,kind:"activity",day,data});
 }
 for(const [key,w] of preview.workouts){
  if(!inRange(w.day))continue;
  const bytes=new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(key)));
  const hex=Array.from(bytes,n=>n.toString(16).padStart(2,"0")).join("").slice(0,32);
  const uuid=hex.slice(0,8)+"-"+hex.slice(8,12)+"-4"+hex.slice(13,16)+"-8"+hex.slice(17,20)+"-"+hex.slice(20);
  out.push({id:"apple-"+uuid,day:w.day,kind:"exercise",data:{name:w.name,minutes:w.minutes,health:{uuid,start:w.start,end:w.end}}});
 }
 return out;
}
