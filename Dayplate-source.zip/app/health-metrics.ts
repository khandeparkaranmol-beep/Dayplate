import {estimate,shift,type Stored} from "./model";
export function healthAt(rows:Stored[],day:string){
 const ordered=rows.filter(r=>r.day<=day).sort((a,b)=>b.day.localeCompare(a.day));
 const profiles=ordered.filter(r=>r.kind==="target").flatMap(r=>r.data.profile?[{...r.data.profile,day:r.day}]:[]);
 const profile=profiles[0];
 const weights=ordered.filter(r=>r.kind==="weight").map(r=>({day:r.day,value:r.data.kg}));
 const measures=ordered.filter(r=>r.kind==="measure");
 const heightCheck=measures.find(r=>r.data.height!==undefined);
 const height=heightCheck?.data.height!==undefined&&(!profile||heightCheck.day>=profile.day)?{value:heightCheck.data.height,day:heightCheck.day}:profile?{value:profile.height,day:profile.day}:null;
 const weight=weights[0]&&(!profile||weights[0].day>=profile.day)?weights[0]:profile?{value:profile.weight,day:profile.day}:null;
 const waist=measures.find(r=>r.data.waist!==undefined);
 const current=weights.filter(r=>r.day>=shift(day,-6)),previous=weights.filter(r=>r.day>=shift(day,-13)&&r.day<shift(day,-6));
 const avg=(a:typeof weights)=>a.reduce((s,w)=>s+w.value,0)/a.length;
 const energy=profile&&weight&&height?estimate({...profile,weight:weight.value,height:height.value}):null;
 return {height,weight,waist:waist?{value:waist.data.waist!,day:waist.day}:null,energy,profile,
  bmi:weight&&height?weight.value/((height.value/100)**2):null,
  week:current.length?avg(current):null,n:current.length,previousN:previous.length,
  weeklyChange:current.length>=2&&previous.length>=2?avg(current)-avg(previous):null,
  sinceStart:weights.length>=2?weights[0].value-weights.at(-1)!.value:null,
  baseline:weights.at(-1),latestWeighIn:weights[0]};
}
