import dishes from "./data/indian-rolls.json";
import {makePanelFood, panelSchema} from "./nutrition";
import type {LibraryFood} from "./regional";

export const rollGroup = "Indian rolls";

export const rollFoods: LibraryFood[] = dishes.map(dish => {
  const panel = panelSchema.parse({
    kind: "Recipe estimate", unit: "g", amount: dish.grams, values: dish.values,
    detail: dish.detail, links: dish.links, checked: "2026-11-28",
    source: "https://www.ars.usda.gov/ARSUserFiles/80400525/Data/SR/SR28/dnload/sr28abbr.zip"
  });
  return {
    ...makePanelFood(dish.name, "1 roll", dish.grams, panel, "🌯"),
    group: rollGroup, tags: ["Indian lunch", "Indian snacks"], aliases: dish.aliases
  };
});
