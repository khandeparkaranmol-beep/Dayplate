"use client";
import {useState,useEffect,useRef,useCallback} from "react";
import {LayoutDashboard,BookOpen,LibraryBig,TrendingUp,SlidersHorizontal,Plus,CalendarDays,ChevronLeft,ChevronRight,ChevronDown,Sunrise,Sun,MoonStar,Apple,Flame,Target,Scale,Footprints,Check,X,Trash2,Pencil,Utensils,Beef,Wheat,Droplet,LockKeyhole,RefreshCw,Bookmark,ChartColumn} from "lucide-react";
import {Friends} from "./Friends";
import { Users,Download } from "lucide-react";
import {catalog} from "./catalog";
import {type Entry,type Stored,type Food,type Meal,meals,dateKey,shift,totals,targetAt,format,foodEntries,recordSchema,completeDay,diarySignature} from "./model";
import {TargetForm,CheckInForm,FoodForm} from "./forms";
import {LibraryView,ProgressView} from "./views";
import {MeasureForm,HealthPanel} from "./HealthPanel";
import {DailyNutrients} from "./NutrientTable";
import {DailyBudget,FeaturedDish,WeekStrip} from "./JournalSpread";
import {Movement,duration} from "./Movement";

import {RepeatMeal} from "./RepeatMeal";
import {previousMeals,type FoodEntry} from "./repeat";
import {foodKey,formatDaily,dayNutrient} from "./nutrition";
import {FoodIcon,Empty} from "./ui";
const navigation=[{name:"Overview",Icon:LayoutDashboard},{name:"Food library",Icon:LibraryBig},{name:"Movement",Icon:Footprints},{name:"Progress",Icon:TrendingUp},{name:"Friends",Icon:Users}] as const;
type View=(typeof navigation)[number]["name"];
type Dialog={type:"food",meal:Meal,food?:Food,edit?:Extract<Stored,{kind:"food"}>}|{type:"repeat",meal:Meal}|{type:"target"|"weight"|"exercise"|"create"|"backup"|"measure"|"package"};
const mealIcons=[Sunrise,Sun,MoonStar,Apple];
const defaultMeal=():Meal=>{const h=new Date().getHours();return h<11?"Breakfast":h<15?"Lunch":h<18?"Snacks":"Dinner"};
const plural=(n:number,word:string)=>n+" "+word+(n===1?"":"s");
function uniqueFoods(foods:Food[]) {return [...new Map(foods.map(f=>[foodKey(f),f])).values()]}
type DeviceOptions={online?:boolean,request?:(url:string,init?:RequestInit)=>Promise<Response>,backup?:React.ComponentType<{close:()=>void,refresh:()=>Promise<void>}>};
const networkRequest=(url:string,init?:RequestInit)=>fetch(url,init);
export default function Journal({request=networkRequest,backup:Backup,online=false}:DeviceOptions={}) {
 const [rows,setRows]=useState<Stored[]>([]),[day,setDay]=useState(""),[view,setView]=useState<View>("Overview"),[dialog,setDialog]=useState<Dialog|null>(null),[busy,setBusy]=useState(false),[ready,setReady]=useState(false),[error,setError]=useState(""),[toast,setToast]=useState(""),[openMeals,setOpenMeals]=useState<string[]>([]),[quickTab,setQuickTab]=useState("Staples");
 const lock=useRef(false),dateInput=useRef<HTMLInputElement>(null),requestEpoch=useRef(0);
 const load=useCallback(async()=>{const ticket=++requestEpoch.current;try{const r=await request("/api/journal",{cache:"no-store"});if(!r.ok)throw Error("Your journal could not be loaded. Retry to see your saved entries.");const data=await r.json();if(!Array.isArray(data))throw Error("Please refresh to sign in again.");if(ticket===requestEpoch.current){setRows(data);setReady(true);setError("")}}catch(e){if(ticket===requestEpoch.current)setError((e as Error).message)}},[request]);
 useEffect(()=>{setDay(dateKey());void load();const refresh=()=>{if(document.visibilityState==="visible"&&!lock.current)void load()};document.addEventListener("visibilitychange",refresh);return()=>document.removeEventListener("visibilitychange",refresh)},[load]);
 useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(""),3600);return()=>clearTimeout(t)},[toast]);
 useEffect(()=>{if(!dialog) setOpenMeals([])},[day]);
 async function mutate(body:object,entry:Entry|null,id:string,msg:string) {
  if(lock.current||!ready)return false;lock.current=true;setBusy(true);setError("");++requestEpoch.current;
  try{const r=await request("/api/journal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});let data;try{data=await r.json() as {error?:string,revision:number}}catch{throw Error("Could not save. Check your connection and retry.")}
   if(!r.ok){if(r.status===409)await load();throw Error(data.error||"Could not save your change.")}
   setRows(old=>[...old.filter(v=>v.id!==id),...(entry?[{...entry,revision:data.revision}]:[])]);setDialog(null);setToast(msg);if(entry?.kind==="food"){setOpenMeals(o=>[...new Set([...o,entry.data.meal])]);setView("Overview")}return true;
  }catch(e){setError((e as Error).message);return false}finally{lock.current=false;setBusy(false)}
 }
 async function save(entry:Entry,msg:string){if(!recordSchema.safeParse(entry).success){setError("Check the values in this entry.");return false}const revision=rows.find(r=>r.id===entry.id)?.revision||0;return mutate({action:"put",entry,revision},entry,entry.id,msg)}
 const remove=(r:Stored)=>mutate({action:"delete",id:r.id,revision:r.revision},null,r.id,"Entry removed");
 const close=()=>{if(!lock.current){setDialog(null);setError("")}};
 const selected=day||dateKey(),today=dateKey(),dayRows=rows.filter(r=>r.day===selected),foodRows=foodEntries(dayRows),t=totals(dayRows),target=targetAt(rows,selected),budget=target?.data.calories??0,remaining=budget-t.kcal;
 const customs=rows.flatMap(r=>r.kind==="saved"?[r.data]:r.kind==="food"&&r.data.custom?[r.data.food]:[]);
 const foods=uniqueFoods([...catalog,...customs]), recent=uniqueFoods(foodEntries(rows).filter(r=>r.day<=selected).sort((a,b)=>b.day.localeCompare(a.day)).map(r=>r.data.food)).slice(0,4);
 const staples=["Kanda pohe","Goan fish curry rice","Grilled chicken breast","Parle-G Original Gluco Biscuits"].map(name=>catalog.find(f=>f.name===name)!);
 const isToday=selected===today;
 const dateText=new Date(selected+"T12:00:00").toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
 const [reviewDay,backToReview]=useState<{day:string,view:View}|null>(null);
 const navigate=(n:View)=>{setView(n);backToReview(null);window.scrollTo({top:0,behavior:"instant"})};
 const showFood=(f?:Food,m:Meal=defaultMeal())=>{if(ready)setDialog({type:"food",meal:m,food:f})};
 const launch=(type:"target"|"weight"|"exercise"|"create"|"measure"|"package")=>{if(ready)setDialog({type})};
 async function repeat(entries:FoodEntry[]){
   if(lock.current||!ready)return false;
   lock.current=true;setBusy(true);setError("");++requestEpoch.current;
   try{
     const res=await request("/api/journal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"repeat",entries})});
     if(!res.ok)throw Error(((await res.json()) as {error?:string}).error||"Could not add this meal.");
     await load();setDialog(null);setOpenMeals([entries[0].data.meal]);setView("Overview");setToast(entries[0].data.meal+" added · "+entries.length+" foods");return true;
   }catch(e){setError((e as Error).message);return false}finally{lock.current=false;setBusy(false)}
 }
 const dates=<div className="date-select"><button title="Previous day" aria-label="Previous day" onClick={()=>setDay(shift(selected,-1))}><ChevronLeft size={16}/></button><label title="Choose date"><CalendarDays size={16}/><span>{isToday?"Today":new Date(selected+"T12:00:00").toLocaleDateString("en-GB",{month:"short",day:"numeric"})}</span><input aria-label="Choose diary date" ref={dateInput} type="date" value={selected} max={today} onClick={()=>{try{dateInput.current?.showPicker()}catch{}}} onChange={e=>{if(e.target.value&&e.target.value<=today)setDay(e.target.value)}}/></label><button disabled={isToday} aria-label="Next day" onClick={()=>setDay(shift(selected,1))}><ChevronRight size={16}/></button></div>;
 const finishedDay=completeDay(rows,selected),review=rows.find(r=>r.kind==="review"&&r.day===selected);
 const diary=<section className="panel diary"><div className="section-head"><div className="title-line"><BookOpen size={20}/><h2>On your plate</h2></div>{previousMeals(rows,selected).length?<button className="light" onClick={()=>setDialog({type:"repeat",meal:defaultMeal()})}>Repeat a meal</button>:<span className="count">{plural(foodRows.length,"food")}</span>}</div>{meals.map((m,i)=>{const items=foodRows.filter(r=>r.data.meal===m),Icon=mealIcons[i],opened=openMeals.includes(m);
 return <div key={m} className="meal"><div className="meal-line"><button className="meal-main" aria-expanded={items.length?opened:undefined} onClick={()=>items.length?setOpenMeals(o=>opened?o.filter(x=>x!==m):[...o,m]):showFood(undefined,m)}><span className={"meal-icon m"+i}><Icon size={22}/></span><span><b>{m}</b><small>{items.length?items.map(r=>r.data.food.name).join(" · "):"Add "+m.toLowerCase()}</small></span></button><span className="meal-kcal">{items.length?<>{format(totals(items).kcal)} <small>kcal</small></>:null}</span><button className="circle-add" onClick={()=>showFood(undefined,m)} aria-label={"Add food to "+m}><Plus size={17}/></button></div>{opened&&items.length>0&&<div className="logged">{items.map(r=><button key={r.id} onClick={()=>setDialog({type:"food",meal:m,edit:r})}><span className="grow"><b>{r.data.food.name}</b><small>{Number(r.data.quantity.toFixed(2))} × {r.data.food.serving}</small></span><span>{format(r.data.quantity*r.data.food.kcal)} kcal</span><Pencil size={13}/></button>)}</div>}</div>})}{foodRows.length>0&&<div className="day-finish"><span>{finishedDay?"Day marked complete":review?"Diary updated since last review":"Finished logging for this day?"}</span><button className="text-btn" disabled={busy} onClick={()=>finishedDay&&review?void remove(review):void save({id:"review-"+selected,day:selected,kind:"review",data:{signature:diarySignature(rows,selected)}},"Day marked complete")}>{finishedDay?"Reopen day":"Mark complete"}</button></div>}</section>;
 const macros=<section className="panel macro-panel"><div className="section-head"><div className="title-line"><ChartColumn size={20}/><h2>Macronutrients</h2></div></div><div className="macro-list">{[{title:"Protein",key:"p",Icon:Beef,col:"protein",cal:t.p*4},{title:"Carbs",key:"c",Icon:Wheat,col:"carbs",cal:t.c*4},{title:"Fat",key:"f",Icon:Droplet,col:"fat",cal:t.f*9}].map(a=><div className={"macro "+a.col} key={a.key}><div className="macro-name"><i><a.Icon size={15}/></i><span>{a.title}</span><b>{foodRows.length?formatDaily(dayNutrient(dayRows,a.key)):"0"} <small>g</small></b></div><div className="track"><span style={{width:100*a.cal/(t.p*4+t.c*4+t.f*9||1)+"%"}}/></div></div>)}</div><small className="macro-foot">{t.partial?"Some entries have incomplete macro values.":"Bars show each macro’s share of logged macro calories."}</small></section>;
 const quick=<section className="panel quick"><div className="section-head"><div className="title-line"><Bookmark size={19}/><h2>Quick plate</h2></div></div><div className="quick-tabs">{["Staples","Recent"].map(q=><button key={q} className={quickTab===q?"active":""} onClick={()=>setQuickTab(q)}>{q}</button>)}</div><div>{(quickTab==="Recent"?recent:staples).map(f=><button key={foodKey(f)} className="pick" onClick={()=>showFood(f)}><FoodIcon food={f}/><span className="grow"><b>{f.name}</b><small>{f.serving} · {format(f.kcal)} kcal</small></span><Plus size={15}/></button>)}{quickTab==="Recent"&&!recent.length&&<Empty>Foods you log will appear here for next time.</Empty>}</div></section>;
 return <div className="shell"><aside className="sidebar"><div className="brand"><img alt="" src="/favicon.svg"/><span>Dayplate</span></div><nav aria-label="Main navigation">{navigation.map(n=><button key={n.name} onClick={()=>navigate(n.name)} aria-current={view===n.name?"page":undefined} className={view===n.name?"nav-active":""}><n.Icon size={19}/><span>{n.name==="Overview"?"Journal":n.name==="Food library"?"Foods":n.name}</span></button>)}</nav><div className="side-bottom">{Backup&&<button onClick={()=>setDialog({type:"backup"})}><Download size={18}/>{online?"Your account":"Backup & restore"}</button>}<button onClick={()=>launch("target")}><SlidersHorizontal size={18}/>Daily target</button><div className="privacy"><LockKeyhole size={14}/>Private journal</div></div></aside>
 <main><div className="mobile-brand"><div className="brand"><img alt="" src="/favicon.svg"/><span>Dayplate</span></div><div className="head-actions">{Backup&&<button aria-label={online?"Your account":"Backup and restore"} onClick={()=>setDialog({type:"backup"})}><Download size={18}/></button>}<button onClick={()=>launch("target")} aria-label="Daily target"><SlidersHorizontal size={19}/></button></div></div><div className="main-wrap"><header className="page-head"><div><p className="date-caption">{view==="Food library"?"Your food collection":day?dateText:"Personal journal"}</p><h1>{view==="Overview"?(isToday?"Today":"Daily journal"):view}</h1></div><div className="head-actions">{view!=="Food library"&&view!=="Friends"&&dates}{view!=="Friends"&&<button className="primary head-log" disabled={!ready} onClick={()=>view==="Movement"?launch("exercise"):showFood()}><Plus size={18}/>{view==="Movement"?"Log workout":"Log food"}</button>}</div></header>
 {error&&!dialog&&<div className="error" role="alert">{error}<button onClick={()=>void load()}>Reload diary</button></div>}
 {!ready?<div className="panel loading" role="status">{error?"Diary unavailable":"Opening your journal…"}</div>:<>
 {view==="Overview"&&<>{reviewDay&&<button className="text-btn back" onClick={()=>{setDay(reviewDay.day);navigate(reviewDay.view)}}><ChevronLeft size={16}/>Back to {reviewDay.view.toLowerCase()}</button>}<WeekStrip day={selected} today={today} rows={rows} onDay={setDay}/><div className="journal-spread"><FeaturedDish key={selected} choose={f=>showFood(f)} entries={foodRows} edit={row=>setDialog({type:"food",meal:row.data.meal,edit:row})}/><DailyBudget rows={dayRows} budget={budget} proteinGoal={target?.data.proteinGoal} target={()=>launch("target")}/></div><div className="dash-grid"><div className="stack">{diary}<section className="panel checkins"><div className="section-head"><h2>Body & movement</h2><button className="text-btn" onClick={()=>navigate("Progress")}>Review my week</button></div><div className="checkin-pair"><button onClick={()=>launch("weight")}><Scale/><span><b>Body weight</b><small>{dayRows.find(r=>r.kind==="weight")?.data.kg?dayRows.find(r=>r.kind==="weight")?.data.kg+" kg":"Log weight"}</small></span><Plus size={15}/></button><button onClick={()=>navigate("Movement")}><Footprints/><span><b>Activity</b><small>{dayRows.some(r=>r.kind==="exercise")?duration(dayRows.filter(r=>r.kind==="exercise").reduce((a,r)=>a+r.data.minutes,0)):"Open movement"}</small></span><Plus size={15}/></button></div>{dayRows.filter(r=>r.kind==="exercise").map(r=><button className="journal-session" key={r.id} onClick={()=>navigate("Movement")}><Footprints size={15}/>{r.data.name}<small>{duration(r.data.minutes)}{r.data.health?" · Apple Health":""}</small></button>)}</section></div><div className="stack"><DailyNutrients rows={dayRows} proteinGoal={target?.data.proteinGoal}/>{quick}<details className="macro-detail"><summary>Macronutrient breakdown</summary>{macros}</details></div></div></>}
 {view==="Food library"&&<LibraryView foods={foods} choose={f=>showFood(f)} create={()=>launch("create")} product={()=>launch("package")}/>}
 {view==="Friends"&&<Friends rows={rows} online={online}/>}
 {view==="Movement"&&<><Movement request={request} refresh={load} rows={rows} day={selected} log={()=>launch("exercise")} journal={d=>{backToReview({day:selected,view});setDay(d);setView("Overview");window.scrollTo({top:0,behavior:"instant"})}}/></>}
 {view==="Progress"&&<><ProgressView rows={rows} day={selected} weight={()=>launch("weight")} exercise={()=>launch("exercise")} remove={remove} busy={busy} openDay={d=>{backToReview({day:selected,view});setDay(d);setView("Overview");window.scrollTo({top:0,behavior:"instant"})}}/><HealthPanel rows={rows} day={selected} measure={()=>launch("measure")} target={()=>launch("target")}/></>}</>}
 </div></main>{toast&&<div className="toast" role="status"><Check size={17}/>{toast}</div>}
 {(dialog?.type==="food"||dialog?.type==="create"||dialog?.type==="package")&&<FoodForm key={dialog.type} day={selected} foods={foods} initial={dialog.type==="food"?dialog.food:undefined} edit={dialog.type==="food"?dialog.edit:undefined} meal={dialog.type==="food"?dialog.meal:defaultMeal()} libraryOnly={dialog.type==="create"} startLabel={dialog.type==="package"} startCustom={dialog.type==="create"} remove={remove} busy={busy} save={save} close={close} dayCalories={t.kcal} target={budget||undefined} dayProtein={dayNutrient(dayRows,"p")} proteinGoal={target?.data.proteinGoal}/>}
 {dialog?.type==="repeat"&&<RepeatMeal rows={rows} day={selected} meal={dialog.meal} busy={busy} close={close} save={repeat}/>}
 {dialog?.type==="target"&&<TargetForm day={selected} rows={rows} existing={target} busy={busy} save={save} close={close}/>}
 {(dialog?.type==="weight"||dialog?.type==="exercise")&&<CheckInForm kind={dialog.type} day={selected} rows={rows} busy={busy} save={save} close={close}/>}
 {dialog?.type==="measure"&&<MeasureForm rows={rows} day={selected} busy={busy} save={save} close={close}/>}
 {dialog?.type==="backup"&&Backup&&<Backup close={close} refresh={load}/>}
 {error&&dialog&&<DialogError message={error}/>}
 </div>
}
function DialogError({message}:{message:string}){useEffect(()=>{const d=document.querySelector("dialog");if(!d)return;const e=document.createElement("p");e.className="error";e.setAttribute("role","alert");e.textContent=message;d.appendChild(e);e.scrollIntoView({block:"nearest"});return()=>{e.remove()}},[message]);return null}
