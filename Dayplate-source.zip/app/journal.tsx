"use client";
import {distinctFoods} from "./nutrition";
import {useState,useEffect,useRef,useCallback,useMemo} from "react";
import {LayoutDashboard,BookOpen,LibraryBig,TrendingUp,SlidersHorizontal,Plus,CalendarDays,ChevronLeft,ChevronRight,ChevronDown,Sunrise,Sun,MoonStar,Apple,Flame,Target,Scale,Footprints,Check,X,Trash2,Pencil,Utensils,LockKeyhole,RefreshCw,Bookmark} from "lucide-react";
import {KitchenCard,KitchenShelf,MealPlanner,RecipeForm} from "./KitchenViews";
import {recipePortion,type Recipe,type Plan} from "./kitchen";
import {VarietyForm,VarietySummary} from "./FoodVariety";
import {WeeklyReview} from "./WeeklyReview";
import {type Experiment} from "./week-story";
import {BreakfastStudy,HungerForm,StudyForm,todaysStudy} from "./BreakfastStudy";
import {BuddyReminder} from "./BuddyPlans";
import {DayReceipt} from "./DayReceipt";
import {DayLinkDialog} from "./DayLinkDialog";
import {Share2} from "lucide-react";
import {ShareLoggedUpdate} from "./ShareLoggedUpdate";
import type {LogPick} from "./logged-update";
import {Friends} from "./Friends";
import { Users,Download } from "lucide-react";
import {catalog,refreshCafeSugars} from "./catalog";
import {type Entry,type Stored,type Food,type Meal,meals,dateKey,shift,totals,targetAt,format,foodEntries,recordSchema,completeDay,diarySignature} from "./model";
import {TargetForm,CheckInForm,FoodForm} from "./forms";
import {LibraryView,ProgressView} from "./views";
import {MeasureForm,HealthPanel} from "./HealthPanel";
import {defaultMealNutrients,MealNutrients,MealNutrientPicker,foodNutrientLine} from "./MealNutrients";
import {DailyNutrients} from "./NutrientTable";
import {DailyBudget,FeaturedDish,WeekStrip} from "./JournalSpread";
import {Movement,duration} from "./Movement";

import {BreakfastRoutine} from "./BreakfastRoutine";
import {RepeatMeal} from "./RepeatMeal";
import {previousMeals,type FoodEntry} from "./repeat";
import {foodKey,dayNutrient,sugarSummary} from "./nutrition";
import {WorkoutForm} from "./WorkoutForm";
import {burnLabel} from "./workout-energy";
import {MacroBreakdown} from "./MacroBreakdown";
import {FoodIcon,Empty} from "./ui";
const navigation=[{name:"Overview",Icon:LayoutDashboard},{name:"Food library",Icon:LibraryBig},{name:"Movement",Icon:Footprints},{name:"Progress",Icon:TrendingUp},{name:"Friends",Icon:Users}] as const;
type View=(typeof navigation)[number]["name"];
type ExerciseRow=Extract<Stored,{kind:"exercise"}>;
type Dialog={type:"dayLink"}|{type:"share",pick?:LogPick}|{type:"package",name?:string}|{type:"recipe",edit?:Recipe}|{type:"plan",edit?:Plan}|{type:"experiment"|"variety"}|{type:"hunger",study:Experiment}|{type:"food",meal:Meal,food?:Food,edit?:Extract<Stored,{kind:"food"}>}|{type:"repeat",meal:Meal}|{type:"exercise",edit?:ExerciseRow}|{type:"target"|"weight"|"create"|"backup"|"measure"|"mealNutrients"};
const mealIcons=[Sunrise,Sun,MoonStar,Apple];
const defaultMeal=():Meal=>{const h=new Date().getHours();return h<11?"Breakfast":h<15?"Lunch":h<18?"Snacks":"Dinner"};
const plural=(n:number,word:string)=>n+" "+word+(n===1?"":"s");
type DeviceOptions={online?:boolean,request?:(url:string,init?:RequestInit)=>Promise<Response>,backup?:React.ComponentType<{close:()=>void,refresh:()=>Promise<void>}>};
const networkRequest=(url:string,init?:RequestInit)=>fetch(url,init);
export default function Journal({request=networkRequest,backup:Backup,online=false}:DeviceOptions={}) {
 const [rows,setRows]=useState<Stored[]>([]),[day,setDay]=useState(""),[view,setView]=useState<View>("Overview"),[dialog,setDialog]=useState<Dialog|null>(null),[busy,setBusy]=useState(false),[ready,setReady]=useState(false),[error,setError]=useState(""),[toast,setToast]=useState(""),[openMeals,setOpenMeals]=useState<string[]>([]),[quickTab,setQuickTab]=useState("Staples");
 const [feedVersion,refreshFeed]=useState(0);
 const share=(pick?:LogPick)=>setDialog({type:"share",pick});
 const lock=useRef(false),dateInput=useRef<HTMLInputElement>(null),requestEpoch=useRef(0);
 const load=useCallback(async()=>{const ticket=++requestEpoch.current;try{const r=await request("/api/journal",{cache:"no-store"});if(!r.ok)throw Error("Your journal could not be loaded. Retry to see your saved entries.");const data=await r.json();if(!Array.isArray(data))throw Error("Please refresh to sign in again.");if(ticket===requestEpoch.current){setRows(data.map(refreshCafeSugars));setReady(true);setError("")}}catch(e){if(ticket===requestEpoch.current)setError((e as Error).message)}},[request]);
 useEffect(()=>{setDay(dateKey());void load();const refresh=()=>{if(document.visibilityState==="visible"&&!lock.current)void load()};document.addEventListener("visibilitychange",refresh);return()=>document.removeEventListener("visibilitychange",refresh)},[load]);
 useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(""),3600);return()=>clearTimeout(t)},[toast]);

 async function mutate(body:object,entry:Entry|null,id:string,msg:string) {
  if(lock.current||!ready)return false;lock.current=true;setBusy(true);setError("");++requestEpoch.current;
  try{const r=await request("/api/journal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});let data;try{data=await r.json() as {error?:string,revision:number}}catch{throw Error("Could not save. Check your connection and retry.")}
   if(!r.ok){if(r.status===409)await load();throw Error(data.error||"Could not save your change.")}
   setRows(old=>[...old.filter(v=>v.id!==id),...(entry?[{...entry,revision:data.revision}]:[])]);setDialog(null);setToast(msg);
   if(entry?.kind==="food"){setOpenMeals(o=>[...new Set([...o,entry.data.meal])]);setView("Overview");requestAnimationFrame(()=>document.getElementById("journal-meal-"+entry.data.meal)?.scrollIntoView({block:"nearest"}))}return true;
  }catch(e){setError((e as Error).message);return false}finally{lock.current=false;setBusy(false)}
 }
 async function save(entry:Entry,msg:string,expected?:number){if(!recordSchema.safeParse(entry).success){setError("Check the values in this entry.");return false}const revision=expected??rows.find(r=>r.id===entry.id)?.revision??0;return mutate({action:"put",entry,revision},entry,entry.id,msg)}
 const remove=(r:Stored)=>mutate({action:"delete",id:r.id,revision:r.revision},null,r.id,"Entry removed");
 const close=()=>{if(!lock.current){setDialog(null);setError("")}};
 const selected=day||dateKey(),today=dateKey(),dayRows=rows.filter(r=>r.day===selected),foodRows=foodEntries(dayRows),t=totals(dayRows),target=targetAt(rows,selected),budget=target?.data.calories??0,remaining=budget-t.kcal;
 const foods=useMemo(()=>{
   const customs=rows.flatMap(r=>r.kind==="saved"?[r.data]:r.kind==="food"&&r.data.custom?[r.data.food]:[]);
   const recipes=rows.filter(r=>r.kind==="recipe").flatMap(r=>recipePortion(r.data)??[]);
   if(!customs.length&&!recipes.length)return catalog;
   return distinctFoods([...recipes,...catalog,...customs]);
 },[rows]);
 const recent=distinctFoods(foodEntries(rows).filter(r=>r.day<=selected).sort((a,b)=>b.day.localeCompare(a.day)).map(r=>r.data.food)).slice(0,4);
 const staples=["Kanda pohe","Goan fish curry rice","Grilled chicken breast","Parle-G Original Gluco Biscuits"].map(name=>catalog.find(f=>f.name===name)!);
 const isToday=selected===today;
 const dateText=new Date(selected+"T12:00:00").toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
 const [reviewDay,backToReview]=useState<{day:string,view:View}|null>(null);
 const navigate=(n:View)=>{setView(n);backToReview(null);window.scrollTo({top:0,behavior:"instant"})};
 const showFood=(f?:Food,m:Meal=defaultMeal())=>{if(ready)setDialog({type:"food",meal:m,food:f})};
 const launch=(type:"target"|"weight"|"exercise"|"create"|"measure"|"package")=>{if(ready)setDialog({type})};
 async function repeat(entries:FoodEntry[],consume?:{id:string,revision:number}){
   if(lock.current||!ready)return false;
   lock.current=true;setBusy(true);setError("");++requestEpoch.current;
   try{
     const res=await request("/api/journal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"repeat",entries,consume})});
     if(!res.ok){if(res.status===409)await load();throw Error(((await res.json()) as {error?:string}).error||"Could not add this meal.")}
     await load();setDialog(null);setOpenMeals([entries[0].data.meal]);setView("Overview");setToast(entries[0].data.meal+" added · "+entries.length+" foods");return true;
   }catch(e){setError((e as Error).message);return false}finally{lock.current=false;setBusy(false)}
 }
 const dates=<div className="date-select"><button title="Previous day" aria-label="Previous day" onClick={()=>setDay(shift(selected,-1))}><ChevronLeft size={16}/></button><label title="Choose date"><CalendarDays size={16}/><span>{isToday?"Today":new Date(selected+"T12:00:00").toLocaleDateString("en-GB",{month:"short",day:"numeric"})}</span><input aria-label="Choose diary date" ref={dateInput} type="date" value={selected} max={today} onClick={()=>{try{dateInput.current?.showPicker()}catch{}}} onChange={e=>{if(e.target.value&&e.target.value<=today)setDay(e.target.value)}}/></label><button disabled={isToday} aria-label="Next day" onClick={()=>setDay(shift(selected,1))}><ChevronRight size={16}/></button></div>;
 const finishedDay=completeDay(rows,selected),review=rows.find(r=>r.kind==="review"&&r.day===selected);
 const mealSettings=rows.find(r=>r.kind==="mealNutrients")?.data;
 const mealKeys=mealSettings?.keys??defaultMealNutrients;
 const study=todaysStudy(rows,selected);
 const openDiary=(d:string)=>{backToReview({day:selected,view});setDay(d);setView("Overview");setOpenMeals(["Breakfast"]);window.scrollTo({top:0,behavior:"instant"})};
 const dayShare=<button type="button" className="light day-share-button" onClick={()=>setDialog({type:"dayLink"})}><Share2 size={16}/> Share my day</button>;
 const diary=<section className="panel diary"><div className="section-head"><div className="title-line"><BookOpen size={20}/><h2>Your meals</h2></div><div className="meal-tools">{dayShare}<button className="text-btn" onClick={()=>setDialog({type:"mealNutrients"})}><SlidersHorizontal size={15}/>Meal nutrients</button>{previousMeals(rows,selected).length?<button className="light" onClick={()=>setDialog({type:"repeat",meal:defaultMeal()})}>Repeat a meal</button>:null}</div></div>{meals.map((m,i)=>{const items=foodRows.filter(r=>r.data.meal===m),Icon=mealIcons[i],opened=openMeals.includes(m);
 return <div key={m} className="meal" id={"journal-meal-"+m}><div className="meal-line"><button className="meal-main" aria-expanded={items.length?opened:undefined} onClick={()=>items.length?setOpenMeals(o=>opened?o.filter(x=>x!==m):[...o,m]):showFood(undefined,m)}><span className={"meal-icon m"+i}><Icon size={22}/></span><span><b>{m}</b><small>{items.length?items.map(r=>r.data.food.name).join(" · "):"Add "+m.toLowerCase()}</small></span></button><span className="meal-kcal">{items.length?<>{format(totals(items).kcal)} <small>kcal</small></>:null}</span><button className="circle-add" onClick={()=>showFood(undefined,m)} aria-label={"Add food to "+m}><Plus size={17}/></button></div><MealNutrients foods={items} keys={mealKeys} columns={mealSettings?.columns} meal={m}/>{opened&&items.length>0&&<div className="logged">{items.map(r=><button key={r.id} onClick={()=>setDialog({type:"food",meal:m,edit:r})}><span className="grow"><b>{r.data.food.name}</b><small>{Number(r.data.quantity.toFixed(2))} × {r.data.food.serving}{mealKeys.length>0&&" · "+foodNutrientLine(r,mealKeys)}</small></span><span>{format(r.data.quantity*r.data.food.kcal)} kcal</span><Pencil size={13}/></button>)}{online&&<div className="meal-share-action"><button className="light" type="button" onClick={()=>share({kind:"meal",day:selected,meal:m})}>Share {m.toLowerCase()}</button></div>}</div>}</div>})}{finishedDay&&<DayReceipt foods={foodRows} keys={mealKeys} open={m=>{setOpenMeals(o=>[...new Set([...o,m])]);document.getElementById("journal-meal-"+m)?.scrollIntoView({block:"center"})}}/>}{foodRows.length>0&&<div className="day-finish"><span>{finishedDay?"Need to change something?":review?"Diary updated since last review":"Finished logging for this day?"}</span><button type="button" className={finishedDay?"light day-complete":"primary day-complete"} disabled={busy} onClick={()=>finishedDay&&review?void remove(review):void save({id:"review-"+selected,day:selected,kind:"review",data:{signature:diarySignature(rows,selected)}},"Day marked complete")}>{finishedDay?<RefreshCw size={16}/>:<Check size={18}/>} {finishedDay?"Reopen day":"Mark complete"}</button></div>}</section>;
 const quick=<section className="panel quick"><div className="section-head"><div className="title-line"><Bookmark size={19}/><h2>Quick plate</h2></div></div><div className="quick-tabs">{["Staples","Recent"].map(q=><button key={q} className={quickTab===q?"active":""} onClick={()=>setQuickTab(q)}>{q}</button>)}</div><div>{(quickTab==="Recent"?recent:staples).map(f=><button key={foodKey(f)} className="pick" onClick={()=>showFood(f)}><FoodIcon food={f}/><span className="grow"><b>{f.name}</b><small>{f.serving} · {format(f.kcal)} kcal · {sugarSummary(f)}</small></span><Plus size={15}/></button>)}{quickTab==="Recent"&&!recent.length&&<Empty>Foods you log will appear here for next time.</Empty>}</div></section>;
 return <div className="shell"><aside className="sidebar"><div className="brand"><img alt="" src="/favicon.svg"/><span>Dayplate</span></div><nav aria-label="Main navigation">{navigation.map(n=><button key={n.name} onClick={()=>navigate(n.name)} aria-current={view===n.name?"page":undefined} className={view===n.name?"nav-active":""}><n.Icon size={19}/><span>{n.name==="Overview"?"Journal":n.name==="Food library"?"Foods":n.name}</span></button>)}</nav><div className="side-bottom">{Backup&&<button onClick={()=>setDialog({type:"backup"})}><Download size={18}/>{online?"Your account":"Backup & restore"}</button>}<button onClick={()=>launch("target")}><SlidersHorizontal size={18}/>Daily target</button><div className="privacy"><LockKeyhole size={14}/>Private journal</div></div></aside>
 <main><div className="mobile-brand"><div className="brand"><img alt="" src="/favicon.svg"/><span>Dayplate</span></div><div className="head-actions">{Backup&&<button aria-label={online?"Your account":"Backup and restore"} onClick={()=>setDialog({type:"backup"})}><Download size={18}/></button>}<button onClick={()=>launch("target")} aria-label="Daily target"><SlidersHorizontal size={19}/></button></div></div><div className="main-wrap"><header className="page-head"><div><p className="date-caption">{view==="Food library"?"Your food collection":day?dateText:"Personal journal"}</p><h1>{view==="Overview"?(isToday?"Today":"Daily journal"):view}</h1></div><div className="head-actions">{view!=="Food library"&&view!=="Friends"&&dates}{view!=="Friends"&&<button className="primary head-log" disabled={!ready} onClick={()=>view==="Movement"?launch("exercise"):view==="Progress"?launch("weight"):showFood()}><Plus size={18}/>{view==="Movement"?"Log workout":view==="Progress"?"Log weight":"Log food"}</button>}</div></header>
 {error&&!dialog&&<div className="error" role="alert">{error}<button onClick={()=>void load()}>Reload diary</button></div>}
 {!ready?<div className="panel loading" role="status">{error?"Diary unavailable":"Opening your journal…"}</div>:<div className={"view-body "+(view==="Food library"?"foods-view":view.toLowerCase()+"-view")}>
 {view==="Overview"&&<>{reviewDay&&<button className="text-btn back" onClick={()=>{setDay(reviewDay.day);navigate(reviewDay.view)}}><ChevronLeft size={16}/>Back to {reviewDay.view.toLowerCase()}</button>}<WeekStrip day={selected} today={today} rows={rows} onDay={setDay}/><div className="day-core"><DailyBudget rows={dayRows} budget={budget} proteinGoal={target?.data.proteinGoal} target={()=>launch("target")}/>{diary}</div>{online&&isToday&&<BuddyReminder open={()=>navigate("Friends")}/>}<KitchenCard rows={rows} day={selected} plan={edit=>setDialog({type:"plan",edit})} kitchen={()=>{navigate("Food library");requestAnimationFrame(()=>{const shelf=document.querySelector<HTMLDetailsElement>(".tools-fold");if(shelf)shelf.open=true})}} review={()=>navigate("Progress")}/>{study&&!rows.some(r=>r.kind==="hunger"&&r.day===selected&&r.data.experiment===study.id)&&<div className="hunger-prompt"><span>Breakfast experiment · {study.data.first} / {study.data.second}</span><button className="text-btn" onClick={()=>setDialog({type:"hunger",study})}>Rate afternoon hunger</button></div>}<div className="dash-grid"><div className="stack">{isToday&&<BreakfastRoutine rows={rows} today={today} save={save} repeat={repeat} busy={busy} log={()=>showFood(undefined,"Breakfast")}/>} <section className="panel checkins"><div className="section-head"><h2>Body & movement</h2><button className="text-btn" onClick={()=>navigate("Progress")}>Review my week</button></div><div className="checkin-pair"><button onClick={()=>launch("weight")}><Scale/><span><b>Body weight</b><small>{dayRows.find(r=>r.kind==="weight")?.data.kg?dayRows.find(r=>r.kind==="weight")?.data.kg+" kg":"Log weight"}</small></span><Plus size={15}/></button><button onClick={()=>navigate("Movement")}><Footprints/><span><b>Activity</b><small>{dayRows.some(r=>r.kind==="exercise")?duration(dayRows.filter(r=>r.kind==="exercise").reduce((a,r)=>a+r.data.minutes,0)):"Open movement"}</small></span><Plus size={15}/></button></div>{dayRows.filter(r=>r.kind==="exercise").map(r=><button className="journal-session" key={r.id} onClick={()=>navigate("Movement")}><Footprints size={15}/>{r.data.name}<small>{duration(r.data.minutes)} · {burnLabel(r,rows)}</small></button>)}</section></div><div className="stack"><DailyNutrients rows={dayRows} proteinGoal={target?.data.proteinGoal}/>{quick}<FeaturedDish key={selected} choose={f=>showFood(f)} entries={foodRows} edit={row=>setDialog({type:"food",meal:row.data.meal,edit:row})}/><MacroBreakdown rows={dayRows} openMeal={m=>{setOpenMeals(o=>[...new Set([...o,m])]);document.getElementById("journal-meal-"+m)?.scrollIntoView({block:"center"})}}/></div></div></>}
 {view==="Food library"&&<><details className="tools-fold"><summary>My kitchen <small>Recipes and saved portions</small></summary><KitchenShelf rows={rows} create={()=>setDialog({type:"recipe"})} edit={edit=>setDialog({type:"recipe",edit})} log={f=>showFood(f)}/></details><LibraryView foods={foods} choose={f=>showFood(f)} create={()=>launch("create")} product={name=>{if(ready)setDialog({type:"package",name})}}/></>}
 {view==="Friends"&&<><div className="day-share-toolbar">{dayShare}</div><Friends rows={rows} online={online} save={save} share={()=>share()} refreshKey={feedVersion}/></>}
 {view==="Movement"&&<><Movement share={online?share:undefined} log={d=>{setDay(d);launch("exercise")}} request={request} refresh={load} rows={rows} day={selected} edit={r=>setDialog({type:"exercise",edit:r})} journal={d=>{backToReview({day:selected,view});setDay(d);setView("Overview");window.scrollTo({top:0,behavior:"instant"})}}/></>}
 {view==="Progress"&&<><WeeklyReview rows={rows} day={selected} keys={mealKeys} openDay={openDiary} configure={()=>setDialog({type:"mealNutrients"})}/><details className="tools-fold"><summary>Food experiments and variety</summary><BreakfastStudy rows={rows} day={selected} busy={busy} start={()=>setDialog({type:"experiment"})} rate={study=>setDialog({type:"hunger",study})} save={save}/><VarietySummary rows={rows} day={selected} edit={()=>setDialog({type:"variety"})}/></details><ProgressView rows={rows} day={selected} weight={()=>launch("weight")} exercise={()=>{navigate("Movement");launch("exercise")}} remove={remove} busy={busy} openDay={d=>{backToReview({day:selected,view});setDay(d);setView("Overview");window.scrollTo({top:0,behavior:"instant"})}}/><HealthPanel rows={rows} day={selected} measure={()=>launch("measure")} target={()=>launch("target")}/></>}</div>}
 </div></main>{toast&&<div className="toast" role="status"><Check size={17}/>{toast}</div>}
 {(dialog?.type==="food"||dialog?.type==="create"||dialog?.type==="package")&&<FoodForm key={dialog.type} day={selected} foods={foods} initial={dialog.type==="food"?dialog.food:undefined} edit={dialog.type==="food"?dialog.edit:undefined} meal={dialog.type==="food"?dialog.meal:defaultMeal()} libraryOnly={dialog.type==="create"} startLabel={dialog.type==="package"} packageName={dialog.type==="package"?dialog.name:undefined} startCustom={dialog.type==="create"} remove={remove} busy={busy} save={save} close={close} dayCalories={t.kcal} target={budget||undefined} dayProtein={dayNutrient(dayRows,"p")} proteinGoal={target?.data.proteinGoal}/>}
 {dialog?.type==="dayLink"&&<DayLinkDialog rows={rows} day={selected} online={online} close={close}/>}
 {dialog?.type==="share"&&online&&<ShareLoggedUpdate rows={rows} day={selected} initial={dialog.pick} close={close} openFriends={()=>{close();navigate("Friends")}} shared={message=>{setDialog(null);setToast(message);refreshFeed(n=>n+1)}}/>}
 {dialog?.type==="recipe"&&<RecipeForm rows={rows} foods={foods} edit={dialog.edit} day={selected} busy={busy} close={close} save={save} remove={remove}/>}
 {dialog?.type==="plan"&&<MealPlanner rows={rows} foods={foods} edit={dialog.edit} initial={defaultMeal()} day={selected} busy={busy} close={close} save={save} eat={repeat} remove={remove}/>}
 {dialog?.type==="variety"&&<VarietyForm rows={rows} day={selected} close={close} busy={busy} save={save}/>}
 {dialog?.type==="experiment"&&<StudyForm rows={rows} day={selected} busy={busy} close={close} save={save}/>}
 {dialog?.type==="hunger"&&<HungerForm rows={rows} study={dialog.study} day={selected} busy={busy} close={close} save={save} remove={remove}/>}
 {dialog?.type==="repeat"&&<RepeatMeal rows={rows} day={selected} meal={dialog.meal} busy={busy} close={close} save={repeat}/>}
 {dialog?.type==="mealNutrients"&&<MealNutrientPicker keys={mealKeys} columns={mealSettings?.columns} busy={busy} close={close} save={(keys,columns)=>void save({id:"meal-nutrients",kind:"mealNutrients",day:dateKey(),data:{keys,columns}},"Meal columns updated")}/>}
 {dialog?.type==="target"&&<TargetForm day={selected} rows={rows} existing={target} busy={busy} save={save} close={close}/>}
 {dialog?.type==="exercise"&&<WorkoutForm day={selected} rows={rows} edit={dialog.edit} busy={busy} save={save} close={close}/>}
 {dialog?.type==="weight"&&<CheckInForm day={selected} rows={rows} busy={busy} save={save} close={close}/>}
 {dialog?.type==="measure"&&<MeasureForm rows={rows} day={selected} busy={busy} save={save} close={close}/>}
 {dialog?.type==="backup"&&Backup&&<Backup close={close} refresh={load}/>}
 {error&&dialog&&<DialogError message={error}/>}
 </div>
}
function DialogError({message}:{message:string}){useEffect(()=>{const d=document.querySelector("dialog");if(!d)return;const e=document.createElement("p");e.className="error";e.setAttribute("role","alert");e.textContent=message;d.appendChild(e);e.scrollIntoView({block:"nearest"});return()=>{e.remove()}},[message]);return null}
