import dishes from "./data/kebabs.json";
import {makePanelFood, type NutritionPanel} from "./nutrition";
import type {LibraryFood} from "./regional";

export const kebabGroup = "Indian kebabs";
const spellingAliases = "kabab kababs kabob kabobs kebabs कबाब";
const existingKebabs = new Set(["Paneer tikka", "Tofu tikka skewers"]);

export function includeExistingKebab(food: LibraryFood): LibraryFood {
  if (!existingKebabs.has(food.name)) return food;
  return {...food, tags: [...(food.tags ?? []), kebabGroup], aliases: [food.aliases, spellingAliases].join(" ")};
}

export const kebabFoods: LibraryFood[] = dishes.map(dish => {
  const panel: NutritionPanel = {
    kind: "Recipe estimate", unit: "g", amount: 100, checked: "2026-11-27",
    source: "https://fdc.nal.usda.gov/download-datasets/", links: dish.links,
    detail: dish.detail, values: dish.values as Record<string, number>
  };
  return {
    ...makePanelFood(dish.name, dish.serving, dish.grams, panel, dish.icon),
    group: kebabGroup, tags: ["Indian snacks"], aliases: dish.aliases + " " + spellingAliases
  };
});
