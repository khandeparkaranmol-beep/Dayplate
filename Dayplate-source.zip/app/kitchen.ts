import type {Entry,Stored,Food,Meal} from "./model";
import {foodSchema} from "./model";
import {makePanelFood,nutrients,scaled,type NutritionPanel} from "./nutrition";
import {references} from "./references";

export type Recipe=Extract<Stored,{kind:"recipe"}>;
export type Plan=Extract<Stored,{kind:"plan"}>;
export type Line=Plan["data"]["lines"][number];
export type LoggedFood=Extract<Stored,{kind:"food"}>;

export const pantry=references.map(ref=>{
  const unit=ref.basisUnit??"g";
  return makePanelFood(ref.name,"100 "+unit,100,{kind:"Food composition reference",unit,amount:100,
    values:ref.values,source:ref.source,links:ref.links,detail:ref.detail},"🥣");
});

export function recipePortion(recipe:Recipe["data"]):Food|null{
  if(!recipe.lines.length||!Number.isFinite(recipe.yieldCount)||recipe.yieldCount<=0)return null;
  const values:Record<string,number>={},bounds:NonNullable<NutritionPanel["bounds"]>={};
  for(const key of Object.keys(nutrients)){
    let total=0,upper=false,lower=false,complete=true;
    for(const {food,quantity} of recipe.lines){
      const n=scaled(food,key,quantity);
      if(!n){complete=false;break}
      total+=n.value;
      upper ||= n.relation==="<"||n.relation==="≤";
      lower ||= n.relation===">"||n.relation==="≥";
    }
    if(!complete||(upper&&lower))continue;
    values[key]=total/recipe.yieldCount;
    if(upper)bounds[key]="≤";
    if(lower)bounds[key]="≥";
  }
  if(values.kcal==null)return null;
  const unit=recipe.unit.trim()||"portion";
  const detail=("From your kitchen. Batch yield: "+recipe.yieldCount+" × "+unit+". Ingredients: "+
    recipe.lines.map(l=>l.food.name+" ("+Number(l.quantity.toFixed(3))+" × "+l.food.serving+")").join(", ")+".").slice(0,3500);
  const food=makePanelFood(recipe.name.trim()||"My recipe","1 "+unit,1,
    {kind:"Recipe estimate",amount:1,unit:"serving",values,bounds,detail},"🍲");
  return foodSchema.safeParse(food).success?food:null;
}

export function plateRows(lines:Line[],day:string,meal:Meal):LoggedFood[]{
  return lines.map(l=>({id:l.id,kind:"food",day,revision:1,data:{meal,quantity:l.quantity,food:l.food}}));
}

export function toFoodEntries(rows:LoggedFood[]):Extract<Entry,{kind:"food"}>[]{
  return rows.map(({revision,...entry})=>entry);
}
