import {validBarcode} from "./nutrition";
const offKeys:Record<string,string>={kcal:"energy-kcal",p:"proteins",c:"carbohydrates",f:"fat",fiber:"fiber",sugar:"sugars",addedSugar:"added-sugars",satFat:"saturated-fat",transFat:"trans-fat",monoFat:"monounsaturated-fat",polyFat:"polyunsaturated-fat",sodium:"sodium",potassium:"potassium",calcium:"calcium",iron:"iron",cholesterol:"cholesterol",magnesium:"magnesium",phosphorus:"phosphorus",zinc:"zinc",b12:"vitamin-b12",vitaminC:"vitamin-c",vitaminD:"vitamin-d",vitaminA:"vitamin-a",salt:"salt"};
type ExternalProduct={code?:string,product_name?:string,brands?:string,nutriments?:Record<string,unknown>,image_nutrition_url?:string,product_quantity_unit?:string,quantity?:string,data_quality_errors_tags?:string[],no_nutriments?:string,no_nutrition_data?:string};
import {nutrients} from "./nutrition";
export function unpackBarcode(code:string,product:ExternalProduct){
 if(product.code&&product.code!==code)throw Error("The provider returned a different barcode.");
 const unit=/^(ml|cl|dl|l)$/i.test(product.product_quantity_unit||"")||/(?:^|[\s\d.,])(?:ml|cl|dl|l|litres?|liters?)\b/i.test(product.quantity||"")?"ml":"g";
 const values:Record<string,string>={},raw=product.nutriments||{};
 if(!product.data_quality_errors_tags?.length&&product.no_nutrition_data!=="on"&&product.no_nutriments!=="on"){
  for(const [key,external] of Object.entries(offKeys)){
   const v=raw[external+"_100g"],mod=raw[external+"_modifier"];
   if((typeof v!=="number"&&typeof v!=="string")||v===""||!Number.isFinite(+v)||+v<0)continue;
   if(mod&&!(["<","≤",">","≥"].includes(String(mod))))continue;
   const mult=nutrients[key][1]==="mg"?1000:nutrients[key][1]==="µg"?1e6:1;
   values[key]=(mod?String(mod):"")+String(Number((+v*mult).toPrecision(7)));
  }
 }
 return {name:[product.brands,product.product_name].filter(Boolean).join(" · ").slice(0,100),code,unit:unit as "ml"|"g",values,
 source:"https://world.openfoodfacts.org/product/"+code,image:product.image_nutrition_url?.startsWith("https://images.openfoodfacts.org/")?product.image_nutrition_url:undefined};
}
export async function lookupBarcode(code:string){
 if(!validBarcode(code))throw Error("Check the barcode digits and check digit.");
 const fields="code,product_name,brands,nutriments,product_quantity_unit,quantity,image_nutrition_url,data_quality_errors_tags,no_nutrition_data,no_nutriments";
 const res=await fetch("https://world.openfoodfacts.org/api/v2/product/"+code+".json?fields="+fields,{signal:AbortSignal.timeout(10000),credentials:"omit"});
 if(res.status===429)throw Error("The barcode service is busy. Enter the panel below or retry later.");
 if(res.status===404)return null;if(!res.ok)throw Error("Lookup unavailable. You can enter the package panel below.");
 const data=await res.json() as {status:number,product?:ExternalProduct};
 return data.status===1&&data.product?unpackBarcode(code,data.product):null;
}
