import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Dayplate – Personal Health Tracker",
  description: "Your private daily food diary, calorie budget, and weight trends.",
  icons: { icon: "/favicon.svg" },
  appleWebApp: { capable: true, title: "Dayplate" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#f7f8fa" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
