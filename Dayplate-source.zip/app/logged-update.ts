import type {SnapshotGroup} from "./day-snapshot";
import {meals, type Meal, type Stored} from "./model";

export type LogPick = {kind:"day"; day:string} | {kind:"meal"; day:string; meal:Meal} | {kind:"food"|"exercise"|"steps"; day:string; id:string};
export type LoggedUpdate = {
  kind:LogPick["kind"]; day:string; title:string;
  items:{name:string; portion:string}[];
  stats:{label:string; value:string}[]; groups?:SnapshotGroup[];
};
export type UpdatePreview = {snapshot:LoggedUpdate; fingerprint:string};
export const loggedDayLabel=(day:string)=>new Date(day+"T12:00:00").toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});

export function shareableRecord(row:Stored){
  return row.kind==="food" || row.kind==="exercise" || (row.kind==="activity" && (row.data.steps!=null||row.data.active!=null));
}

export function loggedChoices(rows:Stored[],day:string){
  const options:{label:string;pick:LogPick}[]=[];
  const daily=rows.filter(r=>r.day===day);
  if(daily.some(shareableRecord))options.push({label:"Whole day so far",pick:{kind:"day",day}});
  for(const meal of meals){
    const foods=daily.filter(r=>r.kind==="food").filter(r=>r.data.meal===meal);
    if(!foods.length)continue;
    options.push({label:meal+" · "+(foods.length===1?foods[0].data.food.name:foods.length+" foods"),pick:{kind:"meal",day,meal}});
    if(foods.length>1)for(const r of foods)options.push({label:meal+" · "+r.data.food.name+" ("+r.data.quantity+" × "+r.data.food.serving+")",pick:{kind:"food",day,id:r.id}});
  }
  for(const r of daily){
    if(r.kind==="exercise")options.push({label:r.data.name+" · "+r.data.minutes+" min",pick:{kind:"exercise",day,id:r.id}});
    if(r.kind==="activity" && r.data.steps!=null)options.push({label:r.data.steps.toLocaleString()+" steps",pick:{kind:"steps",day,id:r.id}});
  }
  return options;
}
