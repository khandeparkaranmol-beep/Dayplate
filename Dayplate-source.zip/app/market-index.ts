import { validBarcode } from "./nutrition";
export const indexRelease={
 date:"2026-11-03",
 url:"https://huggingface.co/datasets/PackSense/packsense-india/resolve/78b27c016af681e589795988da447ca37ac5ea75/india_products.csv",
 source:"https://huggingface.co/datasets/PackSense/packsense-india",
 digest:"9007b7a48fe9bc129e6a90a6fc7dfb4dfdcb6a72f53b3a3aabc74eda0d5d1951"
};
export type IndexItem={code:string,name:string,brand:string};
let loaded:IndexItem[]|undefined;
const validFoodGroups=new Set(["beverages","milk and dairy products","sugary snacks","salty snacks","cereals and potatoes","composite foods","fruits and vegetables","fish meat eggs","fat and sauces","fats and sauces"]);
export function csvRows(text:string):string[][] {
 const out:string[][]=[],row:string[]=[];let field="",quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++}else quoted=!quoted}
 else if(c===","&&!quoted){row.push(field);field=""}
 else if(c==="\n"&&!quoted){row.push(field.replace(/\r$/,""));out.push(row.splice(0));field=""}
 else field+=c}
 if(quoted)throw Error("The CSV has an incomplete quoted field.");
 if(field||row.length){row.push(field.replace(/\r$/,""));out.push(row)}return out;
}
export function parseDirectory(csv:string){
 const [header,...rows]=csvRows(csv.replace(/^\uFEFF/,""));
 const at=(k:string)=>{const pos=header.indexOf(k);if(pos<0)throw Error("Unexpected CSV column layout.");return pos};
 const c=at("code"),n=at("product_name"),b=at("brands"),e=at("open_error_flags"),s=at("existence_status"),g=at("pnns_groups_1"),t=at("categories_tags");
 const result=new Map<string,IndexItem>();
 for(const row of rows){
  const code=row[c]?.trim(),name=row[n]?.trim(),brand=row[b]?.trim()||"",tags=(row[t]||"").toLowerCase();
  if(!name||!validBarcode(code)||!["present_in_snapshot","confirmed_exists"].includes(row[s])||Number(row[e])>0)continue;
  if(/pet-food|dog-food|cat-food|cosmetic|shampoo|body-wash|toothpaste|infant-formula/.test(tags))continue;
  if(!validFoodGroups.has((row[g]||"").toLowerCase())&&!/en:(snacks|beverages|biscuits|chocolates|milks|cheeses|breakfast-cereals|legumes|breads|sauces|spices|yogurts|fruit-juices|noodles|cooking-oils|rice)(?:\||$)/.test(tags))continue;
  result.set(code,{code,name,brand});
 }
 if(!result.size)throw Error("No identifiable food products in the file.");
 return [...result.values()];
}
async function cache(){return new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open("dayplate-market-index",1);r.onupgradeneeded=()=>r.result.createObjectStore("data");r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
export async function cachedDirectory(){
 if(loaded)return loaded;
 try{const db=await cache();const data=await new Promise<IndexItem[]|undefined>((ok,no)=>{const r=db.transaction("data").objectStore("data").get(indexRelease.digest);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});db.close();if(data?.length)loaded=data}catch{/* A fresh search can still use this session. */}
 return loaded||[];
}
export async function installDirectory(file?:File){
 let buffer:ArrayBuffer;
 if(file){if(file.size>12000000)throw Error("Choose the India products CSV from the linked snapshot.");buffer=await file.arrayBuffer()}
 else{const res=await fetch(indexRelease.url,{signal:AbortSignal.timeout(25000),credentials:"omit"});if(!res.ok)throw Error("The product directory is unavailable.");buffer=await res.arrayBuffer()}
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",buffer))).map(n=>n.toString(16).padStart(2,"0")).join("");
 if(hash!==indexRelease.digest)throw Error("This file does not match the published India snapshot. Use the linked CSV.");
 const entries=parseDirectory(new TextDecoder().decode(buffer));
 let cached=false;
 try{const db=await cache();await new Promise<void>((ok,no)=>{const tx=db.transaction("data","readwrite");tx.objectStore("data").put(entries,indexRelease.digest);tx.oncomplete=()=>ok();tx.onerror=tx.onabort=()=>no(tx.error)});db.close();cached=true}catch{/* Search remains usable until this window closes. */}
 loaded=entries;return {entries,cached};
}
export function marketMatches(entries:IndexItem[],query:string){
 const words=query.trim().toLowerCase().split(/\s+/);
 if(!query.trim())return [];
 return entries.filter(row=>words.every(w=>(row.code+" "+row.brand+" "+row.name).toLowerCase().includes(w))).slice(0,40);
}

const searchCache=new Map<string,IndexItem[]>();
let lastSearch=0;
export async function searchIndiaMarket(term:string):Promise<IndexItem[]>{
 const query=term.trim().toLowerCase();
 if(query.length<3)throw Error("Enter at least three letters of a brand or product.");
 const cached=searchCache.get(query);if(cached)return cached;
 if(Date.now()-lastSearch<6000)throw Error("Give the product directory a few seconds before searching again.");
 lastSearch=Date.now();
 const url=new URL("https://world.openfoodfacts.org/cgi/search.pl");
 url.search=new URLSearchParams({action:"process",search_terms:query,tagtype_0:"countries",tag_contains_0:"contains",tag_0:"india",json:"1",page_size:"25",fields:"code,product_name,brands,countries_tags,data_quality_errors_tags"}).toString();
 const res=await fetch(url,{credentials:"omit",signal:AbortSignal.timeout(12000)});
 if(!res.ok)throw Error("Online search is unavailable. Try an exact barcode or enter the packet label.");
 const data=await res.json() as {products?:{code?:string,product_name?:string,brands?:string,countries_tags?:string[],data_quality_errors_tags?:string[]}[]};
 if(!Array.isArray(data.products))throw Error("The directory returned no readable results.");
 const matches:IndexItem[]=[];
 for(const p of data.products){
  if(!p.code||!validBarcode(p.code)||!p.product_name||!p.countries_tags?.includes("en:india")||p.data_quality_errors_tags?.length)continue;
  matches.push({code:p.code,name:p.product_name,brand:p.brands||""});
 }
 searchCache.set(query,matches);return matches;
}
