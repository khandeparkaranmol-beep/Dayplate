import { z } from "zod";
import { nutrients,panelSchema } from "./nutrition";
export const meals = ["Breakfast", "Lunch", "Dinner", "Snacks"] as const;
export type Meal = (typeof meals)[number];
export const validDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{
  const d=new Date(s+"T12:00:00Z");
  return Number.isFinite(d.getTime()) && d.toISOString().slice(0,10)===s;
});
const num = (max:number) => z.number().finite().min(0).max(max);
const label = z.string().trim().min(1).max(100);
export const foodSchema = z.object({
  name:z.string().trim().min(1).max(250), serving:z.string().trim().min(1).max(220), grams:z.number().positive().max(10000).nullable(),
  kcal:num(10000), p:num(2000).nullable(), c:num(2000).nullable(), f:num(2000).nullable(),
  sugar:num(2000).nullable().optional(), ml:z.number().positive().max(10000).optional(), panel:panelSchema.optional(),
  icon:z.string().min(1).max(12)
});
export type Food = z.infer<typeof foodSchema>;
export const profileSchema=z.object({
  mode:z.enum(["estimate","manual"]), age:z.number().int().min(18).max(100), height:z.number().min(100).max(250), weight:z.number().min(30).max(400),
  sex:z.enum(["female","male"]), factor:z.union([z.literal(1.2),z.literal(1.375),z.literal(1.55),z.literal(1.725)]), deficit:z.union([z.literal(0),z.literal(250),z.literal(500)])
});
export type Profile=z.infer<typeof profileSchema>;
export function estimate(p:Profile) {
  const resting=10*p.weight+6.25*p.height-5*p.age+(p.sex==="male"?5:-161);
  const maintenance=Math.round(resting*p.factor);
  const minimum=p.sex==="male"?1500:1200;
  const target=Math.round((maintenance-p.deficit)/10)*10;
  const safe=target>=minimum && !(p.deficit>0 && p.weight/(p.height/100)**2<18.5);
  return {resting:Math.round(resting),maintenance,target,safe};
}
export const measureSchema=z.object({height:z.number().min(100).max(250).optional(),waist:z.number().min(35).max(300).optional()}).refine(d=>d.height!=null||d.waist!=null);
const common={id:z.string().min(1).max(80),day:validDate};
const quantity=z.number().finite().min(.001).max(1000);
export const kitchenLine=z.object({id:z.string().uuid(),food:foodSchema,quantity});
const kitchenLines=z.array(kitchenLine).min(1).max(40).refine(items=>new Set(items.map(i=>i.id)).size===items.length);
export const householdRecipe=z.object({name:label,unit:label,yieldCount:quantity,lines:kitchenLines});
const boxingSchema=z.object({rounds:z.number().int().min(1).max(200),roundMinutes:z.number().positive().max(60),restSeconds:z.number().min(0).max(3600),effort:z.number().int().min(1).max(10)});
export const foodGroups=["Vegetables","Fruit","Pulses & beans","Grains & millets","Dairy","Nuts & seeds","Eggs, fish & meat"] as const;
export const recordSchema=z.discriminatedUnion("kind",[
  z.object({...common,kind:z.literal("food"),data:z.object({food:foodSchema,quantity:z.number().min(.001).max(1000),meal:z.enum(meals), custom:z.boolean().optional()})}),
  z.object({...common,kind:z.literal("activity"),data:z.object({steps:num(500000).optional(),active:num(50000).optional(),resting:num(50000).optional(),sources:z.object({steps:label.optional(),active:label.optional(),resting:label.optional()})}).refine(v=>v.steps!=null||v.active!=null||v.resting!=null)}),
  z.object({...common,kind:z.literal("review"),data:z.object({signature:z.string().min(1).max(12000)})}),
  z.object({...common,kind:z.literal("measure"),data:measureSchema}),
  z.object({...common,kind:z.literal("weight"),data:z.object({kg:z.number().min(20).max(500)})}),
  z.object({...common,kind:z.literal("exercise"),data:z.object({name:label,minutes:z.number().finite().positive(),boxing:boxingSchema.optional(),basis:z.object({activity:label,kg:z.number().min(20).max(500).optional()}).optional(),health:z.object({activeKcal:z.number().finite().nonnegative().optional(),uuid:z.string().uuid(),start:z.string().datetime(),end:z.string().datetime()}).optional()})}),
  z.object({...common,kind:z.literal("target"),data:z.object({calories:z.number().int().min(1200).max(6500),proteinGoal:z.number().positive().max(400).optional(),profile:profileSchema.nullable()})}),
  z.object({...common,kind:z.literal("routine"),data:z.object({cue:z.string().trim().min(1).max(80),days:z.array(z.number().int().min(0).max(6)).min(1).max(7).refine(days=>new Set(days).size===days.length),usualDay:validDate.nullable(),paused:z.boolean()})}),
  z.object({...common,id:z.literal("meal-nutrients"),kind:z.literal("mealNutrients"),data:z.object({
    columns:z.number().int().positive().max(Object.keys(nutrients).length).optional(),
    keys:z.array(z.string().refine(k=>k!=="kcal"&&Object.hasOwn(nutrients,k))).max(Object.keys(nutrients).length).refine(keys=>new Set(keys).size===keys.length)
  }).refine(v=>!v.columns||v.columns<=v.keys.length)}),
  z.object({...common,kind:z.literal("crewDay"),data:z.object({routine:z.enum(["missed","back"])})}),
  z.object({...common,kind:z.literal("variety"),data:z.object({groups:z.array(z.enum(foodGroups)).max(foodGroups.length).refine(v=>new Set(v).size===v.length)})}),
  z.object({...common,kind:z.literal("recipe"),data:householdRecipe}),
  z.object({...common,kind:z.literal("plan"),data:z.object({meal:z.enum(meals),lines:kitchenLines})}),
  z.object({...common,kind:z.literal("experiment"),data:z.object({first:label,second:label,end:validDate.optional()}).refine(v=>v.first.toLowerCase()!==v.second.toLowerCase())}),
  z.object({...common,kind:z.literal("hunger"),data:z.object({experiment:z.string().uuid(),choice:z.enum(["first","second"]),rating:z.number().int().min(1).max(5)})}),
  z.object({...common,kind:z.literal("saved"),data:foodSchema}),
]);
export type Entry=z.infer<typeof recordSchema>;
export type Stored=Entry & {revision:number};
export const foodEntries=(rows:Stored[])=>rows.filter(r=>r.kind==="food");
export const targetAt=(rows:Stored[],day:string)=>rows.filter((r):r is Extract<Stored,{kind:"target"}>=>r.kind==="target"&&r.day<=day).sort((a,b)=>b.day.localeCompare(a.day))[0];
export function dateKey(d=new Date()) {return [d.getFullYear(),String(d.getMonth()+1).padStart(2,"0"),String(d.getDate()).padStart(2,"0")].join("-");}
export function shift(day:string,delta:number) {const d=new Date(day+"T12:00:00");d.setDate(d.getDate()+delta);return dateKey(d);}
export const format=(n:number)=>Math.round(n).toLocaleString("en-US");
export const totals=(rows:Stored[])=>foodEntries(rows).reduce((a,r)=>{
  const {quantity:q,food}=r.data;
  a.kcal+=food.kcal*q;
  for(const key of ["p","c","f"] as const) {
    if(food[key]===null) a.partial=true; else a[key]+=food[key]*q;
  }
  return a;
},{kcal:0,p:0,c:0,f:0,partial:false});

export function diarySignature(rows:Stored[],day:string){
 const entries=foodEntries(rows).filter(r=>r.day===day);
 return entries.length?JSON.stringify(entries.map(e=>[e.id,e.revision]).sort((a,b)=>String(a[0]).localeCompare(String(b[0])))):"";
}
export function completeDay(rows:Stored[],day:string){
 const review=rows.find(r=>r.kind==="review"&&r.day===day);
 return review?.kind==="review"&&review.data.signature===diarySignature(rows,day);
}
