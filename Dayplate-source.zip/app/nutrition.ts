import { z } from "zod";
import type { Food, Stored } from "./model";

export const nutrients: Record<string, [string, string]> = {
  kcal:["Energy","kcal"], p:["Protein","g"], c:["Carbohydrate","g"], f:["Total fat","g"],
  fiber:["Dietary fibre","g"], sugar:["Total sugars","g"], addedSugar:["Added sugars","g"],
  satFat:["Saturated fat","g"], transFat:["Trans fat","g"], monoFat:["Monounsaturated fat","g"],
  polyFat:["Polyunsaturated fat","g"], omega3:["Omega-3","g"], omega6:["Omega-6","g"],
  cholesterol:["Cholesterol","mg"], sodium:["Sodium","mg"], potassium:["Potassium","mg"],
  calcium:["Calcium","mg"], iron:["Iron","mg"], magnesium:["Magnesium","mg"], phosphorus:["Phosphorus","mg"],
  zinc:["Zinc","mg"], copper:["Copper","mg"], manganese:["Manganese","mg"], selenium:["Selenium","µg"],
  iodine:["Iodine","µg"], chromium:["Chromium","µg"], molybdenum:["Molybdenum","µg"], chloride:["Chloride","mg"],
  vitaminA:["Vitamin A","µg"], vitaminD:["Vitamin D","µg"], vitaminE:["Vitamin E","mg"], vitaminK:["Vitamin K","µg"],
  vitaminC:["Vitamin C","mg"], b1:["Thiamin (B1)","mg"], b2:["Riboflavin (B2)","mg"], b3:["Niacin (B3)","mg"],
  b5:["Pantothenic acid (B5)","mg"], b6:["Vitamin B6","mg"], b7:["Biotin (B7)","µg"], b9:["Folate (B9)","µg"],
  b12:["Vitamin B12","µg"], choline:["Choline","mg"], caffeine:["Caffeine","mg"], salt:["Salt","g"],
  sugarAlcohol:["Sugar alcohols","g"], lactose:["Lactose","g"], solubleFiber:["Soluble fibre","g"], insolubleFiber:["Insoluble fibre","g"],
};
Object.assign(nutrients,{
 energyFromFat:["Energy from fat","kcal"],nonNaturalTransFat:["Non-naturally occurring trans fat","g"],
 naturalSugar:["Naturally occurring sugars","g"],bcaa:["Branched-chain amino acids","g"],essentialAminoAcids:["Essential amino acids","g"],conditionallyEssentialAminoAcids:["Conditionally essential amino acids","g"],nonessentialAminoAcids:["Nonessential amino acids","g"],
 ...Object.fromEntries(["histidine","isoleucine","leucine","lysine","methionine","phenylalanine","threonine","tryptophan","valine","asparticAcid","serine","glutamicAcid","proline","glycine","alanine","cystine","tyrosine","arginine"].map(k=>[k,[k[0].toUpperCase()+k.slice(1).replace(/Acid/," acid"),"g"]]))
});
const nonnegative=z.number().finite().nonnegative().max(10000000);
export const panelSchema=z.object({
  amount:z.number().positive().max(10000), unit:z.enum(["g","ml"]),
  values:z.record(z.string().max(48),nonnegative),
  bounds:z.record(z.string().max(48),z.enum(["<","≤",">","≥"])).optional(),
  kind:z.enum(["Café menu","Manufacturer label","Manufacturer listing","Published pack image","Product listing","Food composition reference","Recipe estimate","Your package","Community barcode"]),
  links:z.array(z.string().url().regex(/^https?:\/\//i).max(2500)).max(15).optional(),
  source:z.string().url().regex(/^https?:\/\//i).max(2500).optional(),
  detail:z.string().max(3500).optional(), checked:z.string().max(20).optional(),
  brand:z.string().max(120).optional(), variant:z.string().max(170).optional(),
  barcode:z.string().regex(/^\d{8,14}$/).optional(), pack:z.number().positive().max(100000).optional(),
});
export type NutritionPanel=z.infer<typeof panelSchema>;
export const compactNumber=(n:number)=>Number(n.toPrecision(5)).toLocaleString("en-IN",{maximumFractionDigits:6});
export const amountOf=(f:Food)=>f.ml??f.grams;
export const unitOf=(f:Food)=>f.ml!=null?"ml":"g";
export function scaled(food:Food,key:string,servings=1):{value:number,relation?:string}|null {
  const panel=food.panel;
  if(panel){
    const base=panel.values[key],size=amountOf(food);
    if(base===undefined||size==null||panel.unit!==unitOf(food))return null;
    return {value:base*size/panel.amount*servings,relation:panel.bounds?.[key]};
  }
  if(key==="kcal"||key==="p"||key==="f"||key==="c"){
    const n=food[key];if(n!==null)return {value:n*servings};
  }
  return null;
}
export function dayNutrient(rows:Stored[],key:string){
  const foods=rows.filter(r=>r.kind==="food");
  let sum=0, known=0, bounded=0, upper=0, lower=0, hasUpper=false,hasLower=false;
  for(const r of foods){
    const n=scaled(r.data.food,key,r.data.quantity);
    if(!n)continue;
    if(n.relation==="<"||n.relation==="≤"){upper+=n.value;hasUpper=true;bounded++;continue}
    if(n.relation===">"||n.relation==="≥"){lower+=n.value;hasLower=true;bounded++;continue}
    known++;sum+=n.value;
  }
  return {sum,known,bounded,total:foods.length,missing:foods.length-known-bounded,upper,lower,hasUpper,hasLower};
}
export function formatDaily(d:ReturnType<typeof dayNutrient>){
  if(!d.known&&!d.bounded)return "—";
  if(d.hasLower)return "≥ "+compactNumber(d.sum+d.lower);
  if(d.hasUpper)return compactNumber(d.sum)+"–"+compactNumber(d.sum+d.upper);
  return compactNumber(d.sum);
}
export function validBarcode(code:string){
  if(!/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/.test(code))return false;
  const digits=code.slice(0,-1).split("").reverse();
  const sum=digits.reduce((s,c,i)=>s+Number(c)*(i%2===0?3:1),0);
  return (10-sum%10)%10===Number(code.at(-1));
}
export function makePanelFood(name:string,serving:string,size:number,panel:NutritionPanel,icon:string):Food{
  if(panel.values.kcal===undefined||panel.bounds?.kcal)throw Error("A readable energy value is required.");
  const factor=size/panel.amount;
  const macro=(k:string)=>panel.values[k]===undefined||panel.bounds?.[k]?null:panel.values[k]*factor;
  return {name,serving,grams:panel.unit==="g"?size:null,ml:panel.unit==="ml"?size:undefined,
    kcal:panel.values.kcal*factor,p:macro("p"),c:macro("c"),f:macro("f"),icon,panel};
}

export function foodKey(food:Food){
 const panel=food.panel;
 return JSON.stringify([food.name,food.serving,food.grams,food.ml,food.kcal,food.p,food.c,food.f,
   panel?.kind,panel?.barcode,panel?.amount,panel?.variant,Object.entries(panel?.values||{}).sort(),Object.entries(panel?.bounds||{}).sort()]);
}
