import GoogleSignIn from "./GoogleSignIn";
import {getDiaryUser,googleClient} from "./account";
import {chatGPTSignInPath} from "./chatgpt-auth";
import OnlineJournal from "./OnlineJournal";
export const dynamic="force-dynamic";
export default async function Home(){
 if(await getDiaryUser())return <OnlineJournal/>;
 return <main className="login-page"><div className="login-brand"><img src="/favicon.svg" alt=""/>Dayplate</div><div className="login-layout"><section><h1>Your personal<br/>health journal.</h1><p>Log the food you actually eat. Bring in your steps and workouts. Challenge a friend when you want company.</p>{googleClient()?<GoogleSignIn/>:<a className="primary login-cta" href={chatGPTSignInPath("/")} target="_top">Sign in with ChatGPT</a>}<small>Your diary is private. You choose what friends see.</small></section><div className="login-photo art-pohe" role="img" aria-label="Fresh Maharashtrian kanda pohe"/></div></main>;
}
