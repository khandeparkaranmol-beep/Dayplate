import {redirect} from "next/navigation";
import {journalURL} from "../lib/pages-origin";
export default function Home(){redirect(journalURL)}
