import {apiOrigin} from "../lib/pages-origin";

const sessionKey = "dayplate.pages.session";
export const currentSession = () => sessionStorage.getItem(sessionKey);
export const startSession = (token: string) => sessionStorage.setItem(sessionKey,token);
export function endSession() {
  sessionStorage.removeItem(sessionKey);
  window.dispatchEvent(new Event("dayplate-signout"));
}
export async function pagesRequest(path: string, init: RequestInit = {}) {
  if (!path.startsWith("/api/") || path.includes("..")) throw Error("Unknown Dayplate request.");
  const headers = new Headers(init.headers);
  const token = currentSession();
  if (token) headers.set("Authorization", "Bearer " + token);
  const res = await fetch(apiOrigin + path, {...init, headers, credentials:"omit", cache:"no-store", redirect:"error"});
  if (token && res.status === 401 && token === currentSession()) endSession();
  return res;
}
