import {apiOrigin} from "../lib/pages-origin";
import {forgetBrowserKey,readBrowserKey,rememberBrowser,resumeBrowser} from "./remembered-browser";

const sessionKey="dayplate.pages.session";
const changeKey="dayplate.account.change";
let memoryToken:string|null=null;
const epochKey="dayplate.pages.account-change";
function sharedEpoch(){try{return localStorage.getItem(changeKey)}catch{return null}}
function accountChanged(){
  try{return !!currentSession()&&sessionStorage.getItem(epochKey)!==sharedEpoch()}catch{return false}
}
let generation=0;
let pending:Promise<string|null>|undefined;
export function currentSession(){
  try{return sessionStorage.getItem(sessionKey)??memoryToken}catch{return memoryToken}
}
function setAccess(token:string|null){
  memoryToken=token;
  try{
    if(token)sessionStorage.setItem(sessionKey,token);else sessionStorage.removeItem(sessionKey);
    const epoch=sharedEpoch();
    if(token&&epoch)sessionStorage.setItem(epochKey,epoch);else sessionStorage.removeItem(epochKey);
  }catch{/* Tab memory is sufficient. */}
}
function announceChange(){
  try{localStorage.setItem(changeKey,crypto.randomUUID())}catch{/* Storage may be restricted. */}
}
export function observeAccount(change:()=>void){
  const otherTab=(event:StorageEvent)=>{
    if(event.key!==changeKey&&event.key!==null)return;
    generation++;pending=undefined;setAccess(null);change();
  };
  window.addEventListener("storage",otherTab);
  window.addEventListener("dayplate-account-changed",change);
  return ()=>{window.removeEventListener("storage",otherTab);window.removeEventListener("dayplate-account-changed",change)};
}
export async function startSession(token:string){
  generation++;pending=undefined;setAccess(token);
  // Explicit Google sign-in replaces the previously remembered account on this browser.
  await forgetBrowserKey().catch(()=>{});
  await rememberBrowser(token).catch(()=>false);
  announceChange();setAccess(token);
}
export async function signOutBrowser(){
  const began=generation;
  const res=await pagesRequest("/api/google/signout",{method:"POST"});
  if(!res.ok&&res.status!==401)throw Error("Could not sign out. Try again.");
  if(began!==generation||accountChanged())return;
  generation++;pending=undefined;setAccess(null);
  await forgetBrowserKey().catch(()=>{});
  announceChange();
  window.dispatchEvent(new Event("dayplate-signout"));
}
function restoreAccess(){
  if(pending)return pending;
  const started=generation;
  const job=(async()=>{
    const key=await readBrowserKey().catch(()=>undefined);
    if(!key||started!==generation)return null;
    const token=await resumeBrowser(key);
    if(started!==generation)return null;
    setAccess(token);
    return token;
  })();
  pending=job;
  const settled=()=>{if(pending===job)pending=undefined};
  job.then(settled,settled);
  return job;
}
export async function openSession(){
  if(accountChanged())setAccess(null);
  const token=currentSession();
  if(!token)return Boolean(await restoreAccess());
  // Upgrade a still-valid session from an older release without asking for Google again.
  if(!await readBrowserKey().catch(()=>undefined))await rememberBrowser(token).catch(()=>false);
  return token===currentSession();
}
export async function pagesRequest(path:string,init:RequestInit={}){
  if(!path.startsWith("/api/")||path.includes(".."))throw Error("Unknown Dayplate request.");
  const send=(token:string|null)=>{
    const headers=new Headers(init.headers);
    if(token)headers.set("Authorization","Bearer "+token);
    return fetch(apiOrigin+path,{...init,headers,credentials:"omit",cache:"no-store",redirect:"error"});
  };
  if(accountChanged()){
    generation++;pending=undefined;setAccess(null);
    window.dispatchEvent(new Event("dayplate-account-changed"));
    return new Response(null,{status:409});
  }
  const token=currentSession(),started=generation,epoch=sharedEpoch();
  const res=await send(token);
  if(res.status!==401||!token||path==="/api/google/session"||started!==generation)return res;
  const renewed=token!==currentSession()?currentSession():await restoreAccess();
  if(started!==generation||sharedEpoch()!==epoch)return res;
  if(renewed)return send(renewed);
  setAccess(null);
  window.dispatchEvent(new Event("dayplate-signout"));
  return res;
}
