import type {Food,Stored} from "./model";

// Positive list for the owner's sharing preference. A new menu item, custom recipe
// or unfamiliar label stays private until its catalog entry has been reviewed.
const shareableDishes=new Set([
  "Banana","Apple","Orange","Mango","Grapes","Papaya","Watermelon","Avocado",
  "Guava (white flesh)","Guava (pink flesh)","Kiwi (green)","Muskmelon (orange flesh)",
  "Muskmelon (yellow flesh)","Chikoo (sapota)","Sitaphal (custard apple)","Amla (Indian gooseberry)",
  "Mosambi (sweet lime)","Pomegranate","Lychee","Jackfruit (ripe)","Jamun (Indian black plum)",
  "Fig (fresh)","Pear","Pineapple","Plum","Strawberry","Star fruit","Mango (Banganapalli)",
  "Mango (Kesar)","Mango (Payri)","Banana (red)","Banana (Robusta)","Persimmon (Japanese, raw)",
  "Cucumber","Carrot","Tomato","Spinach, cooked","Potato, boiled","Pumpkin, raw","Onion, raw",
  "Mushrooms, white, raw","Almonds","Cashews, raw","Peanuts, roasted","Peanuts, raw",
  "Boiled egg","Egg white","Chicken breast, cooked","Grilled chicken breast","Tofu, firm",
  "Salmon, cooked","Shrimp, cooked","Lentils, plain","Chickpeas, cooked","Black-eyed peas, boiled",
  "Brown rice","Steamed basmati rice","Quinoa","Rolled oats, dry","Whole wheat bread","Pasta, plain",
  "Milk, whole","Greek yogurt, plain","Curd / dahi","Paneer","Black coffee","Buttermilk / chaas",
  "Roti / chapati","Kanda pohe","Vegetable upma","Plain dosa","Idli","Sambar","Idli sambar",
  "Tomato omelette (besan, eggless)","Moong dal chilla","Dal tadka","Rajma masala","Chana masala",
  "Paneer bhurji","Bhindi sabzi","Mixed vegetable sabzi","Vegetable khichdi","Chicken curry",
  "Goan fish curry rice","Tandoori chicken","Chana ros","Puttu with kadala curry"
]);
export function ownerOnlyFood(food:Food,custom=false){
  const panel=food.panel;
  return custom||!shareableDishes.has(food.name)||!panel?.source||
    (panel.kind!=="Food composition reference"&&panel.kind!=="Recipe estimate");
}
export function eligibleDiaryRow(row:Stored){
  return row.kind!=="food"||!ownerOnlyFood(row.data.food,row.data.custom);
}
