// Supplementary sugar estimates per 100 g of recipe ingredient.
const sugarProxies:Record<string,{values:Record<string,number>,source:string,note:string,bounds?:Record<string,"<">}>={
  "nutella india":{values:{addedSugar:56.3*19/21},source:"https://www.ferrerofoodservice.com/us/en/brands/nutella/nutella-jar-26oz",note:"Total sugar uses Ferrero India’s 56.3 g per 100 g. Added sugar uses the US label’s ratio of 19 g added to 21 g total sugar."},
  jaggery:{values:{fiber:1},bounds:{fiber:"<"},source:"https://agriexchange.apeda.gov.in/images/CropImages/JAGGERY%20POWDER%20PRODUCT%20DETAILS%20EXPORT255004952.pdf",note:"A cane jaggery laboratory specification reports fibre below 1 g per 100 g. The portion’s fibre is therefore an upper limit."},
  pav:{values:{potassium:152},source:"https://www.ars.usda.gov/ARSUserFiles/80400525/Data/SR/SR28/dnload/sr28abbr.zip",note:"Potassium in pav uses a plain dinner roll with milk as a proxy (USDA NDB 18396)."},
  sev:{values:{fiber:.75*10.8,potassium:.75*846},source:"https://fdc.nal.usda.gov/food-details/174288/nutrients",note:"Fibre and potassium in sev are estimated from a recipe containing 75% besan by finished weight. Oil and water make up the remaining weight."},
  paneer:{values:{},source:"https://www.unboxhealth.in/explore/product/mother-dairy-fresh-paneer/f4520d66-7f09-43b5-80de-802e51a4e146",note:"Plain paneer sugar is estimated from its available carbohydrate. The Mother Dairy label attributes all 2.5 g of carbohydrate per 100 g to sugar."},
  bread:{values:{addedSugar:3.2},source:"https://goodbite.ai/product/english-oven-sandwich-bread",note:"Added sugar in bread is estimated using the English Oven sandwich bread label."},
  "coconut milk":{values:{sugar:1.4,fiber:.5},bounds:{fiber:"<"},source:"https://www.marksandspencer.com/food/COCONUT%20MILK./p/fdp20059273",note:"Coconut milk sugar and the upper limit for fibre are from the M&S canned coconut milk label."},
  semolina:{values:{sugar:0.1},source:"https://www.culpepers.com.au/uploaded/files/product_documents/semolina_euro_-_fine.pdf",note:"Semolina sugar uses the Culpepers fine semolina specification."},
  prawns:{values:{sugar:0.1,fiber:0.5},source:"https://www.tesco.com/shop/en-GB/products/297648931",note:"Prawn sugar and fibre use Tesco’s cooked, peeled king prawn label."},
};
const unsweetenedIngredients=new Set(["oil","white flour","wheat flour","rice flour","semolina","raw egg","egg yolk","boiled egg","chicken (cooked)","beef (cooked)","prawns","vegetables","mushrooms","onion","milk","butter","cheese","tomato","cucumber","coriander","potato","dried red chilli","garlic","vinegar","coconut","coconut milk","cream","dates","almonds","cocoa","mascarpone","coffee",
 "pumpkin","gram flour","jowar flour","rice flakes (dry)","tapioca (dry)","puffed rice","yogurt","peanuts","cashews","banana","ghee","paneer","spinach","eggplant","cooked rice","chickpeas","cooked lentils","cooked chana dal","cooked mung beans","fish (cooked)","sweetcorn","carrot",
 "dry rice","dry mung","urad dal","toor dal","yellow moong dal","chana dal dry","whole urad (cooked)","green peas","kidney beans","cauliflower","cabbage","beet","green beans","capsicum","tamarind","sesame","lemon juice","ginger","radish","bulgur","wheat vermicelli","white peas (cooked)","cumin","mustard","boiled peanuts","fenugreek leaves","mint","taro leaves","bottle gourd"]);
export function recipeIngredient(key:string,base:Record<string,number>){
  const proxy=sugarProxies[key];
  const values={...base,...proxy?.values};
  if(key==="paneer"){values.sugar=base.c;values.fiber=0}
  if(key==="oil"&&values.c===0)values.sugar=0;
  if(key==="sugar"||key==="jaggery")values.addedSugar=values.sugar;
  else if(unsweetenedIngredients.has(key))values.addedSugar=0;
  return {values,source:proxy?.source,note:proxy?.note,bounds:proxy?.bounds};
}
