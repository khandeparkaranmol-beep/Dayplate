import raw from "./data/reference.json";
import {makePanelFood} from "./nutrition";
import type {Food} from "./model";
export type RefFood={name:string,basisUnit?:"g"|"ml",keys:string[],values:Record<string,number>,source:string,links:string[],detail:string};
export const references:RefFood[]=raw as unknown as RefFood[];
export const ingredientRefs=new Map(references.flatMap(r=>r.keys.map(k=>[k,r] as const)));
export function applyReference(name:string,serving:string,grams:number,icon:string):Food{
 const ref=references.find(r=>r.name===name);
 if(!ref)throw Error("Missing composition reference for "+name);
 return makePanelFood(name,serving,grams,{kind:"Food composition reference",unit:"g",amount:100,values:ref.values,source:ref.source,links:ref.links,detail:ref.detail,checked:"2026-11-24"},icon);
}
