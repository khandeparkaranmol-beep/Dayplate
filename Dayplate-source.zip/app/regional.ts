import {mumbaiCafe,goanCafe,panajiMenu,type Recipe} from "./cafe-menu";
import packagedData from "./data/packaged.json";
import {ingredientRefs} from "./references";
import {makePanelFood,panelSchema,type NutritionPanel} from "./nutrition";
import type {Food} from "./model";
export type LibraryFood=Food & {group:string,aliases?:string,note?:string,source?:string,portionKind?:string};
export const primaryGroups=["Maharashtrian","Goan","Continental","Indian market snacks"];
const m:Recipe[]=[
["Kanda pohe","1 bowl",160,"rice flakes (dry):42,onion:30,peanuts:8,oil:5","🥣","kanda poha onion poha कांदा पोहा पोहे कांदेपोहे"],
["Varan bhaat","1 bowl",250,"cooked rice:155,pigeon peas:80,ghee:3","🍚","varan bhat वरण भात"],
["Misal pav","1 plate with 1 pav",300,"cooked moth beans:100,farsan:25,pav:45,onion:25,tomato:30,oil:8","🍛","usal farsan मिसळ पाव"],
["Thalipeeth","1 medium",85,"jowar flour:18,gram flour:12,wheat flour:12,onion:18,oil:4","🫓","thalipith थालीपीठ"],
["Jowar bhakri","1 medium",75,"jowar flour:48","🫓","jwari bhakari भाकरी"],
["Bajri bhakri","1 medium",75,"bajra flour:48","🫓","bajra bhakari bajrichi bhakri बाजरीची भाकरी"],
["Matki usal","1 katori",150,"cooked moth beans:105,onion:20,coconut:7,oil:4","🫘","moth beans उसळ"],
["Amti dal","1 katori",150,"pigeon peas:110,coconut:5,jaggery:3,oil:4","🥣","aamti आमटी"],
["Pithla","1 katori",150,"gram flour:32,onion:20,oil:5","🥣","pitla pithale पिठलं"],
["Zunka","1 katori",120,"gram flour:40,onion:25,oil:7","🥣","jhunka झुणका"],
["Bharli vangi","1 katori",150,"eggplant:95,peanuts:15,coconut:10,oil:6,onion:20","🍆","bharleli vangi stuffed brinjal"],
["Batata bhaji","1 katori",150,"potato:115,onion:15,oil:6","🥔","aloo batatyachi bhaji"],
["Koshimbir","1 katori",100,"cucumber:70,peanuts:8,yogurt:20,coriander:2","🥒","kakdi raita"],
["Sabudana khichdi","1 bowl",160,"tapioca (dry):45,peanuts:14,potato:30,ghee:6","🥣","sabudana khichadi साबुदाणा खिचडी"],
["Sabudana vada","1 medium vada",55,"tapioca (dry):15,potato:19,peanuts:8,oil:6","🧆","sabudana wada"],
["Kothimbir vadi","2 pieces",65,"gram flour:25,coriander:15,peanuts:4,oil:5","🌿","kothambir wadi coriander fritters"],
["Kanda bhaji","3 small fritters",80,"onion:40,gram flour:20,oil:9","🧅","kanda bhajia bhajji pakoda"],
["Batata vada","1 medium vada",75,"potato:43,gram flour:13,oil:7","🥔","batata wada"],
["Vada pav","1 vada with pav",130,"potato:45,gram flour:15,oil:8,pav:48,peanuts:4","🥪","wada pav वडापाव"],
["Mumbai pav bhaji","1 plate with 2 pav",300,"pav:90,potato:70,vegetables:55,tomato:45,butter:12,oil:3","🍛","paav bhaji"],
["Mumbai bhel puri","1 plate",130,"puffed rice:21,sev:12,potato:25,onion:20,tomato:20,jaggery:6,coriander:7","🥣","bhelpuri bhel"],
["Ukadiche modak","1 steamed modak",50,"rice flour:16,coconut:12,jaggery:10,ghee:1","🥟","ukdiche modak ukadiche modak उकडीचे मोदक"],
["Puran poli","1 medium poli",85,"wheat flour:26,cooked chana dal:28,jaggery:19,ghee:5","🫓","puranpoli पुरणपोळी"],
["Shrikhand","1 small katori",100,"whole strained yogurt:72,sugar:24,cashews:3","🥣","shrikand श्रीखंड"],
["Sheera","1 small katori",100,"semolina:25,sugar:18,ghee:8,cashews:3","🥣","rava sheera suji halwa"],
["Masale bhaat","1 bowl",180,"cooked rice:125,vegetables:32,peanuts:7,coconut:5,oil:5","🍚","masala bhat"],
["Malvani fish curry","1 katori",180,"fish (cooked):85,coconut:20,onion:20,oil:5,kokum extract:4","🐟","malwani kalvan"],
["Bombil fry","2 pieces",100,"bombay duck (raw):100,semolina:10,rice flour:5,oil:9","🐟","Bombay duck fry"],
["Tambda rassa","1 bowl with meat",180,"mutton (cooked):85,onion:28,coconut:15,oil:6","🍛","Kolhapuri red mutton curry"],
["Chakli, homemade","1 spiral",25,"rice flour:12,gram flour:6,oil:6","🥨","chakali murukku"],
["Poha chivda","1 handful",30,"rice flakes (dry):18,peanuts:5,coconut:2,oil:3,sugar:1","🥜","chiwda chewda"],
];
const g:Recipe[]=[
["Goan fish curry rice","1 plate",350,"cooked rice:175,fish (cooked):85,coconut:18,onion:18,oil:4,kokum extract:4","🍛","xitt kodi xit koddi xit kodi fish thali"],
["Goan fish curry","1 katori, without rice",180,"fish (cooked):85,coconut:19,onion:20,oil:4,kokum extract:4","🐟","nustyachi kodi nusteachi koddi"],
["Chicken xacuti","1 katori",180,"chicken (cooked):95,coconut:24,onion:27,oil:6","🍛","shagoti shaguti shakuti"],
["Chicken cafreal","1 portion",150,"chicken (cooked):115,coriander:12,garlic:3,onion:10,oil:8","🍗","cafriyal galinha"],
["Prawn balchão","1 small katori",100,"prawns:58,onion:16,tomato:12,oil:8,sugar:3,vinegar:4,dried red chilli:1,garlic:2","🍤","balchao balchav"],
["Prawn curry","1 katori",180,"prawns:75,coconut milk:65,onion:18,tomato:15,oil:4","🍤","sungtache kodi sungta curry"],
["Fish recheado","1 stuffed mackerel",130,"indian mackerel (raw):122,onion:8,oil:8,dried red chilli:2,vinegar:5,garlic:2","🐟","bangda rechead bangdo"],
["Fish caldine","1 katori",180,"fish (cooked):80,coconut milk:65,vegetables:20,oil:3","🐟","caldin caldeen"],
["Ambot tik","1 katori",180,"fish (cooked):85,onion:28,tomato:24,oil:5,kokum extract:6","🐟","ambotik ambot teek"],
["Rava fried fish","1 fillet",100,"fish (cooked):75,semolina:14,oil:8","🐟","rawa fry kingfish surmai visvon"],
["Rava fried prawns","1 portion",100,"prawns:72,semolina:16,oil:8","🍤","sungta rawa fry"],
["Pork vindaloo","1 katori",160,"pork (cooked):100,onion:28,oil:7,dried red chilli:2,garlic:4,vinegar:8","🥘","vindalho vindalhu"],
["Pork sorpotel","1 katori",150,"pork (cooked):75,pork liver (cooked):25,onion:25,oil:5,vinegar:6,garlic:3,dried red chilli:2","🥘","sarapatel"],
["Chouriço pav","1 filled roll",120,"chouriço sausage:50,pav:48,onion:18","🥪","choriz pao choris pav sausage bread"],
["Goan poi","1 bread roll",65,"wheat flour:30,white flour:16","🥖","poee poie poiee pão bread"],
["Sannas","2 small sannas",90,"rice flour:35,coconut:6,sugar:4","🍘","sanna steamed rice cakes"],
["Goan red rice","1 cup cooked",170,"boiled red rice:170","🍚","ukde tandul parboiled rice"],
["Alsande tonak","1 katori",150,"black-eyed peas:95,coconut:17,onion:20,oil:4","🫘","alsanyache tonak black eyed peas"],
["Khatkhate","1 katori",160,"vegetables:95,pigeon peas:35,coconut:15","🥕","khatkhaten mixed vegetables"],
["Mooga gathi","1 katori",150,"cooked mung beans:95,coconut:18,jaggery:3,oil:4","🫘","moong gathi mooga gaathi"],
["Tisryo sukhem","1 katori, shelled",125,"clams:70,coconut:15,onion:25,oil:4","🐚","tisreo sukhe clams"],
["Sol kadhi","1 glass",150,"coconut milk:55,kokum extract:8,coriander:3","🥛","solkadi kokum kadhi"],
["Bebinca","1 slice",60,"egg yolk:10,coconut milk:18,white flour:9,sugar:16,ghee:5","🍰","bebik bibik bibinca bebinka"],
["Dodol","1 piece",45,"rice flour:8,coconut milk:18,jaggery:15,cashews:2","🍮","goan coconut sweet"],
["Patoleo","1 leaf parcel",80,"rice flour:20,coconut:18,jaggery:13","🥥","patoli patolyo"],
["Ros omelette","1 omelette with gravy",175,"raw egg:55,onion:20,coconut:14,chicken (cooked):25,oil:6","🍳","ras omelet ross omelette"],
];
const c:Recipe[]=[
["Grilled chicken breast","1 cooked fillet",150,"chicken (cooked):145,oil:5","🍗","herb roast chicken"],
["Spaghetti aglio e olio","1 pasta bowl",220,"pasta (cooked):195,olive oil:12,garlic:5,parsley:2","🍝","garlic olive oil spaghetti"],
["Penne arrabbiata","1 pasta bowl",250,"pasta (cooked):170,passata:55,onion:15,olive oil:7,garlic:3,dried red chilli:1","🍝","red sauce pasta arabbiata"],
["Alfredo pasta","1 pasta bowl",250,"pasta (cooked):175,cream:42,parmesan:15,butter:7","🍝","white sauce pasta fettuccine"],
["Spaghetti bolognese","1 pasta bowl",280,"pasta (cooked):160,beef (cooked):55,tomato:40,onion:15,oil:5","🍝","bolognaise"],
["Margherita pizza","1 medium slice",100,"white flour:29,mozzarella:19,passata:21,olive oil:4,basil:1","🍕","margarita pizza"],
["Mushroom risotto","1 bowl",220,"cooked rice:145,mushrooms:40,parmesan:11,butter:7,onion:14","🍚","risoto"],
["Vegetable lasagne","1 square",220,"pasta (cooked):90,cheese:35,tomato:42,vegetables:28,cream:16,oil:4","🍝","lasagna"],
["Chicken Caesar salad","1 meal bowl",250,"chicken (cooked):75,romaine:121,bread:20,mayonnaise:18,parmesan:12,garlic:1,vinegar:3","🥗","caesar cesar chicken salad"],
["Garden salad, vinaigrette","1 salad bowl",170,"romaine:95,tomato:35,cucumber:30,olive oil:7,vinegar:3","🥗","green garden salad"],
["Greek salad","1 salad bowl",190,"cucumber:65,tomato:60,onion:15,feta:28,olive oil:7,black olives:15","🥗","feta salad"],
["Grilled fish with vegetables","1 plate",250,"fish (cooked):130,vegetables:110,oil:7","🐟","pan seared fish"],
["Mashed potatoes","1 side",150,"potato:126,milk:16,butter:8","🥔","mash"],
["Roasted vegetables","1 side",150,"vegetables:140,oil:8","🥕","oven roasted veg"],
["Garlic bread","2 small slices",65,"bread:52,butter:10,garlic:3,parsley:1","🥖","garlic toast"],
["Grilled cheese sandwich","1 sandwich",100,"bread:60,cheese:34,butter:9","🥪","cheese toastie"],
["Chicken club sandwich","1 sandwich",209,"bread:85,chicken (cooked):60,boiled egg:22,romaine:14,tomato:14,mayonnaise:14","🥪","clubhouse sandwich"],
["Scrambled eggs on toast","1 plate",158,"raw egg:100,bread:44,milk:15,butter:6","🍳","egg toast"],
["Cheese omelette","1 two-egg omelette",145,"raw egg:100,cheese:24,onion:15,butter:5","🍳","cheese omelet"],
["Cream of mushroom soup","1 soup bowl",220,"mushrooms:80,milk:90,cream:16,butter:5,white flour:6","🥣","mushroom soup"],
["Tomato soup","1 soup bowl",220,"tomato:150,onion:22,cream:10,butter:4,sugar:2","🍅","tomato bisque"],
["French toast","2 small slices",128,"bread:60,raw egg:35,milk:25,sugar:8,butter:5","🍞","pain perdu"],
["Pancakes, plain","2 small pancakes",94,"white flour:37,milk:40,raw egg:14,butter:5,sugar:4","🥞","hotcakes"],
["Baked potato with butter","1 potato",176,"baked potato:167,butter:9","🥔","jacket potato"],
["Potato wedges","1 side",125,"baked potato:115,oil:9","🥔","oven fries"],
["Macaroni and cheese","1 bowl",200,"pasta (cooked):130,cheese:30,milk:27,butter:6,white flour:4","🧀","mac and cheese"],
];
const variants:Record<string,string>={
 "Chicken pot pie":"Single butter-pastry lid, chicken breast and creamy vegetable filling. Finished weight includes water in the gravy; no base crust or side.",
 "Nutella brownie":"Chocolate-hazelnut spread, flour and egg version. A single unadorned square with no ice cream or sauce. Brand nutrition applies only to the spread.",
 "Chicken puff":"Flour and butter represent the pastry layers. Estimated cooked filling and egg wash.",
 "Mushroom and cheese puff":"Flour and butter represent the pastry layers. Includes cheese and cooked mushroom filling.",
 "Bun maska":"Plain pav approximates the café bun. Includes 15 g butter; log chai separately.",
 "Akuri on toast":"Two eggs with tomato, onion and butter, with one slice of plain white toast.",
 "Bombay grilled vegetable sandwich":"Two slices with potato and vegetables. Butter and coriander included; no cheese or ketchup.",
 "Chilli cheese toast":"Cheddar on two small slices. Dried chilli approximates the chilli seasoning.",
 "Prawn rissóis":"Milk-and-flour dough with prawn filling. Bread approximates crumbs; oil represents absorbed frying oil.",
 "Chicken cafreal poi":"The poi is modelled from flour and water; chicken breast with green marinade is the filling.",
 "Goan beef croquette":"Cooked mince, potato binder, crumb coating and estimated absorbed frying oil.",
 "Goan bolinha":"Fresh coconut, semolina and sugar version. One small baked biscuit.",
 "Alle belle":"One milk-and-egg crepe with fresh coconut and jaggery filling. Cane jaggery approximates palm jaggery.",
 "Varan bhaat":"Whole boiled pigeon peas approximate split toor dal.","Amti dal":"Whole boiled pigeon peas approximate split toor dal.",
 "Puran poli":"Whole cooked chickpeas approximate split chana dal.","Shrikhand":"Whole-milk strained yogurt approximates chakka.",
 "Misal pav":"Cooked whole moth beans approximate short home-sprouted matki.","Matki usal":"Cooked moth beans approximate short-sprouted matki.","Mooga gathi":"Whole cooked mung approximates short, bean-heavy sprouts.",
 "Chicken cafreal":"Lean chicken breast with a coriander-garlic marinade. Green chillies and spices are unquantified.","Chicken xacuti":"Chicken breast and coconut version. Xacuti spices are unquantified.",
 "Goan red rice":"Cooked wholegrain red rice is a proxy for the local variety.","Alsande tonak":"This variation uses black-eyed cowpeas in place of Goan red cowpeas.",
 "Goan poi":"Flour weights are dry. Fermentation is unmodelled.","Sannas":"Rice flour represents rice solids. Fermentation is unmodelled.","Goan fish curry rice":"White rice accompanies this cod-based approximation.",
 "Pork vindaloo":"Distilled vinegar approximates Goan palm vinegar.","Pork sorpotel":"Pork shoulder and liver version with distilled vinegar.",
 "Chouriço pav":"The Portuguese sausage approximates Goan chouriço. Fat and salt vary by producer.",
 "Mushroom risotto":"Cooked long-grain rice approximates risotto rice.","Khatkhate":"Whole pigeon peas approximate split toor dal.",
 "Chicken Caesar salad":"Mayonnaise, garlic and vinegar dressing. Croutons are represented by bread.",
 "Poha chivda":"Fresh coconut version.","Fish recheado":"The weight of mackerel is raw edible flesh before frying.","Bombil fry":"The fish weight is raw cleaned edible flesh before frying.",
};
export function recipes(list:Recipe[],group:string):LibraryFood[]{return list.map(([name,serving,grams,parts,icon,aliases])=>{
 const ingredients=parts.split(",").map(item=>{
   const [key,g]=item.split(":");
   const ref=ingredientRefs.get(key);
   if(!ref)throw Error("Unknown recipe ingredient "+key+" in "+name);
   const values=ref.values;
   return {key,g:Number(g),values,ref};
 });
 const values:Record<string,number>={};
 for(const key of Object.keys(ingredients[0].values)){
   if(key==="sodium"||key==="salt")continue;
   if(ingredients.every(i=>i.values[key]!==undefined)){
     values[key]=ingredients.reduce((sum,i)=>sum+i.g*i.values[key]/100,0);
   }
 }
 const urls=[...new Set(ingredients.map(i=>i.ref?.source).filter((v):v is string=>!!v))];
 const detail="Illustrative recipe, finished yield "+grams+" g. "+ingredients.map(i=>i.g+" "+(i.ref.basisUnit||"g")+" "+i.ref.name).join(", ")+". "+(variants[name]||"")+" Added salt is unmeasured. Heat-sensitive vitamins are ingredient estimates before additional cooking losses.";
 const panel:NutritionPanel={kind:"Recipe estimate",amount:grams,unit:"g",values,detail:detail.trim(),source:urls[0],links:urls.slice(1),checked:"2026-11-24"};
 return {...makePanelFood(name,serving,grams,panel,icon),group,aliases,portionKind:"Recipe estimate",note:panel.detail,source:panel.source};
})}
const packaged:LibraryFood[]=packagedData.map(r=>{
 const panel=panelSchema.parse(r.panel);
 const icon=r.group==="Protein bars"?"🍫":panel.unit==="ml"?"🥛":r.group==="Indian market snacks"?"🥨":"📦";
 return {...makePanelFood(r.name,r.serving,r.size,panel,icon),group:r.group,portionKind:panel.kind,source:panel.source,note:panel.variant,aliases:panel.brand==="Yoga Bar"?"yogabar yoga bar snacks protein":"packaged"};
});
export const regional:LibraryFood[]=[...recipes(m,"Maharashtrian"),...recipes(g,"Goan"),...recipes(c,"Continental"),...recipes(mumbaiCafe,"Mumbai cafés"),...recipes(goanCafe,"Goan cafés"),...panajiMenu,...packaged];
