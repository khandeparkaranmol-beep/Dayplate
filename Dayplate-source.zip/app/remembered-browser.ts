import {apiOrigin} from "../lib/pages-origin";
import {deviceAlgorithm,deviceMessage,hex,proofAlgorithm} from "../lib/remembered-browser";

type BrowserKey={publicKey:string,privateKey:CryptoKey};
const databaseName="dayplate-remembered-browser";
async function useKey<T>(mode:IDBTransactionMode,action:(store:IDBObjectStore,done:(value:T)=>void)=>void):Promise<T>{
  const db=await new Promise<IDBDatabase>((resolve,reject)=>{
    const request=indexedDB.open(databaseName,1);
    request.onupgradeneeded=()=>request.result.createObjectStore("keys");
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error);
  });
  try{return await new Promise<T>((resolve,reject)=>{
    const transaction=db.transaction("keys",mode);
    let result:T;
    transaction.oncomplete=()=>resolve(result);
    transaction.onerror=transaction.onabort=()=>reject(transaction.error);
    action(transaction.objectStore("keys"),value=>{result=value});
  })}finally{db.close()}
}
export function readBrowserKey(){
  return useKey<BrowserKey|undefined>("readonly",(store,done)=>{
    const read=store.get("current");read.onsuccess=()=>done(read.result);
  });
}
export function forgetBrowserKey(publicKey?:string){
  return useKey<void>("readwrite",store=>{
    const read=store.get("current");
    read.onsuccess=()=>{if(!publicKey||read.result?.publicKey===publicKey)store.delete("current")};
  });
}
const request=(path:string,init:RequestInit)=>fetch(apiOrigin+path,{...init,cache:"no-store",credentials:"omit",redirect:"error"});
function deviceRequest(body:object,token?:string){
  const headers=new Headers({"Content-Type":"application/json"});
  if(token)headers.set("Authorization","Bearer "+token);
  return request("/api/google/device",{method:"POST",headers,body:JSON.stringify(body)});
}
export async function rememberBrowser(token:string){
  const keys=await crypto.subtle.generateKey(deviceAlgorithm,false,["sign","verify"]) as CryptoKeyPair;
  const publicKey=hex(await crypto.subtle.exportKey("raw",keys.publicKey));
  const response=await deviceRequest({action:"remember",publicKey},token);
  if(!response.ok)return false;
  await useKey<void>("readwrite",store=>{store.put({publicKey,privateKey:keys.privateKey},"current")});
  return true;
}
export async function resumeBrowser(key:BrowserKey){
  const challenge=await request("/api/google/nonce",{});
  if(!challenge.ok)throw Error("Could not reconnect to Dayplate.");
  const {nonce,verifier}=await challenge.json() as {nonce:string,verifier:string};
  if(!/^[a-f0-9]{64}$/.test(nonce)||!/^[a-f0-9]{64}$/.test(verifier))throw Error("Could not reconnect to Dayplate.");
  const proof=hex(await crypto.subtle.sign(proofAlgorithm,key.privateKey,deviceMessage(nonce)));
  const res=await deviceRequest({action:"resume",publicKey:key.publicKey,verifier,proof});
  if(res.status===410){await forgetBrowserKey(key.publicKey);return null}
  if(!res.ok)throw Error("Could not reconnect to Dayplate.");
  const {token}=await res.json() as {token:string};
  if(!/^[a-f0-9]{64}$/.test(token))throw Error("Could not reconnect to Dayplate.");
  return token;
}
