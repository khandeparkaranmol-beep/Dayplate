import {z} from "zod";
import {recordSchema,foodEntries,type Entry,type Meal,type Stored,shift} from "./model";

export type FoodEntry=Extract<Entry,{kind:"food"}>;
export const repeatSchema=z.object({
  action:z.literal("repeat"),
  entries:z.array(recordSchema).min(1).max(40),
}).refine(batch=>batch.entries.every(e=>e.kind==="food"&&e.day===batch.entries[0].day)
  && new Set(batch.entries.map(e=>e.id)).size===batch.entries.length);

export function previousMeals(rows:Stored[],day:string){
  const grouped=new Map<string,{day:string,meal:Meal,entries:FoodEntry[]}>();
  const first=shift(day,-30);
  for(const row of foodEntries(rows).filter(r=>r.day<day&&r.day>=first).sort((a,b)=>b.day.localeCompare(a.day))){
    const key=row.day+" "+row.data.meal;
    const group=grouped.get(key)??{day:row.day,meal:row.data.meal,entries:[]};
    group.entries.push(row);grouped.set(key,group);
  }
  return [...grouped.values()].filter(g=>g.entries.length<=40);
}

export function sameEntry(existing:Stored,incoming:Entry){
 return existing.id===incoming.id&&existing.day===incoming.day&&existing.kind===incoming.kind
   &&JSON.stringify(existing.data)===JSON.stringify(incoming.data);
}
