import {makePanelFood, type NutritionPanel} from "./nutrition";
import type {LibraryFood} from "./regional";
import west from "./data/restaurant-west.json";
import east from "./data/restaurant-east.json";
import kfc from "./data/restaurant-kfc.json";
import bk from "./data/restaurant-bk.json";
import ph from "./data/restaurant-ph.json";
import wow from "./data/restaurant-wow.json";
import dominos from "./data/restaurant-dominos.json";

type Item = {
  name:string; section:string; page:number; amount:number; unit:string;
  values:Record<string,number|undefined>; size?:number; serving?:string; detail?:string; source?:string;
  bounds?:Record<string,string|undefined>;
};
type Menu = {brand:string; region:string; source:string; items:Item[]};
const menus:Menu[]=[west,east,kfc,bk,ph,dominos,wow];
export const restaurantBrands=[...new Set(menus.map(menu=>menu.brand))];
const aliases:Record<string,string>={
  "West & South":"McD McDonalds Mumbai Goa Pune Karnataka Bengaluru Bangalore Hyderabad Chennai Maharashtra",
  "North & East":"McD McDonalds Delhi NCR Kolkata Punjab",
  "KFC":"Kentucky Fried Chicken",
  "Burger King":"BK", "Domino’s":"Dominos", "Wow! Momo":"Wow Momos",
};
function iconFor(text:string) {
  if (/pizza|margherita/i.test(text)) return "🍕";
  if (/momo/i.test(text)) return "🥟";
  if (/fries/i.test(text)) return "🍟";
  if (/burger|zinger|whopper|tikki/i.test(text)) return "🍔";
  if (/coffee|tea|latte|cappuccino|espresso|mcafé/i.test(text)) return "☕";
  if (/sundae|soft serve|mcflurry|dessert/i.test(text)) return "🍦";
  if (/chicken|wings|strip/i.test(text)) return "🍗";
  if (/beverage|drink|pepsi|cola|shake/i.test(text)) return "🥤";
  return "🍽️";
}
export const restaurantFoods:LibraryFood[]=menus.flatMap(menu=>menu.items.map(item=>{
  const regional=menu.brand==="McDonald’s";
  const name=menu.brand+" · "+item.name+(regional?" ("+menu.region+")":"");
  const size=item.size??item.amount;
  const serving=item.serving??"1 menu portion";
  const source=item.source??(menu.brand==="Domino’s"?menu.source.replace("{page}",String(item.page).padStart(2,"0")):
    menu.source.endsWith(".pdf")||menu.brand==="Burger King"?menu.source+"#page="+item.page:menu.source);
  const variant=[menu.brand,menu.region,item.section].join(" · ");
  let detail=item.detail??"";
  if(menu.brand==="Wow! Momo")detail="The Darjeeling restaurant listing gives energy per 100 g. Weigh your portion to log it.";
  if(menu.brand==="Pizza Hut"&&size!==item.amount)detail="The menu lists "+item.amount+" g for the full order. This portion is "+serving+".";
  if(menu.brand==="Domino’s")detail="The published column covers "+item.amount+" slices. Log the number of slices you ate.";
  const panel:NutritionPanel={
    amount:item.amount,unit:item.unit as NutritionPanel["unit"],kind:"Restaurant menu",
    values:item.values as NutritionPanel["values"],brand:menu.brand,variant,source,checked:"2026-11-25",
    ...(item.bounds?{bounds:item.bounds as NutritionPanel["bounds"]}:{}),
    ...(menu.brand==="KFC"&&!item.source?{links:["https://about.kfc.co.in/assets/files/nutrition-booklet.pdf"]}:{}),
    detail:detail||"Values for the published Indian menu portion. Availability and preparation can vary by outlet.",
  };
  const food=makePanelFood(name,serving,size,panel,iconFor(item.name+" "+item.section));
  return {...food,group:"Indian fast food",source,portionKind:panel.kind,note:panel.detail,
    aliases:[aliases[menu.region],aliases[menu.brand],item.name.replace(/Mc\s*(?=[A-Z])/g,"Mc ")].filter(Boolean).join(" ")};
}));
