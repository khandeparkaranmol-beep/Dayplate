export async function shareJSON(json:string,filename:string,kind:"audit"|"backup"){
 const url=URL.createObjectURL(new Blob([json],{type:"application/json"}));
 const a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),30000);
}
