import {z} from "zod";
import {meals} from "./model";

export const snapshotSections=[...meals,"Workouts"] as const;
export const snapshotFields={
  foodDetails:"Food names and portions",foodEnergy:"Food calories",protein:"Protein",sugar:"Total sugar",
  workoutEnergy:"Workout calories",steps:"Steps",activeEnergy:"Daily active calories"
} as const;
export type SnapshotField=keyof typeof snapshotFields;
export const snapshotFieldKeys=Object.keys(snapshotFields) as [SnapshotField,...SnapshotField[]];
export const visibilitySchema=z.object({
  sections:z.array(z.enum(snapshotSections)).max(snapshotSections.length),
  fields:z.array(z.enum(snapshotFieldKeys)).max(snapshotFieldKeys.length),
  hiddenIds:z.array(z.string().min(1).max(80)).max(1000)
}).strict();
export type SnapshotVisibility=z.infer<typeof visibilitySchema>;
export const fullVisibility:SnapshotVisibility={sections:[...snapshotSections],fields:[...snapshotFieldKeys],hiddenIds:[]};
export function hasSharedContent(v:SnapshotVisibility){
  return v.fields.includes("steps")||v.fields.includes("activeEnergy")||v.sections.includes("Workouts")||
    (v.sections.length>0&&v.fields.some(f=>f==="foodDetails"||f==="foodEnergy"||f==="protein"||f==="sugar"));
}
