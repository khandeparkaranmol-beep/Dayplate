export const contests={
 steps:{name:"Step challenge",unit:"steps",about:"Compare total imported steps."},
 workout:{name:"Workout days",unit:"days",about:"One point for each day with a workout."},
 journal:{name:"Journal days",unit:"days",about:"One point for each food journal marked complete."},
 minutes:{name:"Workout minutes",unit:"min",about:"Compare the time spent in logged workouts."}
} as const;
export type Contest=keyof typeof contests;
export type Friendship={peer:string,state:"friend"|"received"|"sent"};
export type Match={id:string,peer:string,incoming:boolean,metric:Contest,length:number,start:string|null,finish:string|null,mine:number,theirs:number,mineDays:number,theirDays:number};
export type FriendPost={id:string,author:string,content:string,created:string,cheers:number,cheered:number};
export type Circle={handle:string|null,people:Friendship[],matches:Match[],posts:FriendPost[]};
