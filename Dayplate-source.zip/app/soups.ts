import dishes from "./data/soups.json";
import {makePanelFood, panelSchema} from "./nutrition";
import type {LibraryFood} from "./regional";

export const soupGroup = "Soups";

// Keep the original portions and nutrition panels for recipes already in the diary.
export const existingSoupNames = new Set([
  "Cream of mushroom soup", "Tomato soup", "Vegetable Manchow soup", "Chicken Manchow soup",
  "Hot and sour vegetable soup", "Sweet corn chicken soup", "Miso soup with tofu and wakame",
  "New England clam chowder", "Manhattan clam chowder", "Chicken noodle soup, American style",
  "Louisiana-style chicken gumbo soup", "Ayoyo soup with smoked herring",
  "Ghanaian groundnut soup with chicken", "Ghanaian light soup with goat"
]);

export const soupFoods: LibraryFood[] = dishes.map(dish => {
  const panel = panelSchema.parse({
    amount: 100, unit: "g", kind: "Recipe estimate", checked: "2026-11-27",
    source: "https://fdc.nal.usda.gov/download-datasets/", links: dish.links,
    detail: dish.detail, values: dish.values
  });
  return {
    ...makePanelFood(dish.name, dish.serving, dish.grams, panel, "🥣"),
    group: soupGroup, tags: dish.tags, aliases: dish.aliases
  };
});
