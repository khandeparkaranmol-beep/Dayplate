"use client";
import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import { type Food } from "./model";
export function Modal({title,description,children,close}:{title:string,description?:string,children:React.ReactNode,close:()=>void}) {
 const ref=useRef<HTMLDialogElement>(null);
 const latest=useRef(close);latest.current=close;
 useEffect(()=>{const d=ref.current,button=document.activeElement as HTMLElement|null; d?.showModal();const prior=document.body.style.overflow;document.body.style.overflow="hidden";return()=>{d?.close();document.body.style.overflow=prior;button?.focus()};},[]);
 return <dialog ref={ref} onCancel={e=>{e.preventDefault();latest.current()}} onClick={e=>{if(e.target===ref.current){const r=ref.current.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close()}}} aria-labelledby="modal-title"><div className="dialog-content"><div className="dialog-head"><div><h2 id="modal-title">{title}</h2>{description&&<p>{description}</p>}</div><button className="icon-btn" aria-label="Close dialog" onClick={close}><X size={19}/></button></div>{children}</div></dialog>
}
export function FoodIcon({food}:{food:Food}){return <span className="food-emoji" aria-hidden="true">{food.icon}</span>}
export function Field({label,children}:{label:string,children:React.ReactNode}){return <label className="field"><span>{label}</span>{children}</label>}
export function Empty({children}:{children:React.ReactNode}){return <p className="empty">{children}</p>}
