"use client";
import {isDarkMagicQuery} from "./countable-foods";
import {FoodFilters} from "./FoodFilters";
import CatalogAudit from "./CatalogAudit";
import {BiscuitLabel} from "./BiscuitLabel";
import {useMemo,useState} from "react";
import {Plus, Search, Scale, Footprints, Flame, TrendingUp, Trash2, ListFilter, BookOpen, ChevronDown} from "lucide-react";
import {type Stored,type Food,format,shift,dateKey,totals,foodEntries,completeDay} from "./model";
import {dishes} from "./JournalSpread";
import {burnLabel} from "./workout-energy";
import {duration} from "./Movement";
import {foodKey,sugarSummary} from "./nutrition";
import {catalog, inGroup, collectionFoods, searchFood} from "./catalog";
import {FoodIcon,Empty} from "./ui";
const coverCounts=new Map(dishes.map(d=>[d.cuisine,catalog.filter(f=>inGroup(f,d.cuisine)).length]));
export function LibraryView({foods,choose,create,product}:{foods:Food[],choose:(f:Food)=>void,create:()=>void,product:(name?:string)=>void}) {
 const [q,query]=useState(""),[group,select]=useState("All"),[audit,showAudit]=useState(false);
 const [visible,setVisible]=useState(48);
 const collection=useMemo(()=>collectionFoods(foods,group),[foods,group]);
 const available=useMemo(()=>searchFood(collection,q),[collection,q]);
 return <><div className="collection-covers">{dishes.map(d=><button key={d.cuisine} className={"collection-cover art-"+d.image} aria-pressed={group===d.cuisine} onClick={()=>{select(d.cuisine);query("");setVisible(48)}}><span><small>{coverCounts.get(d.cuisine)} dishes</small><b>{d.cuisine}</b></span><ChevronDown size={17}/></button>)}</div><section className="panel library"><div className="section-head"><div><h2>Browse foods</h2><small>Choose a food to add it to your journal.</small></div></div><div className="lib-controls"><label className="search"><Search size={18}/><input placeholder="Search a dish, restaurant or brand…" aria-label="Search food library" value={q} onChange={e=>{query(e.target.value);setVisible(48)}}/></label></div><FoodFilters value={group} library onChange={g=>{select(g);setVisible(48)}}/><details className="foods-tools"><summary>Custom foods, packages and data sources</summary><div className="library-actions"><button className="text-btn" onClick={()=>showAudit(!audit)}>{audit?"Close audit":"Data audit"}</button><button className="light" onClick={create}><Plus size={16}/>Custom food</button><button className="primary" onClick={()=>product()}>Find a package</button></div>{audit&&<CatalogAudit initialOpen/>}</details><p className="food-result-count" aria-live="polite">{available.length.toLocaleString()} {available.length===1?"match":"matches"}</p>{isDarkMagicQuery(q)&&<BiscuitLabel open={product}/>}<div className="food-grid">{available.slice(0,visible).map(f=><button className="pick" key={foodKey(f)} onClick={()=>choose(f)}><FoodIcon food={f}/><span className="grow"><b>{f.name}</b><small>{f.serving} · {format(f.kcal)} kcal · {sugarSummary(f)}</small></span><Plus size={16}/></button>)}</div>{available.length>visible&&<button className="light" onClick={()=>setVisible(visible+48)}>Show more foods</button>}
{!available.length&&!isDarkMagicQuery(q)&&<Empty>{group==="My foods"?"Create a food to save your own recipe or label.":"No matches. Create a food using the package or recipe values."}</Empty>}</section></>
}
function WeightChart({weights,start,end}:{weights:{day:string,kg:number}[],start:string,end:string}) {
 if(!weights.length)return <div className="chart-empty"><Scale size={25}/><p>Your first weigh-in starts the chart.</p></div>;
 const min=Math.min(...weights.map(w=>w.kg)),max=Math.max(...weights.map(w=>w.kg));
 const lo=Math.floor(min-0.5),hi=Math.ceil(max+.5);
 const epoch=(d:string)=>new Date(d+"T12:00:00Z").getTime();
 const x=(d:string)=>58+(epoch(d)-epoch(start))/(epoch(end)-epoch(start))*496;
 const y=(v:number)=>133-(v-lo)/(hi-lo)*107;
 const pts=weights.map(w=>[x(w.day),y(w.kg)]);
 return <svg className="weight-graph" viewBox="0 0 575 165" role="img" aria-label={"Weight trend from "+weights[0].kg+" to "+weights[weights.length-1].kg+" kilograms"}>{[lo,(hi+lo)/2,hi].map(v=><g key={v}><path d={`M55 ${y(v)}H557`} stroke="#e2e5eb" strokeDasharray="4 5"/><text x="46" y={y(v)+4} textAnchor="end">{v} kg</text></g>)}<polyline points={pts.map(p=>p.join(",")).join(" ")} fill="none" stroke="#0065ce" strokeWidth="3" strokeLinejoin="round"/>{pts.map(([x,y],i)=><circle cx={x} cy={y} r="4" fill="#fff" stroke="#0065ce" strokeWidth="2" key={i}><title>{weights[i].day+" · "+weights[i].kg+" kg"}</title></circle>)}<text x="55" y="156">{start.slice(5)}</text><text x="555" y="156" textAnchor="end">{end.slice(5)}</text></svg>
}
export function ProgressView({rows,day,weight,exercise,remove,busy,openDay}:{openDay:(d:string)=>void,rows:Stored[],day:string,weight:()=>void,exercise:()=>void,remove:(r:Stored)=>Promise<boolean>,busy:boolean}) {
 const [period,setPeriod]=useState(7),[confirm,setConfirm]=useState("");
 const start=shift(day,1-period),periodRows=rows.filter(r=>r.day>=start&&r.day<=day);
 const days=Array.from({length:period},(_,i)=>shift(start,i)), entries=foodEntries(periodRows);
 const perDay=days.map(day=>{const daily=entries.filter(e=>e.day===day);return {day,kcal:totals(daily).kcal,logged:daily.length>0}});
 const logged=perDay.filter(d=>d.logged),complete=logged.filter(d=>completeDay(rows,d.day)),avg=complete.length?complete.reduce((a,d)=>a+d.kcal,0)/complete.length:null;
 const weights=periodRows.filter(r=>r.kind==="weight").sort((a,b)=>a.day.localeCompare(b.day)).map(r=>({day:r.day,kg:r.data.kg}));
 const history=periodRows.filter(r=>r.kind==="weight"||r.kind==="exercise"||r.kind==="measure").sort((a,b)=>b.day.localeCompare(a.day));
 const minutes=periodRows.filter(r=>r.kind==="exercise").reduce((s,r)=>s+r.data.minutes,0);
 if(!rows.some(r=>r.day<=day&&["food","weight","exercise","measure","activity"].includes(r.kind)))return <section className="panel"><h2>Weight and activity</h2><p>Log a workout to see your active minutes here. Two weigh-ins let you see your weight change.</p><button className="light" onClick={exercise}>Log a workout</button></section>;
 return <><div className="progress-tools"><div className="segmented compact">{[7,30].map(n=><button key={n} className={n===period?"sel":""} onClick={()=>setPeriod(n)}>{n} days</button>)}</div></div><div className="stat-grid">{[{title:"Average food intake",value:avg===null?"—":format(avg),unit:"kcal",sub:complete.length+" complete "+(complete.length===1?"day":"days")+" · "+(logged.length-complete.length)+" partial",Icon:Flame},{title:"Weight change",value:weights.length<2?"—":((weights.at(-1)!.kg-weights[0].kg)>0?"+":"")+(weights.at(-1)!.kg-weights[0].kg).toFixed(1),unit:"kg",sub:weights.length+" weigh-ins",Icon:Scale},{title:"Activity",value:format(minutes),unit:"min",sub:"In this period",Icon:Footprints}].filter(s=>s.value!=="—").map(s=><article className="panel stat" key={s.title}><s.Icon size={20}/><h3>{s.title}</h3><strong>{s.value} <small>{s.unit}</small></strong><small>{s.sub}</small></article>)}</div><div className="progress-grid"><section className="panel"><div className="section-head"><h2>Weight trend</h2></div><WeightChart weights={weights} start={start} end={day}/></section><section className="panel"><div className="section-head"><h2>Daily calories</h2></div>{logged.length?<><div className="bars" aria-label="Open a day in your journal">{perDay.map(d=><button aria-label={d.day+" · "+(d.logged?format(d.kcal)+" kcal":"No foods logged")+". Open journal"} onClick={()=>openDay(d.day)} key={d.day} title={d.day+" · "+(d.logged?format(d.kcal)+" kcal":"No log")} style={{height:d.logged?Math.max(2,d.kcal/Math.max(...logged.map(k=>k.kcal),1)*100)+"%":"2px",background:d.logged?"#67916a":"#dedfd7"}}/>)}</div><div className="axis"><span>{start.slice(5)}</span><span>{day.slice(5)}</span></div><small>Select a day to see its meals.</small></>:<div className="chart-empty"><Flame size={25}/><p>Log a food to see your daily intake.</p></div>}</section></div><section className="panel"><div className="section-head"><h2>Weight & activity log</h2><button className="light" onClick={exercise}><Plus size={16}/>Activity</button></div>{history.length?history.map(r=><div key={r.id} className="history-row">{r.kind!=="exercise"?<Scale size={19}/>:<Footprints size={19}/>}<div className="grow"><b>{r.kind==="weight"?r.data.kg+" kg":r.kind==="measure"?[r.data.height&&"Height "+r.data.height+" cm",r.data.waist&&"Waist "+r.data.waist+" cm"].filter(Boolean).join(" · "):r.data.name+" · "+duration(r.data.minutes)}</b><small>{r.day}{r.kind==="exercise"&&" · "+burnLabel(r,rows)}</small></div><button className="icon-btn" disabled={busy} aria-label={confirm===r.id?"Confirm removal":"Remove record"} onClick={()=>{if(confirm===r.id){void remove(r);setConfirm("")}else setConfirm(r.id)}}>{confirm===r.id?"Remove?":<Trash2 size={15}/>}</button></div>):<Empty>Weigh-ins and workouts in this period will appear here.</Empty>}</section></>
}
