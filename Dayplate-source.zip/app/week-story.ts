import {completeDay,foodEntries,shift,type Stored} from "./model";
import {dayNutrient} from "./nutrition";

export type Experiment=Extract<Stored,{kind:"experiment"}>;
export type Hunger=Extract<Stored,{kind:"hunger"}>;
export const shortDay=(day:string)=>new Date(day+"T12:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"short"});
export const rounded=(value:number)=>Number(value.toFixed(1)).toLocaleString("en-IN");
function knownTotal(rows:Stored[],key:string){
  const fact=dayNutrient(rows,key);
  return fact.total>0&&fact.known===fact.total?fact.sum:null;
}
export function weekStory(rows:Stored[],end:string,keys:string[]){
  const days=Array.from({length:7},(_,i)=>shift(end,i-6));
  const start=days[0],week=rows.filter(r=>r.day>=start&&r.day<=end).sort((a,b)=>a.day.localeCompare(b.day));
  const daily=days.map(day=>({day,foods:foodEntries(week).filter(r=>r.day===day),complete:!!completeDay(week,day)}));
  const complete=daily.filter(d=>d.complete&&d.foods.length>0);
  const averages=keys.map(key=>{
    const values=complete.flatMap(d=>knownTotal(d.foods,key)??[]);
    return {key,days:values.length,value:values.length?values.reduce((a,b)=>a+b,0)/values.length:null};
  });
  const sessions=week.filter(r=>r.kind==="exercise");
  return {start,end,daily,complete:complete.length,logged:daily.filter(d=>d.foods.length>0).length,averages,sessions,
    minutes:sessions.reduce((sum,r)=>sum+r.data.minutes,0),
    weights:week.filter(r=>r.kind==="weight").map(r=>({day:r.day,value:r.data.kg})),
    waists:week.flatMap(r=>r.kind==="measure"&&r.data.waist!=null?[{day:r.day,value:r.data.waist}]:[])};
}
export function breakfastNotes(story:ReturnType<typeof weekStory>,key:string){
  return story.daily.filter(d=>d.complete).flatMap(d=>{
    const foods=d.foods.filter(r=>r.data.meal==="Breakfast"),value=knownTotal(foods,key);
    return value==null?[]:[{day:d.day,names:foods.map(r=>r.data.food.name).join(", "),value}];
  }).sort((a,b)=>b.value-a.value||b.day.localeCompare(a.day));
}
export function hungerSummary(rows:Stored[],experiment:Experiment,asOf:string){
  const last=experiment.data.end&&experiment.data.end<asOf?experiment.data.end:asOf;
  const entries=rows.filter((r):r is Hunger=>r.kind==="hunger"&&r.data.experiment===experiment.id&&r.day>=experiment.day&&r.day<=last);
  return (["first","second"] as const).map(choice=>{
    const ratings=entries.filter(r=>r.data.choice===choice);
    return {choice,name:experiment.data[choice],count:ratings.length,mean:ratings.length?ratings.reduce((s,r)=>s+r.data.rating,0)/ratings.length:null};
  });
}
export function boxingLabel(b:NonNullable<Extract<Stored,{kind:"exercise"}>["data"]["boxing"]>){
  return b.rounds+" × "+b.roundMinutes+" min · "+b.restSeconds+" s rest · effort "+b.effort+"/10";
}
