import {format,type Entry,type Stored} from "./model";

// MET values from the 2024 Adult Compendium. Each selectable activity names its reference condition.
export const workoutTypes = [
  {name:"Walking · Moderate pace",met:3.8,aliases:["walk","walking","outdoor walk","indoor walk"]},
  {name:"Walking · Slow pace",met:2.8,aliases:["slow walk"]},
  {name:"Walking · Brisk pace",met:4.8,aliases:["brisk walk","brisk walking"]},
  {name:"Jogging",met:7.5,aliases:["jog"]},
  {name:"Running · Self-selected pace",met:10.5,aliases:["run","running","outdoor run","indoor run"]},
  {name:"Boxing · Punching bag",met:5.8,aliases:["boxing","bag work","heavy bag"]},
  {name:"Boxing · Sparring",met:7.8,aliases:["sparring"]},
  {name:"Cycling · Easy pace",met:4.3,aliases:["easy cycling"]},
  {name:"Cycling · Moderate pace",met:7,aliases:["cycling","biking","bicycling"]},
  {name:"Cycling · Vigorous pace",met:9,aliases:[]},
  {name:"Strength training · Multiple exercises",met:3.5,aliases:["strength training","weight training","weightlifting","functional strength training"]},
  {name:"Strength training · Vigorous lifting",met:6,aliases:[]},
  {name:"Swimming · Easy freestyle laps",met:5.8,aliases:["swimming","swim"]},
  {name:"Swimming · Fast freestyle laps",met:9.8,aliases:[]},
  {name:"Yoga · General practice",met:2.3,aliases:["yoga"]},
  {name:"Yoga · Surya Namaskar",met:3.5,aliases:["surya namaskar","sun salutations"]},
  {name:"HIIT · Moderate effort",met:7,aliases:["hiit","high intensity interval training"]},
  {name:"HIIT · Vigorous intervals",met:11,aliases:[]},
  {name:"Stair climbing",met:6.8,aliases:["stairs","stair climbing"]},
  {name:"Home exercise · General",met:3.8,aliases:["home exercise"]},
  {name:"Gym workout · General",met:5.5,aliases:["gym workout"]},
];
export function matchWorkout(name:string){
  const key=name.trim().toLowerCase();
  return workoutTypes.find(w=>w.name.toLowerCase()===key||w.aliases.includes(key));
}
export type Workout=Extract<Entry,{kind:"exercise"}>;

// A weigh-in takes precedence over a profile entered on the same day.
export function workoutWeight(rows:Stored[],day:string){
  let kg:number|undefined,latest="",weighIn=false;
  for(const r of rows){
    if(r.day>day||r.day<latest)continue;
    const value=r.kind==="weight"?r.data.kg:r.kind==="target"?r.data.profile?.weight:undefined;
    if(value===undefined||(r.day===latest&&weighIn&&r.kind!=="weight"))continue;
    kg=value;latest=r.day;weighIn=r.kind==="weight";
  }
  return kg;
}
export function estimateActive(met:number,kg:number,minutes:number){
  return Math.round((met-1)*3.5*kg*minutes/200);
}
export function workoutBurn(w:Workout,rows:Stored[]){
  const {health,basis,name,minutes}=w.data;
  if(health?.activeKcal!=null)return {kcal:health.activeKcal,source:"Apple Health"};
  const type=matchWorkout(basis?.activity??name);
  if(!type)return {reason:"Choose a similar activity to estimate burn"};
  const kg=basis?.kg??workoutWeight(rows,w.day);
  if(!kg)return {reason:"Add body weight to estimate burn"};
  return {kcal:estimateActive(type.met,kg,minutes),source:"estimate"};
}
export function burnLabel(w:Workout,rows:Stored[]){
  const result=workoutBurn(w,rows);
  if(result.kcal==null)return result.reason;
  return result.source==="estimate"?"≈ "+format(result.kcal)+" active kcal":format(result.kcal)+" active kcal · Apple Health";
}
