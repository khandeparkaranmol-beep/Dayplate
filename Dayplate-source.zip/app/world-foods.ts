import type { LibraryFood } from "./regional";
import { makePanelFood, type NutritionPanel } from "./nutrition";
import dishes from "./data/world-dishes.json";
import menus from "./data/us-menus.json";

export const worldGroups = ["US restaurants", "US drinks", "Dallas / DFW", "Indo-Chinese", "Tofu", "Ghanaian", "American"];
const dishIcons: Record<string,string> = {"Indo-Chinese":"🥢", Tofu:"🥢", American:"🍽️", Ghanaian:"🍲", "Dallas / DFW":"🌮"};
const regionalDishes: LibraryFood[] = dishes.map(d => {
  const panel: NutritionPanel = {
    amount:d.basis, unit:"g", kind:d.reference ? "Food composition reference" : "Recipe estimate",
    values:d.values as Record<string,number>, detail:d.detail, source:d.source, links:d.links, checked:"2026-11-25"
  };
  return {...makePanelFood(d.name,d.serving,d.grams,panel,dishIcons[d.group]), group:d.group,tags:d.tags,aliases:d.aliases};
});

type MenuUnit = "g" | "ml" | "serving" | "slices";
type Series = {brand:string, source:string, year:string, archive:boolean, dallas:boolean};
type MenuRow = [string,string,number,MenuUnit,number,number,number,string,(number|null)[],boolean,Record<string,"<"|"≤"|">"|"≥">?];
const dataset = menus as unknown as {series:Series[], nutrients:string[], notes:string[], categories:string[], rows:MenuRow[]};
export function usBrandFilter(group:string, brand:string) {return group+" / "+brand;}
const chainAliases:Record<string,string>={"McDonald's":"McD", "Kung Fu Tea":"boba shop bubble tea", "Feng Cha":"boba shop bubble tea", "7 Leaves Cafe":"boba shop bubble tea", "KFC":"Kentucky Fried Chicken", "Dunkin'":"Dunkin Donuts", "Torchy's Tacos":"Tex Mex"};
const brands: Record<string,Set<string>> = {"US restaurants":new Set(), "US drinks":new Set()};

const menuFoods: LibraryFood[] = dataset.rows.map(([title,portion,size,unit,seriesId,noteId,categoryId,sourceRow,fields,drink,bounds]) => {
  const {brand,source,year,archive,dallas} = dataset.series[seriesId];
  const group = "US restaurants", tags = [usBrandFilter(group,brand)];
  brands[group].add(brand);
  if (drink) {
    tags.push("US drinks",usBrandFilter("US drinks",brand));
    brands["US drinks"].add(brand);
  }
  if (dallas) tags.push("Dallas / DFW");
  const category = dataset.categories[categoryId], values:Record<string,number>={};
  fields.forEach((v,i)=>{if(v!==null)values[dataset.nutrients[i]]=v;});
  const compiled=source.includes("printsheetlab.com");
  const label = year+(archive?" archive":compiled?" snapshot":" guide");
  const panel:NutritionPanel = {kind:"Restaurant menu",brand,source,checked:"2026-11-25",unit,amount:size,values,
    ...(bounds?{bounds}:{}),variant:category,
    detail:[archive?"US MenuStat archive, "+year+". Recipes and availability may have changed.":compiled?"US menu snapshot, "+year+".":"US restaurant nutrition guide, "+year+".",category,sourceRow&&"Source record "+sourceRow+".",dataset.notes[noteId]].filter(Boolean).join(" ")};
  return {...makePanelFood(brand+" (US) · "+title,portion+" · "+label,size,panel,drink?"🥤":"🍽️"),
    group,tags,aliases:[chainAliases[brand],category,drink?"beverage drink":"",dallas?"Dallas Fort Worth DFW Texas":""].join(" ")};
});
export const usBrands = Object.fromEntries(Object.entries(brands).map(([group,items])=>[group,[...items].sort((a,b)=>a.localeCompare(b))]));
export const worldFoods = [...regionalDishes,...menuFoods];
