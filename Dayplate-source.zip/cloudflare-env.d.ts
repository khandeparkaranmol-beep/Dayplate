declare namespace Cloudflare {
  interface Env {
    DAYPLATE_SHARING_HANDLE?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
