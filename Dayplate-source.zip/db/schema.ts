import { sqliteTable, text, integer, primaryKey } from "drizzle-orm/sqlite-core";

export const records = sqliteTable("journal_records", {
  owner: text("owner").notNull(),
  id: text("id").notNull(),
  kind: text("kind").notNull(),
  day: text("day").notNull(),
  data: text("data").notNull(),
  revision: integer("revision").notNull().default(1),
}, table => [primaryKey({ columns: [table.owner, table.id] })]);

export const profiles = sqliteTable("profiles", {
  owner:text("owner").primaryKey(), handle:text("handle").notNull().unique()
});
export const friendships = sqliteTable("friendships", {
  pair:text("pair").primaryKey(), sender:text("sender").notNull(), recipient:text("recipient").notNull(), accepted:integer("accepted").notNull().default(0)
});
export const challenges = sqliteTable("challenges", {
  id:text("id").primaryKey(), pair:text("pair").notNull(), sender:text("sender").notNull(), recipient:text("recipient").notNull(),
  metric:text("metric").notNull(), length:integer("length").notNull().default(7), start:text("start"), finish:text("finish"), created:text("created").notNull()
});
export const shares = sqliteTable("friend_posts", {
  id:text("id").primaryKey(), author:text("author").notNull(), content:text("content").notNull(), created:text("created").notNull()
});
export const cheers = sqliteTable("cheers",{
  post:text("post").notNull(),author:text("author").notNull()
},t=>[primaryKey({columns:[t.post,t.author]})]);

export const googleSessions=sqliteTable("google_sessions",{
 digest:text("digest").primaryKey(),owner:text("owner").notNull(),expires:integer("expires").notNull()
});
