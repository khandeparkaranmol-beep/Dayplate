CREATE TABLE `challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`pair` text NOT NULL,
	`sender` text NOT NULL,
	`recipient` text NOT NULL,
	`metric` text NOT NULL,
	`start` text,
	`finish` text,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `cheers` (
	`post` text NOT NULL,
	`author` text NOT NULL,
	PRIMARY KEY(`post`, `author`)
);
--> statement-breakpoint
CREATE TABLE `friendships` (
	`pair` text PRIMARY KEY NOT NULL,
	`sender` text NOT NULL,
	`recipient` text NOT NULL,
	`accepted` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`owner` text PRIMARY KEY NOT NULL,
	`handle` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `profiles_handle_unique` ON `profiles` (`handle`);--> statement-breakpoint
CREATE TABLE `friend_posts` (
	`id` text PRIMARY KEY NOT NULL,
	`author` text NOT NULL,
	`content` text NOT NULL,
	`created` text NOT NULL
);
