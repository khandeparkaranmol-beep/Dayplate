CREATE TABLE `google_sessions` (
	`digest` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`expires` integer NOT NULL
);
