CREATE TABLE `buddy_plans` (
	`id` text PRIMARY KEY NOT NULL,
	`pair` text NOT NULL,
	`sender` text NOT NULL,
	`recipient` text NOT NULL,
	`created` text NOT NULL,
	`sender_plan` text NOT NULL,
	`recipient_plan` text
);
