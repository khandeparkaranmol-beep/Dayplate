ALTER TABLE `friend_posts` ADD `snapshot` text;--> statement-breakpoint
ALTER TABLE `friend_posts` ADD `audience` text;