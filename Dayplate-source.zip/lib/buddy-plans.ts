import {ownerOnlyFood} from "../app/private-foods";
import {z} from "zod";
import {foodSchema,meals,validDate,type Food} from "../app/model";
import {nutrients,scaled} from "../app/nutrition";
import {localClock,plusDays,type BuddyView,type Goal,type Member,type SharedItem} from "../app/buddy";

import {workoutTypes} from "../app/workout-energy";
const handle=z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{2,23}$/);
const id=z.string().uuid();
const zone=z.string().min(1).max(80).refine(s=>{try{localClock(s);return true}catch{return false}});
const movement=z.object({activity:z.string().refine(s=>workoutTypes.some(w=>w.name===s)),minutes:z.number().int().min(1).max(1440)});
const settings=z.object({movement:movement.optional(),goal:z.string().trim().min(1).max(100),target:z.number().int().min(1).max(7),
  sharing:z.enum(["completion","progress","selected"]),zone,reminder:z.union([z.literal(""),z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/)])});
const pick=z.discriminatedUnion("kind",[
  z.object({kind:z.literal("meal"),meal:z.enum(meals),day:validDate}),
  z.object({kind:z.literal("workout"),id:z.string().min(1).max(80)})
]);
const actions=z.discriminatedUnion("action",[
  z.object({action:z.literal("buddyInvite"),id,peer:handle,settings}),
  z.object({action:z.literal("buddyJoin"),id,settings}),
  z.object({action:z.literal("buddyCheck"),id,day:validDate,pick:pick.optional()}),
  z.object({action:z.literal("buddyUndo"),id,day:validDate}),
  z.object({action:z.literal("buddySettings"),id,sharing:settings.shape.sharing,reminder:settings.shape.reminder}),
  z.object({action:z.literal("buddyMove"),id,day:validDate}),
  z.object({action:z.literal("buddyAsk"),id,on:z.boolean()}),
  z.object({action:z.literal("buddyCheer"),id,on:z.boolean()}),
  z.object({action:z.literal("buddyEnd"),id})
]);
type Row={id:string;pair:string;sender:string;recipient:string;sender_plan:string;recipient_plan:string|null};
const visible=" FROM buddy_plans b JOIN friendships f ON f.pair=b.pair AND f.accepted=1 WHERE (b.sender=? OR b.recipient=?)";
const response=(value:unknown,status=200)=>Response.json(value,{status,headers:{"Cache-Control":"private, no-store"}});
const changed=(n:number)=>n?response({saved:true}):response({error:"This plan changed. Refresh Friends and try again."},409);
function member(goal:Goal):Member{return {...goal,goal:goal.movement?goal.movement.activity+" · "+goal.movement.minutes+" min":goal.goal,start:"",next:"",checks:{},ask:false,cheer:false}}
function begin(m:Member,now:Date):Member{
  const start=plusDays(localClock(m.zone,now).day,1);
  return {...m,start,next:start};
}
export async function buddyViews(db:D1Database,me:string,now:Date,specialHandle=""){
  const {results}=await db.prepare("SELECT b.*"+visible+" ORDER BY b.created DESC").bind(me,me).all<Row>();
  return results.map((row):BuddyView=>{
    const sender:Member=JSON.parse(row.sender_plan),recipient:Member|null=row.recipient_plan&&JSON.parse(row.recipient_plan);
    const incoming=row.recipient===me,mine=incoming?recipient:sender,other=incoming?sender:recipient;
    const local=mine?localClock(mine.zone,now):null;
    const entries=Object.values(other?.checks||{});
    const peer=incoming?row.sender:row.recipient;
    const visibleItems=entries.flatMap((item):SharedItem[]=>{
      if(!item)return [];
      if(item.kind==="workout")return [item];
      // Earlier attachments lack provenance for custom foods. Keep the check-in itself.
      if(peer===specialHandle&&!("foodPrivacy" in item&&item.foodPrivacy===1))return [];
      return [{kind:"meal",id:item.id,name:item.name,lines:item.lines}];
    });
    return {id:row.id,peer,incoming,active:!!recipient,mine,
      today:local?.day||"",clock:local?.clock||"",other:other?{
        goal:other.goal,...(other.movement?{movement:other.movement}:{}),target:other.target,sharing:other.sharing,complete:entries.length>=other.target,
        ...(other.sharing==="completion"?{}:{count:entries.length}),items:other.sharing==="selected"?visibleItems:[],
        ask:other.ask,cheer:other.cheer}:null};
  });
}
async function selectedItem(db:D1Database,owner:string,selection:z.infer<typeof pick>,day:string,protectedOwner:boolean):Promise<SharedItem|null>{
  if(selection.kind==="workout"){
    const row=await db.prepare("SELECT data FROM journal_records WHERE owner=? AND id=? AND day=? AND kind='exercise'").bind(owner,selection.id,day).first<{data:string}>();
    if(!row)return null;
    const {name,minutes}=JSON.parse(row.data);
    return {kind:"workout",name,minutes};
  }
  if(selection.day!==day)return null;
  const {results}=await db.prepare("SELECT data FROM journal_records WHERE owner=? AND day=? AND kind='food' AND json_extract(data,'$.meal')=? ORDER BY rowid").bind(owner,day,selection.meal).all<{data:string}>();
  const foods=results.map(row=>JSON.parse(row.data) as {food:Food;quantity:number;custom?:boolean})
    .filter(data=>!protectedOwner||!ownerOnlyFood(data.food,data.custom));
  if(!foods.length||foods.length>40)return null;
  const lines=foods.map(({food:raw,quantity})=>{
    const f=foodSchema.parse(raw);
    const sugar=scaled(f,"sugar");
    // Send the portion and its nutrients only. Personal notes, label metadata and diary IDs stay private.
    const food:Food={name:f.name,serving:f.serving,grams:f.grams,ml:f.ml,icon:f.icon,kcal:f.kcal,p:f.p,c:f.c,f:f.f,
      sugar:sugar&&!sugar.relation?sugar.value:null};
    if(f.panel){const {kind,amount,unit,values,bounds}=f.panel;food.panel={kind,amount,unit,values:Object.fromEntries(Object.entries(values).filter(([k])=>Object.hasOwn(nutrients,k))),bounds:bounds?Object.fromEntries(Object.entries(bounds).filter(([k])=>Object.hasOwn(nutrients,k))):undefined}}
    return {food,quantity};
  });
  return {id:crypto.randomUUID(),kind:"meal",name:selection.meal,lines,...(protectedOwner?{foodPrivacy:1}:{})};
}
export async function buddyAction(db:D1Database,owner:string,me:string,body:unknown,now:Date,protectedOwner=false){
  const parsed=actions.safeParse(body);
  if(!parsed.success)return response({error:"Check your plan, local time and sharing choice."},400);
  const a=parsed.data;
  if(a.action==="buddyInvite"){
    if(a.peer===me)return response({error:"Choose a friend."},400);
    const pair=[me,a.peer].sort().join(":");
    const r=await db.prepare("INSERT OR IGNORE INTO buddy_plans(id,pair,sender,recipient,created,sender_plan) SELECT ?,?,?,?,?,? FROM friendships WHERE pair=? AND accepted=1 AND NOT EXISTS(SELECT 1 FROM buddy_plans WHERE pair=? AND recipient_plan IS NULL)").bind(a.id,pair,me,a.peer,now.toISOString(),JSON.stringify(member(a.settings)),pair,pair).run();
    return changed(r.meta.changes);
  }
  const row=await db.prepare("SELECT b.*"+visible+" AND b.id=?").bind(me,me,a.id).first<Row>();
  if(!row)return changed(0);
  if(a.action==="buddyEnd")return changed((await db.prepare("DELETE FROM buddy_plans WHERE id=? AND (sender=? OR recipient=?)").bind(a.id,me,me).run()).meta.changes);
  if(a.action==="buddyJoin"){
    if(row.recipient!==me||row.recipient_plan)return changed(0);
    const sender=begin(JSON.parse(row.sender_plan),now),recipient=begin(member(a.settings),now);
    return changed((await db.prepare("UPDATE buddy_plans SET sender_plan=?,recipient_plan=? WHERE id=? AND recipient=? AND recipient_plan IS NULL").bind(JSON.stringify(sender),JSON.stringify(recipient),a.id,me).run()).meta.changes);
  }
  if(!row.recipient_plan)return changed(0);
  const column=row.sender===me?"sender_plan":"recipient_plan";
  const before=row[column]!,m:Member=JSON.parse(before);
  const today=localClock(m.zone,now).day,end=plusDays(m.start,6);
  if(a.action==="buddySettings"){m.sharing=a.sharing;m.reminder=a.reminder;if(m.sharing!=="selected")for(const day of Object.keys(m.checks))m.checks[day]=null}
  else if(a.action==="buddyAsk")m.ask=a.on;
  else if(a.action==="buddyCheer")m.cheer=a.on;
  else {
    if(today<m.start||today>end)return response({error:"Check-ins open during your seven local dates."},409);
    if(a.action==="buddyMove"){
      if(a.day<=today||a.day>end)return response({error:"Choose a later date within your week."},400);
      m.next=a.day;
    }else {
      if(a.day!==today)return response({error:"Your local day changed. Refresh and check in again."},409);
      if(a.action==="buddyUndo"){delete m.checks[today];m.next=today}
      else{
        if(today in m.checks)return response({saved:true});
        if(Object.keys(m.checks).length>=m.target)return changed(0);
        let item:SharedItem|null=null;
        if(a.pick){
          if(m.sharing!=="selected")return response({error:"Your sharing choice keeps diary entries private."},400);
          item=await selectedItem(db,owner,a.pick,today,protectedOwner);
          if(!item)return response({error:"Choose one of your meals or workouts from today. Meals can contain up to 40 items."},400);
        }
        m.checks[today]=item;m.next=plusDays(today,1);
      }
    }
  }
  return changed((await db.prepare("UPDATE buddy_plans SET "+column+"=? WHERE id=? AND "+column+"=? AND recipient_plan IS NOT NULL")
    .bind(JSON.stringify(m),a.id,before).run()).meta.changes);
}
