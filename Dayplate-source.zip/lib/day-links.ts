import {z} from "zod";
import {validDate,type Stored} from "../app/model";
import {loggedPreview} from "./logged-updates";
import {digest} from "./google-token";
import {daySnapshot,type DayLinkMode,type SnapshotLinkInfo} from "../app/day-snapshot";

const key=z.string().regex(/^[a-f0-9]{64}$/);
const actions=z.discriminatedUnion("action",[
  z.object({action:z.literal("read"),token:key}).strict(),
  z.object({action:z.literal("preview"),day:validDate}).strict(),
  z.object({action:z.literal("create"),day:validDate,token:key,fingerprint:key.nullable(),mode:z.enum(["snapshot","live"]).default("snapshot")}).strict(),
  z.object({action:z.literal("stop"),id:key}).strict()
]);
const reply=(value:unknown,status=200)=>Response.json(value,{status,headers:{"Cache-Control":"private, no-store","Referrer-Policy":"no-referrer","X-Robots-Tag":"noindex, nofollow"}});
const fail=(error:string,status:number)=>reply({error},status);
const week=7*86400000;
type ReadRow={mode:DayLinkMode;day:string;snapshot:string;created:number;expires:number;
  id:string|null;kind:"food"|"exercise"|"activity"|null;data:string|null;revision:number|null};

async function readDayLink(db:D1Database,token:string,now:number){
  // One read binds the shareable records to an active grant, its owner and its original journal date.
  const {results}=await db.prepare(`SELECT l.mode,l.day,l.snapshot,l.created,l.expires,j.id,j.kind,j.data,j.revision
    FROM day_links l LEFT JOIN journal_records j ON l.mode='live' AND j.owner=l.owner AND j.day=l.day
      AND j.kind IN ('food','exercise','activity')
    WHERE l.digest=? AND l.expires>? ORDER BY j.id`).bind(await digest(token),now).all<ReadRow>();
  const grant=results[0];
  if(!grant)return fail("This link has expired or its owner stopped sharing it.",404);
  const {created,expires,mode,day}=grant;
  if(mode==="snapshot")return reply({mode,created,expires,snapshot:JSON.parse(grant.snapshot)});
  const entries=results.flatMap(r=>r.id&&r.kind&&r.data?[{id:r.id,kind:r.kind,day,data:JSON.parse(r.data),revision:r.revision} as Stored]:[]);
  const snapshot=daySnapshot(entries,day)??{kind:"day",day,title:"Day snapshot",stats:[],items:[],groups:[]};
  return reply({mode,created,expires,asOf:now,snapshot});
}

export async function dayLink(db:D1Database,owner:string|null,body:unknown,now=Date.now()){
  const parsed=actions.safeParse(body);
  if(!parsed.success)return fail("Invalid day link request.",400);
  const a=parsed.data;
  if(a.action==="read")return readDayLink(db,a.token,now);
  if(!owner)return fail("Sign in to manage day links.",401);
  if(a.action==="stop"){
    await db.prepare("UPDATE day_links SET expires=0,snapshot='' WHERE digest=? AND owner=?").bind(a.id,owner).run();
    return reply({saved:true});
  }
  if(a.action==="preview"){
    const preview=await loggedPreview(db,owner,{kind:"day",day:a.day});
    await db.prepare("UPDATE day_links SET snapshot='' WHERE owner=? AND expires<=? AND snapshot<>''").bind(owner,now).run();
    const active=await db.prepare("SELECT digest AS id,mode,created,expires FROM day_links WHERE owner=? AND day=? AND expires>? ORDER BY created DESC").bind(owner,a.day,now).all<SnapshotLinkInfo>();
    return reply({snapshot:preview?.snapshot??null,fingerprint:preview?.fingerprint??null,links:active.results});
  }
  const id=await digest(a.token),{mode,day}=a, fingerprint=a.fingerprint??"";
  async function savedResponse(){
    const prior=await db.prepare("SELECT owner,day,fingerprint,mode,created,expires FROM day_links WHERE digest=?").bind(id)
      .first<{owner:string;day:string;fingerprint:string;mode:DayLinkMode;created:number;expires:number}>();
    if(!prior)return null;
    if(prior.owner!==owner||prior.day!==day||prior.mode!==mode||prior.fingerprint!==fingerprint||prior.expires<=now)
      return fail("Create a fresh link for this day.",409);
    return reply({id,mode,created:prior.created,expires:prior.expires});
  }
  const existing=await savedResponse();
  if(existing)return existing;
  const preview=await loggedPreview(db,owner,{kind:"day",day});
  if((preview?.fingerprint??null)!==a.fingerprint||(!preview&&mode==="snapshot"))
    return fail("Your diary changed. Review the day before creating a link.",409);
  const expires=now+week;
  const saved=await db.prepare("INSERT OR IGNORE INTO day_links(digest,owner,day,fingerprint,snapshot,mode,created,expires) VALUES(?,?,?,?,?,?,?,?)")
    .bind(id,owner,day,fingerprint,mode==="snapshot"?JSON.stringify(preview!.snapshot):"",mode,now,expires).run();
  if(!saved.meta.changes)return await savedResponse()??fail("Create a fresh link for this day.",409);
  return reply({id,mode,created:now,expires});
}
