import {hasSharedContent,visibilitySchema} from "../app/snapshot-visibility";
import {z} from "zod";
import {validDate,type Stored} from "../app/model";
import {loggedPreview} from "./logged-updates";
import {digest} from "./google-token";
import {daySnapshot,type DayLinkMode,type SnapshotLinkInfo} from "../app/day-snapshot";

const key=z.string().regex(/^[a-f0-9]{64}$/);
const actions=z.discriminatedUnion("action",[
  z.object({action:z.literal("read"),token:key}).strict(),
  z.object({action:z.literal("preview"),day:validDate,visibility:visibilitySchema.optional()}).strict(),
  z.object({action:z.literal("create"),day:validDate,visibility:visibilitySchema.optional(),token:key,fingerprint:key.nullable(),mode:z.enum(["snapshot","live"]).default("snapshot")}).strict(),
  z.object({action:z.literal("stop"),id:key}).strict()
]);
const reply=(value:unknown,status=200)=>Response.json(value,{status,headers:{"Cache-Control":"private, no-store","Referrer-Policy":"no-referrer","X-Robots-Tag":"noindex, nofollow"}});
const fail=(error:string,status:number)=>reply({error},status);
const week=7*86400000;
type StoredMode=DayLinkMode|"selected-live";
const linkMode=(mode:StoredMode):DayLinkMode=>mode==="selected-live"?"live":mode;
type ReadRow={mode:StoredMode;day:string;snapshot:string;created:number;expires:number;
  id:string|null;kind:"food"|"exercise"|"activity"|null;data:string|null;revision:number|null};

async function readDayLink(db:D1Database,token:string,now:number){
  // One read binds the shareable records to an active grant, its owner and its original journal date.
  const {results}=await db.prepare(`SELECT l.mode,l.day,l.snapshot,l.created,l.expires,j.id,j.kind,j.data,j.revision
    FROM day_links l LEFT JOIN journal_records j ON l.mode IN ('live','selected-live') AND j.owner=l.owner AND j.day=l.day
      AND j.kind IN ('food','exercise','activity')
    WHERE l.digest=? AND l.expires>? ORDER BY j.id`).bind(await digest(token),now).all<ReadRow>();
  const grant=results[0];
  if(!grant)return fail("This link has expired or its owner stopped sharing it.",404);
  const {created,expires,mode,day}=grant;
  if(mode==="snapshot")return reply({mode,created,expires,snapshot:JSON.parse(grant.snapshot)});
  if(mode!=="live"&&mode!=="selected-live")return fail("This link is unavailable.",404);
  let visibility;
  if(mode==="selected-live"){
    // Legacy readers never join diary rows for this mode. Invalid settings also fail closed.
    try{visibility=visibilitySchema.parse(JSON.parse(grant.snapshot))}catch{return fail("This link is unavailable.",404)}
  }
  const entries=results.flatMap(r=>r.id&&r.kind&&r.data?[{id:r.id,kind:r.kind,day,data:JSON.parse(r.data),revision:r.revision} as Stored]:[]);
  const snapshot=daySnapshot(entries,day,visibility)??{kind:"day",day,title:"Day snapshot",stats:[],items:[],groups:[]};
  return reply({mode:linkMode(mode),created,expires,asOf:now,snapshot});
}

export async function dayLink(db:D1Database,owner:string|null,body:unknown,now=Date.now()){
  const parsed=actions.safeParse(body);
  if(!parsed.success)return fail("Invalid day link request.",400);
  const a=parsed.data;
  if(a.action==="read")return readDayLink(db,a.token,now);
  if(!owner)return fail("Sign in to manage day links.",401);
  if(a.action==="stop"){
    await db.prepare("UPDATE day_links SET expires=0,snapshot='' WHERE digest=? AND owner=?").bind(a.id,owner).run();
    return reply({saved:true});
  }
  const pick={kind:"day" as const,day:a.day,...(a.visibility?{visibility:a.visibility}:{})};
  if(a.action==="preview"){
    const preview=await loggedPreview(db,owner,pick);
    await db.prepare("UPDATE day_links SET snapshot='' WHERE owner=? AND expires<=? AND snapshot<>''").bind(owner,now).run();
    const active=await db.prepare("SELECT digest AS id,CASE WHEN mode='selected-live' THEN 'live' ELSE mode END AS mode,created,expires FROM day_links WHERE owner=? AND day=? AND expires>? ORDER BY created DESC").bind(owner,a.day,now).all<SnapshotLinkInfo>();
    return reply({snapshot:preview?.snapshot??null,fingerprint:preview?.fingerprint??null,links:active.results});
  }
  if(a.visibility&&!hasSharedContent(a.visibility))return fail("Choose at least one thing to share.",400);
  const id=await digest(a.token),{mode,day}=a;
  const storedMode=mode==="live"&&a.visibility?"selected-live":mode;
  const fingerprint=a.visibility?await digest(JSON.stringify([a.fingerprint,a.visibility])):a.fingerprint??"";
  async function savedResponse(){
    const prior=await db.prepare("SELECT owner,day,fingerprint,mode,created,expires FROM day_links WHERE digest=?").bind(id)
      .first<{owner:string;day:string;fingerprint:string;mode:StoredMode;created:number;expires:number}>();
    if(!prior)return null;
    if(prior.owner!==owner||prior.day!==day||prior.mode!==storedMode||prior.fingerprint!==fingerprint||prior.expires<=now)
      return fail("Create a fresh link for this day.",409);
    return reply({id,mode,created:prior.created,expires:prior.expires});
  }
  const existing=await savedResponse();
  if(existing)return existing;
  const preview=await loggedPreview(db,owner,pick);
  if((preview?.fingerprint??null)!==a.fingerprint||(!preview&&mode==="snapshot"))
    return fail("Your diary changed. Review the day before creating a link.",409);
  const expires=now+week;
  const payload=mode==="snapshot"?JSON.stringify(preview!.snapshot):a.visibility?JSON.stringify(a.visibility):"";
  const saved=await db.prepare("INSERT OR IGNORE INTO day_links(digest,owner,day,fingerprint,snapshot,mode,created,expires) VALUES(?,?,?,?,?,?,?,?)")
    .bind(id,owner,day,fingerprint,payload,storedMode,now,expires).run();
  if(!saved.meta.changes)return await savedResponse()??fail("Create a fresh link for this day.",409);
  return reply({id,mode,created:now,expires});
}
