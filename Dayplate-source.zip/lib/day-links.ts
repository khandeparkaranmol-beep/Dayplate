import {z} from "zod";
import {validDate} from "../app/model";
import {loggedPreview} from "./logged-updates";
import {digest} from "./google-token";
import type {SnapshotLinkInfo} from "../app/day-snapshot";

const key=z.string().regex(/^[a-f0-9]{64}$/);
const actions=z.discriminatedUnion("action",[
  z.object({action:z.literal("read"),token:key}).strict(),
  z.object({action:z.literal("preview"),day:validDate}).strict(),
  z.object({action:z.literal("create"),day:validDate,token:key,fingerprint:key}).strict(),
  z.object({action:z.literal("stop"),id:key}).strict()
]);
const reply=(value:unknown,status=200)=>Response.json(value,{status,headers:{"Cache-Control":"private, no-store","Referrer-Policy":"no-referrer","X-Robots-Tag":"noindex, nofollow"}});
const fail=(error:string,status:number)=>reply({error},status);
const week=7*86400000;

export async function dayLink(db:D1Database,owner:string|null,body:unknown,now=Date.now()){
  const parsed=actions.safeParse(body);
  if(!parsed.success)return fail("Invalid snapshot request.",400);
  const a=parsed.data;
  if(a.action==="read"){
    const row=await db.prepare("SELECT snapshot,created,expires FROM day_links WHERE digest=? AND expires>?").bind(await digest(a.token),now).first<{snapshot:string;created:number;expires:number}>();
    return row?reply({...row,snapshot:JSON.parse(row.snapshot)}):fail("This link has expired or its owner stopped sharing it.",404);
  }
  if(!owner)return fail("Sign in to manage day links.",401);
  if(a.action==="stop"){
    await db.prepare("UPDATE day_links SET expires=0,snapshot='' WHERE digest=? AND owner=?").bind(a.id,owner).run();
    return reply({saved:true});
  }
  async function existing(id:string){
    return db.prepare("SELECT owner,day,fingerprint,created,expires FROM day_links WHERE digest=?").bind(id).first<{owner:string;day:string;fingerprint:string;created:number;expires:number}>();
  }
  const id=a.action==="create"?await digest(a.token):"";
  if(a.action==="create"){
    const old=await existing(id);
    if(old)return old.owner===owner&&old.day===a.day&&old.fingerprint===a.fingerprint&&old.expires>now?
      reply({id,created:old.created,expires:old.expires}):fail("Create a fresh link for this snapshot.",409);
  }
  const preview=await loggedPreview(db,owner,{kind:"day",day:a.day});
  if(a.action==="preview"){
    await db.prepare("UPDATE day_links SET snapshot='' WHERE owner=? AND expires<=? AND snapshot<>''").bind(owner,now).run();
    const active=await db.prepare("SELECT digest AS id,created,expires FROM day_links WHERE owner=? AND day=? AND expires>? ORDER BY created DESC").bind(owner,a.day,now).all<SnapshotLinkInfo>();
    return reply({snapshot:preview?.snapshot??null,fingerprint:preview?.fingerprint??null,links:active.results});
  }
  if(!preview||preview.fingerprint!==a.fingerprint)return fail("Your diary changed. Review the new snapshot before creating a link.",409);
  const expires=now+week;
  const saved=await db.prepare("INSERT OR IGNORE INTO day_links(digest,owner,day,fingerprint,snapshot,created,expires) VALUES(?,?,?,?,?,?,?)")
    .bind(id,owner,a.day,a.fingerprint,JSON.stringify(preview.snapshot),now,expires).run();
  if(!saved.meta.changes){
    const old=await existing(id);
    if(old?.owner===owner&&old.day===a.day&&old.fingerprint===a.fingerprint&&old.expires>now)return reply({id,created:old.created,expires:old.expires});
    return fail("Create a fresh link for this snapshot.",409);
  }
  return reply({id,created:now,expires});
}
