import {buddyAction,buddyViews} from "./buddy-plans";
import {reminderDue} from "../app/buddy";
import {z} from "zod";
import {type Circle,type Contest,type Match} from "../app/social";
import {validDate,shift} from "../app/model";
const handle=z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{2,23}$/);
const id=z.string().uuid();
const action=z.discriminatedUnion("action",[
 z.object({action:z.literal("profile"),handle}),
 z.object({action:z.literal("friend"),peer:handle}),
 z.object({action:z.literal("acceptFriend"),peer:handle}),
 z.object({action:z.literal("removeFriend"),peer:handle}),
 z.object({action:z.literal("challenge"),peer:handle,id,metric:z.enum(["steps","workout","journal","minutes"]),length:z.union([z.literal(3),z.literal(7),z.literal(14)])}),
 z.object({action:z.literal("acceptMatch"),id,day:validDate}),
 z.object({action:z.literal("dropMatch"),id}),
 z.object({action:z.literal("post"),id,content:z.string().trim().min(1).max(240)}),
 z.object({action:z.literal("removePost"),id}),
 z.object({action:z.literal("cheer"),id,on:z.boolean()})
]);
const ok=(value:unknown,status=200)=>Response.json(value,{status,headers:{"Cache-Control":"private, no-store"}});
const fail=(message:string,status=400)=>ok({error:message},status);
const pair=(a:string,b:string)=>[a,b].sort().join(":");
const visiblePost="(p.author=? OR EXISTS (SELECT 1 FROM friendships f WHERE f.accepted=1 AND ((f.sender=? AND f.recipient=p.author) OR (f.recipient=? AND f.sender=p.author))))";
type ScoreRow={id:string,handle:string,day:string,kind:string,entryId:string,revision:number,amount:number|null,signature:string|null};
function score(rows:ScoreRow[],metric:Contest){
 const days=new Map<string,ScoreRow[]>();
 for(const r of rows){const a=days.get(r.day)||[];a.push(r);days.set(r.day,a)}
 let total=0,count=0;
 for(const day of days.values()){
  if(metric==="journal"){
   const food=day.filter(r=>r.kind==="food");
   const sig=JSON.stringify(food.map(r=>[r.entryId,r.revision]).sort((a,b)=>String(a[0]).localeCompare(String(b[0]))));
   if(food.length&&day.some(r=>r.signature===sig)){total++;count++}
  }else{const values=day.filter(r=>r.amount!=null);if(values.length){count++;total+=metric==="workout"?1:values.reduce((s,r)=>s+Number(r.amount),0)}}
 }
 return {total:Math.round(total),days:count};
}
export async function social(db:D1Database,owner:string|null,body?:unknown,now=new Date(),remindersOnly=false){
 if(!owner)return fail("Sign in to use Friends.",401);
 const profile=await db.prepare("SELECT handle FROM profiles WHERE owner=?").bind(owner).first<{handle:string}>();
 const me=profile?.handle;
 if(remindersOnly)return ok(me?(await buddyViews(db,me,now)).filter(reminderDue).map(p=>p.mine!.goal):[]);
 if(body===undefined){
  const result:Circle={handle:me||null,people:[],matches:[],posts:[],plans:[]};if(!me)return ok(result);
  const f=await db.prepare("SELECT sender,recipient,accepted FROM friendships WHERE sender=? OR recipient=? ORDER BY accepted DESC,sender").bind(me,me).all<{sender:string,recipient:string,accepted:number}>();
  result.people=f.results.map(r=>({peer:r.sender===me?r.recipient:r.sender,state:r.accepted?"friend":r.sender===me?"sent":"received"}));
  const matches=await db.prepare("SELECT c.* FROM challenges c JOIN friendships f ON f.pair=c.pair AND f.accepted=1 WHERE c.sender=? OR c.recipient=? ORDER BY c.created DESC LIMIT 100").bind(me,me).all<{id:string,sender:string,recipient:string,metric:Contest,length:number,start:string|null,finish:string|null}>();
  const raw=await db.prepare(`SELECT c.id,p.handle,j.day,j.kind,j.id AS entryId,j.revision,CASE WHEN j.kind='activity' THEN json_extract(j.data,'$.steps') WHEN j.kind='exercise' THEN json_extract(j.data,'$.minutes') END AS amount,CASE WHEN j.kind='review' THEN json_extract(j.data,'$.signature') END AS signature
   FROM (SELECT * FROM challenges WHERE sender=? OR recipient=? ORDER BY created DESC LIMIT 100) c
   JOIN friendships f ON f.pair=c.pair AND f.accepted=1 JOIN profiles p ON p.handle IN(c.sender,c.recipient)
   JOIN journal_records j ON j.owner=p.owner AND j.day BETWEEN c.start AND c.finish
   WHERE (c.metric='steps' AND j.kind='activity') OR (c.metric IN('workout','minutes') AND j.kind='exercise') OR (c.metric='journal' AND j.kind IN('food','review'))`).bind(me,me).all<ScoreRow>();
  const byMatch=new Map<string,ScoreRow[]>();for(const r of raw.results){const list=byMatch.get(r.id)||[];list.push(r);byMatch.set(r.id,list)}
  result.matches=matches.results.map(c=>{const rows=byMatch.get(c.id)||[],mine=score(rows.filter(r=>r.handle===me),c.metric),other=score(rows.filter(r=>r.handle!==me),c.metric);
   return {id:c.id,peer:c.sender===me?c.recipient:c.sender,incoming:c.recipient===me,metric:c.metric,length:c.length,start:c.start,finish:c.finish,mine:mine.total,theirs:other.total,mineDays:mine.days,theirDays:other.days} satisfies Match});
  // Only the author sees the total. Other viewers get their own reaction even on older clients.
  const posts=await db.prepare(`SELECT p.id,p.author,p.content,p.created,
    (SELECT count(*) FROM cheers h WHERE h.post=p.id AND (p.author=? OR h.author=?)) AS cheers,
    EXISTS(SELECT 1 FROM cheers h WHERE h.post=p.id AND h.author=?) AS cheered
    FROM friend_posts p WHERE ${visiblePost} ORDER BY p.created DESC LIMIT 50`).bind(me,me,me,me,me,me).all<Circle["posts"][number]>();
  result.plans=await buddyViews(db,me,now);result.posts=posts.results;return ok(result);
 }
 if(body&&typeof body==="object"&&"action" in body&&typeof body.action==="string"&&body.action.startsWith("buddy"))return me?buddyAction(db,owner,me,body,now):fail("Choose a username first.",409);
 const parsed=action.safeParse(body);if(!parsed.success)return fail("Check the username or invitation details.");
 const a=parsed.data,today=now.toISOString().slice(0,10);
 if(a.action==="profile"){
  if(me===a.handle)return ok({saved:true});
  if(me)return fail("Your username is already set.",409);
  const r=await db.prepare("INSERT OR IGNORE INTO profiles(owner,handle) VALUES(?,?)").bind(owner,a.handle).run();
  return r.meta.changes?ok({saved:true}):fail("That username is taken. Try another.",409);
 }
 if(!me)return fail("Choose a username first.",409);
 if("peer" in a&&a.peer===me)return fail("Enter your friend’s username.");
 let changed=0;
 if(a.action==="friend"){
  const r=await db.prepare("INSERT OR IGNORE INTO friendships(pair,sender,recipient) SELECT ?,?,handle FROM profiles WHERE handle=? AND (SELECT count(*) FROM friendships WHERE sender=? AND accepted=0)<50").bind(pair(me,a.peer),me,a.peer,me).run();changed=r.meta.changes;
  if(!changed)return fail("No new request was sent. Check the username and your pending requests.",409);
 }else if(a.action==="acceptFriend"){
  changed=(await db.prepare("UPDATE friendships SET accepted=1 WHERE sender=? AND recipient=? AND accepted=0").bind(a.peer,me).run()).meta.changes;
 }else if(a.action==="removeFriend"){
  const key=pair(me,a.peer);
  const r=await db.batch([db.prepare("DELETE FROM buddy_plans WHERE pair=?").bind(key),db.prepare("DELETE FROM challenges WHERE pair=?").bind(key),db.prepare("DELETE FROM friendships WHERE pair=?").bind(key)]);
  changed=r[2].meta.changes;
 }else if(a.action==="challenge"){
  const key=pair(me,a.peer);
  const r=await db.prepare("INSERT OR IGNORE INTO challenges(id,pair,sender,recipient,metric,length,created) SELECT ?,?,?,?,?,?,? FROM friendships WHERE pair=? AND accepted=1 AND NOT EXISTS(SELECT 1 FROM challenges WHERE pair=? AND metric=? AND (finish IS NULL OR finish>=?))").bind(a.id,key,me,a.peer,a.metric,a.length,now.toISOString(),key,key,a.metric,today).run();changed=r.meta.changes;
 }else if(a.action==="acceptMatch"){
  if(a.day<shift(today,-1)||a.day>shift(today,1))return fail("Check your device date.");
  changed=(await db.prepare("UPDATE challenges SET start=?,finish=date(?,printf('+%d days',length-1)) WHERE id=? AND recipient=? AND start IS NULL AND EXISTS(SELECT 1 FROM friendships f WHERE f.pair=challenges.pair AND accepted=1)").bind(a.day,a.day,a.id,me).run()).meta.changes;
 }else if(a.action==="dropMatch"){
  changed=(await db.prepare("DELETE FROM challenges WHERE id=? AND (sender=? OR recipient=?)").bind(a.id,me,me).run()).meta.changes;
 }else if(a.action==="post"){
  changed=(await db.prepare("INSERT OR IGNORE INTO friend_posts(id,author,content,created) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM friendships WHERE accepted=1 AND (sender=? OR recipient=?))").bind(a.id,me,a.content,now.toISOString(),me,me).run()).meta.changes;
 }else if(a.action==="removePost"){
  const r=await db.batch([db.prepare("DELETE FROM cheers WHERE post=? AND EXISTS(SELECT 1 FROM friend_posts WHERE id=? AND author=?)").bind(a.id,a.id,me),db.prepare("DELETE FROM friend_posts WHERE id=? AND author=?").bind(a.id,me)]);changed=r[1].meta.changes;
 }else if(a.action==="cheer"){
  if(a.on)await db.prepare(`INSERT OR IGNORE INTO cheers(post,author) SELECT p.id,? FROM friend_posts p WHERE p.id=? AND ${visiblePost}`).bind(me,a.id,me,me,me).run();
  else await db.prepare("DELETE FROM cheers WHERE post=? AND author=?").bind(a.id,me);return ok({saved:true});
 }
 return changed?ok({saved:true}):fail("This invitation or update is no longer available. Check your list.",409);
}
