type GoogleKey=JsonWebKey & {kid:string};
let cache:{keys:GoogleKey[],expires:number}|undefined;
async function keys(){
 if(cache&&cache.expires>Date.now())return cache.keys;
 const res=await fetch("https://www.googleapis.com/oauth2/v3/certs");
 if(!res.ok)throw Error("Google signing keys are unavailable.");
 const {keys}=await res.json() as {keys:GoogleKey[]};
 if(!Array.isArray(keys))throw Error("Google signing keys are unavailable.");
 const age=Number(res.headers.get("cache-control")?.match(/max-age=(\d+)/)?.[1]??300);
 cache={keys,expires:Date.now()+Math.max(1,Math.min(age,3600))*1000};return keys;
}
function bytes(v:string){return Uint8Array.from(atob(v.replaceAll("-","+").replaceAll("_","/")),c=>c.charCodeAt(0))}
function json(v:string){return JSON.parse(new TextDecoder().decode(bytes(v)))}
export async function verifyGoogle(token:string,client:string,nonce:string,keyset:()=>Promise<GoogleKey[]>=keys){
 const parts=token.split(".");if(parts.length!==3||token.length>10000||!client||!nonce)throw Error("Invalid sign-in.");
 const h=json(parts[0]),p=json(parts[1]),now=Math.floor(Date.now()/1000);
 if(h.alg!=="RS256"||typeof h.kid!=="string"||!["https://accounts.google.com","accounts.google.com"].includes(p.iss)||p.aud!==client||p.azp&&p.azp!==client||typeof p.exp!=="number"||p.exp<=now||typeof p.iat!=="number"||p.iat>now+60||p.nonce!==nonce||typeof p.sub!=="string"||!/^\d{1,64}$/.test(p.sub))throw Error("Invalid sign-in.");
 const jwk=(await keyset()).find(k=>k.kid===h.kid&&k.kty==="RSA"&&(!k.alg||k.alg==="RS256")&&(!k.use||k.use==="sig"));
 if(!jwk)throw Error("Signing key unavailable. Try signing in again.");
 const key=await crypto.subtle.importKey("jwk",jwk,{name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"},false,["verify"]);
 if(!await crypto.subtle.verify("RSASSA-PKCS1-v1_5",key,bytes(parts[2]),new TextEncoder().encode(parts[0]+"."+parts[1])))throw Error("Invalid sign-in.");
 return "google:"+p.sub;
}
export function randomToken(){return Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,"0")).join("")}
export async function digest(token:string){return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(token))),b=>b.toString(16).padStart(2,"0")).join("")}
