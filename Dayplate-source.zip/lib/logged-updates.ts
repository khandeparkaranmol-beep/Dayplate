import {daySnapshot,dayText} from "../app/day-snapshot";
import {z} from "zod";
import {meals, validDate, type Stored} from "../app/model";
import {compactNumber, dayNutrient, formatDaily} from "../app/nutrition";
import {workoutBurn,strengthDetail} from "../app/workout-energy";
import type {LoggedUpdate, LogPick, UpdatePreview} from "../app/logged-update";

export const logPickSchema=z.union([
  z.object({kind:z.literal("day"),day:validDate}).strict(),
  z.object({kind:z.literal("meal"),day:validDate,meal:z.enum(meals)}).strict(),
  z.object({kind:z.enum(["food","exercise","steps"]),day:validDate,id:z.string().min(1).max(80)}).strict()
]);

type SourceRow={id:string; kind:Stored["kind"]; data:string; revision:number};
export async function loggedPreview(db:D1Database,owner:string,pick:LogPick):Promise<UpdatePreview|null>{
  const base="SELECT id,kind,data,revision FROM journal_records WHERE owner=? AND day=?";
  const query=pick.kind==="day"
    ?db.prepare(base+" AND kind IN ('food','exercise','activity') ORDER BY id").bind(owner,pick.day)
    :pick.kind==="meal"
    ?db.prepare(base+" AND kind='food' AND json_extract(data,'$.meal')=? ORDER BY id").bind(owner,pick.day,pick.meal)
    :db.prepare(base+" AND id=? AND kind=?").bind(owner,pick.day,pick.id,pick.kind==="steps"?"activity":pick.kind);
  const {results}=await query.all<SourceRow>();
  if(!results.length)return null;
  const rows=results.map(r=>({...r,day:pick.day,data:JSON.parse(r.data)} as Stored));
  const first=rows[0];
  let snapshot:LoggedUpdate={kind:pick.kind,day:pick.day,title:"",items:[],stats:[]};
  if(pick.kind==="day"){
    const day=daySnapshot(rows,pick.day);
    if(!day)return null;
    snapshot=day;
  }else if(first.kind==="food"){
    const foods=rows.filter(r=>r.kind==="food");
    snapshot.title=pick.kind==="meal"?pick.meal:first.data.food.name;
    snapshot.items=foods.map(({data:{food,quantity,meal}})=>({
      name:pick.kind==="food"?meal:food.name,
      portion:(quantity===1?"":compactNumber(quantity)+" × ")+food.serving
    }));
    const estimated=foods.some(r=>r.data.food.panel?.kind==="Recipe estimate")?"≈ ":"";
    const kcal=foods.reduce((total,r)=>total+r.data.food.kcal*r.data.quantity,0);
    snapshot.stats.push({label:"Energy",value:estimated+Math.round(kcal)+" kcal"});
    for(const [key,label] of [["p","Protein"],["sugar","Total sugar"]]){
      const n=dayNutrient(foods,key);
      if(!n.missing)snapshot.stats.push({label,value:estimated+formatDaily(n)+" g"});
    }
  }else if(first.kind==="exercise"){
    snapshot.title=first.data.name;
    snapshot.stats.push({label:"Duration",value:compactNumber(first.data.minutes)+" min"});
    if(first.data.strength)snapshot.items.push({name:"Lift details",portion:strengthDetail(first.data)});
    // Use energy saved with this workout. No body measurements enter the snapshot.
    const burn=workoutBurn(first,[]);
    if(burn.kcal!=null)snapshot.stats.push({label:"Active energy",value:(burn.source==="estimate"?"≈ ":"")+Math.round(burn.kcal)+" kcal"});
  }else if(first.kind==="activity"&&first.data.steps!=null){
    snapshot.title="Daily steps";
    snapshot.stats.push({label:"Steps",value:compactNumber(first.data.steps)});
  }else return null;
  const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(JSON.stringify([pick,snapshot,rows.map(r=>[r.id,r.revision])])));
  return {snapshot,fingerprint:Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("")};
}

export function updateText(s:LoggedUpdate){
  if(s.kind==="day")return dayText(s);
  return [s.title+" · "+s.day,...s.items.map(i=>i.name+" · "+i.portion),...s.stats.map(v=>v.label+" "+v.value)].join("\n");
}
