export const pagesOrigin = "https://khandeparkaranmol-beep.github.io";
export const journalURL = pagesOrigin + "/Dayplate/";
export const apiOrigin = "https://dayplate-anmol.anmolskhandeparkar24.chatgpt.site";
