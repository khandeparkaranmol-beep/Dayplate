export const deviceLifetime = 90 * 86400000;
export const accessLifetime = 86400000;
export const deviceAlgorithm = {name:"ECDSA",namedCurve:"P-256"};
export const proofAlgorithm = {name:"ECDSA",hash:"SHA-256"};

export const hex = (buffer:ArrayBuffer) => Array.from(new Uint8Array(buffer),b=>b.toString(16).padStart(2,"0")).join("");
export const unhex = (value:string) => Uint8Array.from(value.match(/../g)??[],b=>parseInt(b,16));
export const deviceMessage = (nonce:string) => new TextEncoder().encode("Dayplate remembered browser v1\n"+nonce);
