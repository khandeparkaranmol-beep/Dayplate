import type {LoggedUpdate} from "../app/logged-update";
import {fullVisibility,type SnapshotVisibility} from "../app/snapshot-visibility";

export async function hasSharingControls(db:D1Database,owner:string,handle:string){
  if(!handle)return false;
  return !!await db.prepare("SELECT 1 AS allowed FROM profiles WHERE owner=? AND handle=?").bind(owner,handle).first();
}

// Previously released clients send the default selection even for an ordinary full-day link.
export function customSelection(v?:SnapshotVisibility){
  return !!v&&(v.hiddenIds.length>0||fullVisibility.sections.some(s=>!v.sections.includes(s))||
    fullVisibility.fields.some(f=>!v.fields.includes(f)));
}

export function storeSnapshot(snapshot:LoggedUpdate,protectedOwner:boolean){
  return JSON.stringify(protectedOwner?{foodPrivacy:1,snapshot}:snapshot);
}
export function readSnapshot(raw:string,protectLegacy:boolean):LoggedUpdate|null{
  const stored=JSON.parse(raw);
  if(stored.foodPrivacy===1)return stored.snapshot;
  const s=stored as LoggedUpdate;
  if(!protectLegacy||s.kind==="steps"||s.kind==="exercise")return s;
  // Old frozen food totals have no ingredient-level provenance. Keep their movement portion.
  if(s.kind!=="day")return null;
  const stats=s.stats.filter(x=>["Steps","Daily active energy","Workout time"].includes(x.label));
  const groups=s.groups?.filter(g=>g.title==="Workouts")??[];
  return stats.length||groups.length?{...s,items:[],stats,groups}:null;
}
