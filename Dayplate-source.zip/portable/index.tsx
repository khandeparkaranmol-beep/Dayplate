import { createRoot } from "react-dom/client";
import PersonalJournal from "../app/PersonalJournal";

createRoot(document.getElementById("root")!).render(<PersonalJournal/>);
