import {createRoot} from "react-dom/client";
import {useState,useEffect,useCallback} from "react";
import OnlineJournal from "../app/OnlineJournal";
import GoogleSignIn from "../app/GoogleSignIn";
import {currentSession} from "../app/pages-api";
function Pages() {
  const [online,setOnline] = useState(()=>Boolean(currentSession()));
  const signedIn = useCallback(()=>setOnline(true),[]);
  useEffect(()=>{
    const signout=()=>setOnline(false);
    window.addEventListener("dayplate-signout",signout);
    return ()=>window.removeEventListener("dayplate-signout",signout);
  },[]);
  if (online) return <OnlineJournal/>;
  return <main className="login-page"><div className="login-brand"><img src="/favicon.svg" alt=""/>Dayplate</div><div className="login-layout"><section><h1>Your personal<br/>health journal.</h1><p>Sign in with Google to keep your diary across devices and challenge friends.</p><GoogleSignIn signedIn={signedIn}/><a href="./Dayplate.html" className="account-link offline-choice">Use offline</a><small>Your offline diary stays in this browser.</small></section><div className="login-photo art-pohe" role="img" aria-label="Maharashtrian kanda pohe"/></div></main>;
}
createRoot(document.getElementById("root")!).render(<Pages/>);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(()=>{});
