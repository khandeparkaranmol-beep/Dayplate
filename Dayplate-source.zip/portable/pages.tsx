import {createRoot} from "react-dom/client";
import {useState,useEffect,useCallback} from "react";
import OnlineJournal from "../app/OnlineJournal";
import GoogleSignIn from "../app/GoogleSignIn";
import {observeAccount,openSession} from "../app/pages-api";
function Pages() {
  const [state,setState]=useState<"opening"|"online"|"login"|"retry">("opening");
  const [attempt,retry]=useState(0);
  const signedIn=useCallback(()=>setState("online"),[]);
  useEffect(()=>{
    let active=true;
    const restart=()=>{setState("opening");retry(n=>n+1)};
    const stopObserving=observeAccount(restart);
    const signout=()=>setState("login");
    const restored=(event:PageTransitionEvent)=>{if(event.persisted)restart()};
    window.addEventListener("pageshow",restored);
    window.addEventListener("dayplate-signout",signout);
    void openSession().then(online=>{if(active)setState(online?"online":"login")},()=>{if(active)setState("retry")});
    return ()=>{active=false;stopObserving();window.removeEventListener("pageshow",restored);window.removeEventListener("dayplate-signout",signout)};
  },[attempt]);
  if(state==="online")return <OnlineJournal/>;
  return <main className="login-page"><div className="login-brand"><img src="/favicon.svg" alt=""/>Dayplate</div><div className="login-layout"><section><h1>Your personal<br/>health journal.</h1>{state==="opening"?<p role="status">Opening your diary…</p>:state==="retry"?<><p role="status">Dayplate couldn’t reconnect to your account.</p><button className="light" onClick={()=>{setState("opening");retry(n=>n+1)}}>Try again</button></>:<><p>Sign in with Google to keep your diary across devices. Dayplate remembers this browser until you sign out or leave it unused for 90 days.</p><GoogleSignIn signedIn={signedIn}/></>}<a href="./Dayplate.html" className="account-link offline-choice">Use offline</a><small>Your offline diary stays in this browser.</small></section><div className="login-photo art-pohe" role="img" aria-label="Maharashtrian kanda pohe"/></div></main>;
}
createRoot(document.getElementById("root")!).render(<Pages/>);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(()=>{});
