import {useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {apiOrigin,journalURL} from "../lib/pages-origin";
import type {SharedDay} from "../app/day-snapshot";
import {DaySnapshotCard} from "../app/DaySnapshotCard";

function SharedSnapshot(){
  const [day,setDay]=useState<SharedDay|null>(null),[error,fail]=useState(""),[reload,refresh]=useState(0);
  useEffect(()=>{
    let active=true,epoch=0,timer:ReturnType<typeof setTimeout>|undefined;
    const abort=new AbortController();
    async function read(){
      const version=++epoch;
      if(timer)clearTimeout(timer);
      const token=location.hash.slice(1);
      setDay(null);fail("");
      if(!/^[a-f0-9]{64}$/.test(token)){fail("This link is incomplete. Ask the sender to copy it again.");return}
      try{
        const res=await fetch(apiOrigin+"/api/day-links",{method:"POST",credentials:"omit",cache:"no-store",referrerPolicy:"no-referrer",redirect:"error",signal:abort.signal,
          headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"read",token})});
        if(!res.ok)throw Error(res.status===404?"This link has expired or its owner stopped sharing it.":"Couldn’t load the snapshot. Check your connection and try again.");
        const info=await res.json() as SharedDay;
        if(!active||version!==epoch)return;
        setDay(info);timer=setTimeout(()=>{setDay(null);fail("This snapshot link has expired.")},Math.max(0,info.expires-Date.now()));
      }catch(e){if(active&&version===epoch)fail(e instanceof TypeError?"Couldn’t load the snapshot. Check your connection and try again.":(e as Error).message)}
    }
    const visible=()=>{if(!document.hidden)void read()};
    void read();window.addEventListener("hashchange",read);document.addEventListener("visibilitychange",visible);
    return ()=>{active=false;abort.abort();clearTimeout(timer);window.removeEventListener("hashchange",read);document.removeEventListener("visibilitychange",visible)};
  },[reload]);
  return <main className="public-snapshot"><a className="snapshot-brand" href={journalURL}><img src="/favicon.svg" alt=""/>Dayplate</a>
    <h1>Day snapshot</h1>{day?<><p>Shared {new Date(day.created).toLocaleString(undefined,{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})} · Read-only</p><DaySnapshotCard snapshot={day.snapshot}/></>:
    error?<div role="alert"><p>{error}</p>{error.includes("connection")&&<button onClick={()=>refresh(n=>n+1)}>Try again</button>}</div>:<p role="status">Opening snapshot…</p>}</main>;
}
createRoot(document.getElementById("root")!).render(<SharedSnapshot/>);
