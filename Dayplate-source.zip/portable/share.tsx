import {useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {apiOrigin,journalURL} from "../lib/pages-origin";
import type {SharedDay} from "../app/day-snapshot";
import {DaySnapshotCard} from "../app/DaySnapshotCard";

const stamp=(ms:number)=>new Date(ms).toLocaleString(undefined,{month:"short",day:"numeric",hour:"numeric",minute:"2-digit",timeZoneName:"short"});

function SharedSnapshot(){
  const [day,setDay]=useState<SharedDay|null>(null),[error,fail]=useState(""),[reload,refresh]=useState(0);
  useEffect(()=>{
    let controller:AbortController|undefined,expiry:ReturnType<typeof setTimeout>|undefined,poll:ReturnType<typeof setTimeout>|undefined;
    let live=false;
    function clearTimers(){clearTimeout(expiry);clearTimeout(poll)}
    function schedule(){
      clearTimeout(poll);
      if(live&&!document.hidden)poll=setTimeout(()=>void read(),60000);
    }
    async function read(reset=false){
      controller?.abort();
      const request=new AbortController();
      controller=request;
      clearTimeout(poll);
      if(reset){clearTimeout(expiry);setDay(null);live=false}
      fail("");
      const token=location.hash.slice(1);
      if(!/^[a-f0-9]{64}$/.test(token)){setDay(null);fail("This link is incomplete. Ask the sender to copy it again.");return}
      try{
        const res=await fetch(apiOrigin+"/api/day-links",{method:"POST",credentials:"omit",cache:"no-store",referrerPolicy:"no-referrer",redirect:"error",signal:request.signal,
          headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"read",token})});
        if(request.signal.aborted)return;
        if(res.status===404){
          clearTimers();live=false;setDay(null);fail("This link has expired or its owner stopped sharing it.");return;
        }
        if(!res.ok)throw Error("read");
        const info=await res.json() as SharedDay;
        if(request.signal.aborted)return;
        live=info.mode==="live";setDay(info);
        clearTimeout(expiry);
        expiry=setTimeout(()=>{
          controller?.abort();clearTimers();live=false;setDay(null);fail("This day link has expired.");
        },Math.max(0,info.expires-(info.asOf??Date.now())));
        schedule();
      }catch{
        if(request.signal.aborted)return;
        setDay(null);fail("Couldn’t load this day. Check your connection and try again.");schedule();
      }
    }
    const reset=()=>void read(true);
    const visibility=()=>{if(!document.hidden)reset();else clearTimeout(poll)};
    const restored=(e:PageTransitionEvent)=>{if(e.persisted)reset()};
    reset();window.addEventListener("hashchange",reset);window.addEventListener("pageshow",restored);
    document.addEventListener("visibilitychange",visibility);
    return ()=>{controller?.abort();clearTimers();window.removeEventListener("hashchange",reset);window.removeEventListener("pageshow",restored);document.removeEventListener("visibilitychange",visibility)};
  },[reload]);
  const live=day?.mode==="live";
  return <main className="public-snapshot"><a className="snapshot-brand" href={journalURL}><img src="/favicon.svg" alt=""/>Dayplate</a>
    <h1>{day?(live?"Day so far":"Day snapshot"):"Shared day"}</h1>
    {day?<>{live?<p className="live-caption"><span className="live-flag">Live</span> As of {stamp(day.asOf!)} · Read-only</p>:
    <p>Shared {stamp(day.created)} · Read-only</p>}<DaySnapshotCard snapshot={day.snapshot}/></>:
    error?<div role="alert"><p>{error}</p>{error.includes("connection")&&<button onClick={()=>refresh(n=>n+1)}>Try again</button>}</div>:<p role="status">Opening shared day…</p>}</main>;
}
createRoot(document.getElementById("root")!).render(<SharedSnapshot/>);
