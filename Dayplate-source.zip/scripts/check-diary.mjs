import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {build} from "esbuild";
import {createRequire} from "node:module";
const require=createRequire(import.meta.url);
const dir=await fs.mkdtemp(path.join(os.tmpdir(),"dayplate-check-"));
const read=async name=>JSON.parse(await fs.readFile(name,"utf8"));
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} differs from ${b}`);
try{
 const files=["catalog","model","nutrition","repeat","market-index","label-lookup","health-metrics","HealthPanel","NutrientTable","forms","views","RepeatMeal"];
 await build({entryPoints:files.map(n=>"app/"+n+(["HealthPanel","NutrientTable","forms","views","RepeatMeal"].includes(n)?".tsx":".ts")),outdir:dir,platform:"node",bundle:true,format:"cjs",jsx:"automatic",outExtension:{".js":".cjs"},external:["react","react/*"],plugins:[{name:"react",setup(b){b.onResolve({filter:/^react($|\/)/},args=>({path:require.resolve(args.path),external:true}))}}]});
 const get=n=>require(path.join(dir,n+".cjs"));
 const {catalog,searchFood,inGroup}=get("catalog"),{foodSchema,estimate,totals,completeDay,diarySignature}=get("model");
 const {scaled,dayNutrient,nutrients,makePanelFood,validBarcode,foodKey,formatDaily}=get("nutrition");
 const panels=await read("app/data/packaged.json"),audit=await read("app/data/panel-audit.json");
 const byName=new Map(catalog.map(f=>[f.name,f]));
 assert.equal(byName.size,catalog.length);assert.equal(catalog.length,205);assert.equal(panels.length,63);
 let totalFields=0,knownPotassium=0;
 for(const f of catalog){
  assert.ok(foodSchema.safeParse(f).success,f.name);assert.ok(f.panel.source,f.name);assert.equal(f.panel.unit==="ml",f.ml!==undefined);
  assert.ok(JSON.stringify(f).length<14500);assert.ok(f.grams||f.ml);assert.ok(f.kcal>=0);
  if(f.panel.barcode)assert.ok(validBarcode(f.panel.barcode),f.name+" barcode");
  if(scaled(f,"potassium"))knownPotassium++;
  for(const [k,v] of Object.entries(f.panel.values)){
    assert.ok(nutrients[k],f.name+" unrecognised nutrient "+k);
    assert.ok(Number.isFinite(v)&&v>=0,f.name);const expected=(f.ml||f.grams)*v/f.panel.amount;
    close(scaled(f,k,0.5).value,expected/2);totalFields++;
    if(["kcal","p","c","f"].includes(k)&&!f.panel.bounds?.[k])close(f[k],expected);
  }
  for(const key of Object.keys(f.panel.bounds||{}))assert.ok(f.panel.values[key]!==undefined);
 }
 for(const r of panels){assert.ok(audit[r.name]?.state!=="Excluded"&&audit[r.name],r.name);assert.deepEqual(byName.get(r.name).panel.values,r.panel.values)}
 assert.equal(Object.values(audit).filter(r=>r.state==="Excluded").length,1);
 const yoga=searchFood(catalog,"yoga bar");assert.equal(yoga.length,12);assert.equal(yoga.filter(f=>inGroup(f,"Indian market snacks")).length,9);
 const shake=yoga.find(f=>f.name.endsWith("Double Chocolate"));close(scaled(shake,"kcal",.5).value,105);close(scaled(shake,"p",.5).value,13);assert.equal(shake.ml,250);
 const whey=searchFood(catalog,"Amul plain whey")[0];close(scaled(whey,"kcal").value,126.08);close(scaled(whey,"p").value,24.992);
 const nutra=searchFood(catalog,"Nutrabay")[0];close(scaled(nutra,"potassium").value,155.1);
 const fruit=byName.get("Banana");close(scaled(fruit,"potassium").value,422.44);
 const oil=byName.get("Cooking oil");close(scaled(oil,"potassium").value,0);
 const unknown=panels.map(p=>byName.get(p.name)).find(f=>!scaled(f,"potassium"));
 const d="2026-11-24";
 const entry=(food,q=1,id=food.name)=>({id,day:d,kind:"food",revision:1,data:{food,quantity:q,meal:"Breakfast"}});
 const records=[entry(fruit),entry(unknown),entry(oil)];const partial=dayNutrient(records,"potassium");assert.equal(partial.known,2);assert.equal(partial.missing,1);close(partial.sum,422.44);
 const bounded=panels.find(p=>Object.keys(p.panel.bounds||{}).length);const k=Object.keys(bounded.panel.bounds)[0];assert.ok(scaled(byName.get(bounded.name),k).relation);
 assert.ok(formatDaily(dayNutrient([entry(byName.get(bounded.name))],k)).length);
 const legacy={name:"My food",serving:"1 bowl",grams:140,icon:"🍛",kcal:200,p:null,f:null,c:null};
 assert.ok(foodSchema.safeParse(legacy).success);assert.equal(scaled(legacy,"potassium"),null);
 assert.notEqual(foodKey(legacy),foodKey({...legacy,kcal:202}));
 const zero=byName.get("Coca-Cola Zero Sugar");close(scaled(zero,"kcal").value,0);
 const review={kind:"review",id:"review-"+d,revision:1,day:d,data:{signature:diarySignature(records,d)}};
 assert.ok(completeDay([...records,review],d));assert.ok(!completeDay([...records.slice(1),review],d));
 const profile={mode:"estimate",age:33,height:175,weight:82,sex:"male",factor:1.375,deficit:250};
 const e=estimate(profile);assert.equal(e.resting,1754);assert.equal(e.target,2160);
 const target={id:"target-2026-11-01",day:"2026-11-01",revision:1,kind:"target",data:{profile,calories:2160}};
 const weight=(day,kg)=>({id:"weight-"+day,day,kind:"weight",revision:1,data:{kg}});
 const history=[target,weight("2026-11-12",84),weight("2026-11-16",82),weight("2026-11-20",81),weight(d,80),{id:"measure-2026-11-22",day:"2026-11-22",kind:"measure",revision:1,data:{height:176,waist:87}},weight("2026-12-01",79)];
 const h=get("health-metrics").healthAt(history,d);close(h.week,80.5);close(h.weeklyChange,-2.5);close(h.bmi,80/1.76**2);assert.equal(h.height.value,176);
 const old={...entry(shake,.5),day:"2026-11-23"};
 const base=get("repeat").previousMeals([...records,old],d);assert.equal(base.length,1);assert.equal(base[0].entries[0].data.quantity,.5);
 const code="8908005144168",off=get("label-lookup").unpackBarcode(code,{code,quantity:"250 ml",nutriments:{proteins_100g:10.4,potassium_100g:.1551,potassium_unit:"mg",sodium_100g:0}});
 assert.equal(off.unit,"ml");assert.equal(off.values.potassium,"155.1");assert.equal(off.values.sodium,"0");assert.equal(off.values.b12,undefined);
 assert.equal(Object.keys(get("label-lookup").unpackBarcode(code,{code,data_quality_errors_tags:["energy-inconsistent"],nutriments:{proteins_100g:1}}).values).length,0);
 const csv='code,product_name,brands,open_error_flags,existence_status,pnns_groups_1,categories_tags\r\n'+code+',"Bar, ""brownie""",Yoga Bar,0,present_in_snapshot,sugary snacks,en:snacks\r\n'+code+',bad,B,1,present_in_snapshot,beverages,en:beverages\n';
 const index=get("market-index").parseDirectory(csv);assert.equal(index.length,1);assert.equal(index[0].name,'Bar, "brownie"');assert.equal(get("market-index").marketMatches(index,"yoga brownie").length,1);
 const render=require("react-dom/server").renderToStaticMarkup,el=require("react").createElement,baseProps={day:d,rows:history,close(){},save:async()=>true,busy:false,remove:async()=>true};
 assert.match(render(el(get("forms").FoodForm,{...baseProps,meal:"Snacks",foods:catalog,initial:shake,dayCalories:400,target:1850})),/Day after this portion/);
 assert.match(render(el(get("forms").TargetForm,{...baseProps,existing:target})),/176/);
 assert.match(render(el(get("HealthPanel").HealthPanel,{...baseProps})),/80.5 kg/);
 assert.match(render(el(get("views").LibraryView,{...baseProps,foods:catalog})),/Find a package/);
 assert.match(render(el(get("views").ProgressView,{...baseProps,rows:[...history,...records,review]})),/1 complete day/);
 assert.match(render(el(get("RepeatMeal").RepeatMeal,{...baseProps,rows:[old],meal:"Breakfast"})),/Double Chocolate/);
 console.log(JSON.stringify({foods:catalog.length,packaged:panels.length,nutrientFields:totalFields,foodsWithPotassium:knownPotassium,checks:"source units, scaling, printed bounds, missing data, diary portions, targets, trends, review validity, barcode conversions, CSV fixtures, repeat selection and rendered screens"}));
}finally{await fs.rm(dir,{recursive:true,force:true})}
