import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {build} from "esbuild";
import {createRequire} from "node:module";
const require=createRequire(import.meta.url);
const dir=await fs.mkdtemp(path.join(os.tmpdir(),"dayplate-check-"));
const read=async name=>JSON.parse(await fs.readFile(name,"utf8"));
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} differs from ${b}`);
try{
 const files=["workout-energy","health-import","catalog","model","nutrition","repeat","market-index","label-lookup","health-metrics","HealthPanel","NutrientTable","MealNutrients","forms","views","RepeatMeal"];
 await build({entryPoints:files.map(n=>"app/"+n+(["HealthPanel","NutrientTable","MealNutrients","forms","views","RepeatMeal"].includes(n)?".tsx":".ts")),outdir:dir,platform:"node",bundle:true,format:"cjs",jsx:"automatic",outExtension:{".js":".cjs"},external:["react","react/*"],plugins:[{name:"react",setup(b){b.onResolve({filter:/^react($|\/)/},args=>({path:require.resolve(args.path),external:true}))}}]});
 const get=n=>require(path.join(dir,n+".cjs"));
 const {catalog,searchFood,inGroup}=get("catalog"),{foodSchema,estimate,totals,completeDay,diarySignature}=get("model");
 const {amountOf,scaled,dayNutrient,nutrients,makePanelFood,validBarcode,foodKey,formatDaily}=get("nutrition");
 const panels=await read("app/data/packaged.json"),audit=await read("app/data/panel-audit.json");
 const byName=new Map(catalog.map(f=>[f.name,f]));
 assert.equal(byName.size,catalog.length);const world=await read("app/data/world-dishes.json"),us=await read("app/data/us-menus.json");
 assert.equal(world.length,144);
 assert.equal(catalog.length,1309+world.length+us.rows.length);
 const usFoods=catalog.filter(f=>inGroup(f,"US restaurants"));
 assert.equal(usFoods.length,us.rows.length);
 assert.ok(usFoods.length>13000);
 const bySource=(key)=>usFoods.filter(f=>inGroup(f,"US restaurants | "+key));
 assert.equal(bySource("archive").length+bySource("guide").length,usFoods.length);
 assert.ok(bySource("archive").every(f=>f.serving.includes("2018 archive")&&f.panel.source.includes("K4NYTR")));
 assert.ok(bySource("guide").every(f=>!f.panel.source.includes("K4NYTR")));
 assert.ok(searchFood(catalog.filter(f=>inGroup(f,"US restaurants / KFC")),"chicken").length);
 assert.ok(searchFood(catalog.filter(f=>inGroup(f,"Dallas / DFW")),"brisket").length);
 const tofu=byName.get("Chilli tofu (Indo-Chinese, dry)");
 assert.ok(inGroup(tofu,"Tofu")&&inGroup(tofu,"Indo-Chinese"));
 const kenkey=byName.get("Kenkey (Ga-style)");
 close(scaled(kenkey,"kcal").value,236.3);close(scaled(kenkey,"sodium").value,459);
 assert.equal(scaled(kenkey,"sugar"),null);
 for(const food of world)assert.ok(inGroup(byName.get(food.name),food.group));
 const milkTea=byName.get("Kung Fu Tea (US) · Kung Fu Black Milk Tea - Medium · 50% sweetness");
 close(scaled(milkTea,"kcal",.5).value,119);close(scaled(milkTea,"sugar",.5).value,10.5);
 assert.equal(scaled(milkTea,"potassium"),null);
 assert.ok(inGroup(milkTea,"US drinks / Kung Fu Tea | guide"));
 assert.ok(!inGroup(milkTea,"US drinks | archive"));
 const latte=searchFood(catalog.filter(f=>inGroup(f,"US drinks / Starbucks | guide")),"Caffè Latte Grande").find(f=>f.kcal===190);
 assert.ok(latte);close(scaled(latte,"p").value,13);
 assert.equal(panels.length,63);
 let totalFields=0,knownPotassium=0;
 for(const f of catalog){
  assert.ok(foodSchema.safeParse(f).success,f.name);assert.ok(f.panel.source,f.name);assert.equal(f.panel.unit==="ml",f.ml!==undefined);
  assert.ok(JSON.stringify(f).length<14500);assert.ok(amountOf(f)>0);assert.ok(f.kcal>=0);
  if(f.panel.barcode)assert.ok(validBarcode(f.panel.barcode),f.name+" barcode");
  if(scaled(f,"potassium"))knownPotassium++;
  for(const [k,v] of Object.entries(f.panel.values)){
    assert.ok(nutrients[k],f.name+" unrecognised nutrient "+k);
    assert.ok(Number.isFinite(v)&&v>=0,f.name);const expected=amountOf(f)*v/f.panel.amount;
    close(scaled(f,k,0.5).value,expected/2);totalFields++;
    if(["kcal","p","c","f"].includes(k)&&!f.panel.bounds?.[k])close(f[k],expected);
  }
  for(const key of Object.keys(f.panel.bounds||{}))assert.ok(f.panel.values[key]!==undefined);
 }
 const restaurants=catalog.filter(f=>inGroup(f,"Indian fast food"));
 const brandCounts={"McDonald’s":296,KFC:196,"Burger King":99,"Pizza Hut":297,"Domino’s":53,"Wow! Momo":17};
 assert.equal(restaurants.length,958);
 for(const [brand,count] of Object.entries(brandCounts)) {
   const items=restaurants.filter(f=>inGroup(f,brand));assert.equal(items.length,count,brand);
   for(const f of items){assert.equal(f.panel.kind,"Restaurant menu");assert.equal(f.panel.brand,brand);assert.equal(scaled(f,"potassium"),null)}
 }
 const findMenu=(query,brand)=>searchFood(restaurants.filter(f=>inGroup(f,brand)),query)[0];
 const burger=findMenu("McD Mumbai McAloo Tikki Burger","McDonald’s");
 close(burger.kcal,330);assert.equal(burger.grams,145);assert.equal(scaled(burger,"sugar"),null);
 const classic=byName.get("KFC · Classic Zinger Burger");assert.equal(classic.grams,225);close(classic.kcal,612);
 close(scaled(classic,"sugar",.5).value,7);close(scaled(classic,"p").value,27);close(scaled(classic,"sodium").value,752);
 const bucket=byName.get("KFC · 4 Pc Hot & Crispy Chicken");assert.equal(bucket.grams,440);close(bucket.kcal,1280);close(scaled(bucket,"kcal",.25).value,320);
 const slice=byName.get("Pizza Hut · Margherita Pizza (Personal)");close(slice.grams,62);close(slice.kcal,725.1/4);
 close(scaled(slice,"sodium",2).value,1430.8/2);assert.equal(scaled(slice,"sugar").relation,"<");
 const domino=byName.get("Domino’s · Margherita (regular, new hand tossed)");assert.equal(domino.grams,null);
 close(scaled(domino,"kcal",4).value,645.3);close(scaled(domino,"addedSugar",2).value,.4);
 const momo=findMenu("Veg Darjeeling Steam Momo","Wow! Momo");close(momo.kcal,187.98);assert.equal(momo.p,null);
 for(const r of panels){assert.ok(audit[r.name]?.state!=="Excluded"&&audit[r.name],r.name);assert.deepEqual(byName.get(r.name).panel.values,r.panel.values)}
 assert.equal(Object.values(audit).filter(r=>r.state==="Excluded").length,1);
 const additions=catalog.filter(f=>f.cuisine);
 const expectedMealCounts={"Indian breakfast":37,"Indian lunch":42,"Indian snacks":41};
 assert.equal(additions.length,120);
 for(const [group,count] of Object.entries(expectedMealCounts)){
   assert.equal(additions.filter(f=>f.group===group).length,count);
 }
 for(const f of additions){
   assert.ok(inGroup(f,f.group)&&inGroup(f,f.cuisine),f.name);
   assert.equal(f.panel.kind,"Recipe estimate");
   const values=f.panel.values;
   for(const key of ["kcal","p","c","f","sugar","addedSugar","fiber","potassium"])assert.ok(Number.isFinite(values[key]),f.name+" "+key);
   assert.ok(values.addedSugar<=values.sugar&&values.sugar<=values.c+.01,f.name+" sugar breakdown");
 }
 const tomatoOmelette=byName.get("Tomato omelette (besan, eggless)");
 for(const term of ["tomato omelet","besan chilla","टोमॅटो ऑम्लेट"]){
   assert.ok(searchFood(additions.filter(f=>inGroup(f,"Indian breakfast")),term).includes(tomatoOmelette),term);
 }
 assert.equal(tomatoOmelette.grams,120);close(tomatoOmelette.kcal,184.4);
 close(scaled(tomatoOmelette,"sugar",.5).value,5.5159/2);close(scaled(tomatoOmelette,"addedSugar").value,0);
 assert.equal(scaled(byName.get("Tilgul ladoo"),"fiber").relation,"<");
 for(const [name,group] of [["Rajma chawal","Indian lunch"],["Ragda pattice","Indian snacks"],["Ghavan","Maharashtrian"],["Filos (Goan banana pancakes)","Goan"],["Idli","Indian breakfast"],["Samosa","Indian snacks"]]){
   assert.ok(inGroup(byName.get(name),group),name);
 }
 const cafes=catalog.filter(f=>f.group==="Mumbai cafés"||f.group==="Goan cafés");
 assert.equal(cafes.length,26);
 assert.ok(cafes.filter(f=>f.group==="Goan cafés").every(f=>inGroup(f,"Goan")));
 for (const term of ["chicken pot pies","nutella brownies","prawn rissois","cafreal poee","akoori","bolinhas","egg chops"]) {
   assert.ok(searchFood(cafes,term).length,term);
 }
 const pie=byName.get("Chicken pot pie"),brownie=byName.get("Nutella brownie");
 assert.equal(pie.grams,240);assert.equal(brownie.grams,60);
 close(scaled(brownie,"kcal").value,(43*533+12*143+2*322+8*364)/100);
 assert.equal(scaled(brownie,"potassium"),null);
 const tiramisu=byName.get("Coffee Rasgulla Tiramisu (Bombay Sweet Shop)");
 assert.equal(tiramisu.grams,200);
 assert.ok(searchFood(cafes,"bombay sweet shop rasgulla tiramisu").includes(tiramisu));
 const recipeFoods=cafes.filter(f=>f.panel.kind==="Recipe estimate");
 assert.equal(recipeFoods.length,20);
 for(const f of recipeFoods){
   const {sugar,addedSugar}=f.panel.values;
   assert.ok(Number.isFinite(sugar)&&Number.isFinite(addedSugar)&&sugar>=addedSugar&&addedSugar>=0,f.name);
 }
 close(scaled(brownie,"sugar").value,(43*56.3+12*.37+2*.56+8*.27)/100);
 close(scaled(brownie,"addedSugar").value,43/100*56.3*19/21);
 close(scaled(tiramisu,"sugar").value,70*.4+55*.03+32*.0292+15*.998+5*.0435+2*.0175);
 close(scaled(tiramisu,"addedSugar").value,70*.4+15*.998);
 const menuCalories=[124,230,102,165,102,110];
 const menuNames=["Prawn balchão cheese tart","Goan egg chop","Goan chicken chilli turnover","Vegetable cutlet poi","Serradura","Date and dodol scroll"];
 for(const [index,name] of menuNames.entries()){
   const f=byName.get(name+" (Qmin Panaji)");
   assert.equal(f.panel.kind,"Café menu");assert.equal(f.panel.amount,100);assert.equal(f.grams,100);
   assert.equal(scaled(f,"sugar"),null);assert.equal(byName.get(name).grams,100);assert.ok(scaled(byName.get(name),"sugar"));
   close(scaled(f,"kcal",.75).value,menuCalories[index]*.75);
   for(const k of ["p","c","f","potassium"])assert.equal(scaled(f,k),null);
 }
 const yoga=searchFood(catalog,"yoga bar");assert.equal(yoga.length,12);assert.equal(yoga.filter(f=>inGroup(f,"Indian market snacks")).length,9);
 const shake=yoga.find(f=>f.name.endsWith("Double Chocolate"));close(scaled(shake,"kcal",.5).value,105);close(scaled(shake,"p",.5).value,13);assert.equal(shake.ml,250);
 const whey=searchFood(catalog,"Amul plain whey")[0];close(scaled(whey,"kcal").value,126.08);close(scaled(whey,"p").value,24.992);
 const nutra=searchFood(catalog,"Nutrabay")[0];close(scaled(nutra,"potassium").value,155.1);
 const fruit=byName.get("Banana");close(scaled(fruit,"potassium").value,422.44);
 const oil=byName.get("Cooking oil");close(scaled(oil,"potassium").value,0);
 const unknown=panels.map(p=>byName.get(p.name)).find(f=>!scaled(f,"potassium"));
 const d="2026-11-24";
 const entry=(food,q=1,id=food.name)=>({id,day:d,kind:"food",revision:1,data:{food,quantity:q,meal:"Breakfast"}});
 const {mealNutrientFact,defaultMealNutrients}=get("MealNutrients");
 assert.deepEqual(defaultMealNutrients,["p","sugar"]);
 const custom={name:"Test serving",serving:"1 bowl",grams:null,kcal:100,p:12,c:10,f:null,icon:"🍽️"};
 const half=entry({...custom,sugar:4},0.5),full=entry(custom),noSugar=entry({...custom,sugar:0});
 assert.deepEqual(mealNutrientFact([half,full],"p"),{value:"18 g",coverage:""});
 assert.deepEqual(mealNutrientFact([half,full],"sugar"),{value:"2 g",coverage:"from 1 of 2 foods"});
 assert.deepEqual(mealNutrientFact([full],"sugar"),{value:"Unlisted",coverage:""});
 assert.equal(mealNutrientFact([noSugar],"sugar").value,"0 g");
 assert.match(mealNutrientFact([entry(slice)],"sugar").value,/^</);
 assert.match(mealNutrientFact([entry(brownie)],"sugar").value,/^≈ /);
 const preference={id:"meal-nutrients",day:d,kind:"mealNutrients",data:{keys:["p","addedSugar","sodium"]}};
 assert.deepEqual(get("model").recordSchema.parse(preference),preference);
 for(const invalid of [["kcal"],["p","p"],["not-a-nutrient"],["constructor"]]){
   assert.equal(get("model").recordSchema.safeParse({...preference,data:{keys:invalid}}).success,false);
 }
 const schema=get("model").recordSchema;
 assert.ok(schema.safeParse({...preference,data:{keys:[]}}).success);
 for(const columns of [1,2,3])assert.ok(schema.safeParse({...preference,data:{...preference.data,columns}}).success);
 for(const columns of [0,1.5,4])assert.equal(schema.safeParse({...preference,data:{...preference.data,columns}}).success,false);
 const records=[entry(fruit),entry(unknown),entry(oil)];const partial=dayNutrient(records,"potassium");assert.equal(partial.known,2);assert.equal(partial.missing,1);close(partial.sum,422.44);
 const bounded=panels.find(p=>Object.keys(p.panel.bounds||{}).length);const k=Object.keys(bounded.panel.bounds)[0];assert.ok(scaled(byName.get(bounded.name),k).relation);
 assert.ok(formatDaily(dayNutrient([entry(byName.get(bounded.name))],k)).length);
 const legacy={name:"My food",serving:"1 bowl",grams:140,icon:"🍛",kcal:200,p:null,f:null,c:null};
 assert.ok(foodSchema.safeParse(legacy).success);assert.equal(scaled(legacy,"potassium"),null);
 assert.notEqual(foodKey(legacy),foodKey({...legacy,kcal:202}));
 const zero=byName.get("Coca-Cola Zero Sugar");close(scaled(zero,"kcal").value,0);
 const review={kind:"review",id:"review-"+d,revision:1,day:d,data:{signature:diarySignature(records,d)}};
 assert.ok(completeDay([...records,review],d));assert.ok(!completeDay([...records.slice(1),review],d));
 const profile={mode:"estimate",age:33,height:175,weight:82,sex:"male",factor:1.375,deficit:250};
 const e=estimate(profile);assert.equal(e.resting,1754);assert.equal(e.target,2160);
 const target={id:"target-2026-11-01",day:"2026-11-01",revision:1,kind:"target",data:{profile,calories:2160}};
 const weight=(day,kg)=>({id:"weight-"+day,day,kind:"weight",revision:1,data:{kg}});
 const history=[target,weight("2026-11-12",84),weight("2026-11-16",82),weight("2026-11-20",81),weight(d,80),{id:"measure-2026-11-22",day:"2026-11-22",kind:"measure",revision:1,data:{height:176,waist:87}},weight("2026-12-01",79)];
 const h=get("health-metrics").healthAt(history,d);close(h.week,80.5);close(h.weeklyChange,-2.5);close(h.bmi,80/1.76**2);assert.equal(h.height.value,176);
 const {workoutBurn,burnLabel}=get("workout-energy");
 const boxing={id:"boxing",kind:"exercise",day:d,data:{name:"Boxing",minutes:20}};
 assert.equal(workoutBurn(boxing,history).kcal,134);
 assert.equal(workoutBurn({...boxing,data:{...boxing.data,basis:{activity:"Boxing · Sparring",kg:70}}},history).kcal,167);
 assert.match(burnLabel(boxing,[weight("2090-01-01",80)]),/weight/);
 assert.match(burnLabel({...boxing,data:{name:"Custom session",minutes:20}},history),/similar activity/);
 const {parseHealth,initialSources,importRows}=get("health-import");
 const workoutXML=(type,time,legacy,inner)=>'<Workout workoutActivityType="HKWorkoutActivityType'+type+'" sourceName="Watch" startDate="'+d+' '+time+':00 +0530" endDate="'+d+' 18:55:00 +0530" duration="20" durationUnit="min" '+legacy+'>'+inner+'</Workout>';
 const xml='<HealthData>'+workoutXML("Boxing","15:00",'totalEnergyBurned="8" totalEnergyBurnedUnit="kcal"','<WorkoutStatistics type="HKQuantityTypeIdentifierActiveEnergyBurned" sum="418.4" unit="kJ"/><WorkoutStatistics type="HKQuantityTypeIdentifierBasalEnergyBurned" sum="25" unit="kcal"/>')+
 workoutXML("Running","15:30",'totalEnergyBurned="0" totalEnergyBurnedUnit="kcal"','')+
 workoutXML("Walking","16:00",'totalEnergyBurned="30" totalEnergyBurnedUnit="kcal"','')+
 workoutXML("Walking","16:30",'','')+'<WorkoutStatistics type="HKQuantityTypeIdentifierActiveEnergyBurned" sum="999" unit="kcal"/></HealthData>';
 const preview=await parseHealth(new File([xml],"export.xml"));
 const imported=await importRows(preview,initialSources(preview),d,d);
 assert.deepEqual(imported.map(r=>Math.round(r.data.health.activeKcal??-1)),[100,0,30,-1]);
 assert.equal(imported.filter(r=>r.kind==="activity").length,0);
 assert.deepEqual(await importRows(preview,initialSources(preview),d,d),imported);
 close(workoutBurn(imported[0],[]).kcal,100);
 assert.equal(workoutBurn(imported[1],history).kcal,0);
 assert.equal(workoutBurn(imported[3],history).kcal,78);
 assert.ok(imported.every(r=>get("model").recordSchema.safeParse(r).success));
 const old={...entry(shake,.5),day:"2026-11-23"};
 const base=get("repeat").previousMeals([...records,old],d);assert.equal(base.length,1);assert.equal(base[0].entries[0].data.quantity,.5);
 const code="8908005144168",off=get("label-lookup").unpackBarcode(code,{code,quantity:"250 ml",nutriments:{proteins_100g:10.4,potassium_100g:.1551,potassium_unit:"mg",sodium_100g:0}});
 assert.equal(off.unit,"ml");assert.equal(off.values.potassium,"155.1");assert.equal(off.values.sodium,"0");assert.equal(off.values.b12,undefined);
 assert.equal(Object.keys(get("label-lookup").unpackBarcode(code,{code,data_quality_errors_tags:["energy-inconsistent"],nutriments:{proteins_100g:1}}).values).length,0);
 const csv='code,product_name,brands,open_error_flags,existence_status,pnns_groups_1,categories_tags\r\n'+code+',"Bar, ""brownie""",Yoga Bar,0,present_in_snapshot,sugary snacks,en:snacks\r\n'+code+',bad,B,1,present_in_snapshot,beverages,en:beverages\n';
 const index=get("market-index").parseDirectory(csv);assert.equal(index.length,1);assert.equal(index[0].name,'Bar, "brownie"');assert.equal(get("market-index").marketMatches(index,"yoga brownie").length,1);
 const {refreshCafeSugars}=get("catalog");
 const previousBrownie=structuredClone(brownie);
 delete previousBrownie.panel.values.sugar;
 delete previousBrownie.panel.values.addedSugar;
 const olderEntry=entry(previousBrownie,.5);
 const updated=refreshCafeSugars(olderEntry);
 close(dayNutrient([updated],"sugar").sum,scaled(brownie,"sugar",.5).value);
 assert.equal(updated.data.quantity,.5);assert.equal(updated.data.food.kcal,previousBrownie.kcal);
 const customEntry={...olderEntry,data:{...olderEntry.data,custom:true}};
 assert.equal(refreshCafeSugars(customEntry),customEntry);
 const render=require("react-dom/server").renderToStaticMarkup,el=require("react").createElement,baseProps={day:d,rows:history,close(){},save:async()=>true,busy:false,remove:async()=>true};
 const mealComponent=get("MealNutrients");
 const chosen=["c","f","sodium","fiber"];
 const mealMarkup=render(el(mealComponent.MealNutrients,{foods:[half,full],keys:chosen,meal:"Lunch",columns:2}));
 assert.match(mealMarkup,/Lunch nutrient totals/);assert.match(mealMarkup,/repeat\(2,/);
 for(const label of ["Carbs","Fat","Sodium","Fiber"])assert.ok(mealMarkup.includes(">"+label+"<"));
 assert.ok(!mealMarkup.includes("Protein")&&!mealMarkup.includes("Total sugar"));
 assert.equal(render(el(mealComponent.MealNutrients,{foods:[half],keys:[],meal:"Lunch"})),"");
 assert.match(render(el(get("forms").FoodForm,{...baseProps,meal:"Snacks",foods:catalog,initial:shake,dayCalories:400,target:1850})),/Day after this portion/);
 const dessertForm=(food,quantity)=>render(el(get("forms").FoodForm,{...baseProps,meal:"Snacks",foods:catalog,edit:entry(food,quantity)}));
 assert.match(dessertForm(brownie,1),/24.3 g total sugar/);
 assert.match(dessertForm(tiramisu,.5),/22.9 g total sugar/);
 assert.match(dessertForm(tiramisu,.5),/21.5 g added sugar/);
 assert.match(render(el(get("forms").TargetForm,{...baseProps,existing:target})),/176/);
 assert.match(render(el(get("HealthPanel").HealthPanel,{...baseProps})),/80.5 kg/);
 assert.match(render(el(get("views").LibraryView,{...baseProps,foods:catalog})),/Find a package/);
 assert.match(render(el(get("views").ProgressView,{...baseProps,rows:[...history,...records,review]})),/1 complete day/);
 assert.match(render(el(get("RepeatMeal").RepeatMeal,{...baseProps,rows:[old],meal:"Breakfast"})),/Double Chocolate/);
 console.log(JSON.stringify({foods:catalog.length,packaged:panels.length,nutrientFields:totalFields,foodsWithPotassium:knownPotassium,checks:"source units, scaling, printed bounds, missing data, diary portions, targets, trends, review validity, barcode conversions, CSV fixtures, repeat selection and rendered screens"}));
}finally{await fs.rm(dir,{recursive:true,force:true})}
