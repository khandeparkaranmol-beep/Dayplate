import assert from "node:assert/strict";
import {DatabaseSync} from "node:sqlite";
import {mkdtemp,readFile,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {createRequire} from "node:module";
import {build} from "esbuild";

const dir=await mkdtemp(join(tmpdir(),"dayplate-health-")),db=new DatabaseSync(":memory:");
const require=createRequire(import.meta.url);
try {
  const fixtures={name:"journal-fixtures",setup(build){
    build.onResolve({filter:/^cloudflare:workers$|^\.\.\/\.\.\/account$/},a=>({namespace:"test",path:a.path}));
    build.onLoad({filter:/.*/,namespace:"test"},a=>({contents:a.path==="cloudflare:workers"?"export const env={DB:globalThis.testDiary}":"export const getDiaryUser=async()=>({userId:globalThis.testOwner})"}));
  }};
  for(const name of ["kitchen","model","nutrition","activity-records","week-story","api/journal/route"]){
    await build({entryPoints:["app/"+name+".ts"],outfile:join(dir,name.split("/").at(-1)+".cjs"),bundle:true,format:"cjs",platform:"node",plugins:[fixtures]});
  }
  await db.exec(await readFile("drizzle/0000_freezing_nemesis.sql","utf8"));
  globalThis.testDiary={prepare(sql){return {bind(...args){const s=db.prepare(sql);return {all:()=>({results:s.all(...args)}),run:()=>({meta:s.run(...args)})}}}},async batch(ops){
    db.exec("BEGIN");try{const r=ops.map(op=>op.run());db.exec("COMMIT");return r}catch(e){db.exec("ROLLBACK");throw e}
  }};
  const get=name=>require(join(dir,name+".cjs")),api=get("route");
  const owner="synthetic-a",day="2026-11-24";
  async function post(body,expected=200,as=owner){
    globalThis.testOwner=as;
    const response=await api.POST(new Request("https://test.local/api/journal",{method:"POST",headers:{origin:"https://khandeparkaranmol-beep.github.io"},body:JSON.stringify(body)}));
    assert.equal(response.status,expected,await response.text());
  }
  async function read(as=owner){globalThis.testOwner=as;return (await api.GET(new Request("https://test.local"))).json()}
  const {pantry,recipePortion,plateRows,toFoodEntries}=get("kitchen");
  const {foodSchema,diarySignature}=get("model"),{scaled}=get("nutrition");
  const {weekStory,breakfastNotes,hungerSummary}=get("week-story");
  for(const f of pantry)assert.ok(foodSchema.safeParse(f).success,f.name);
  const banana=pantry.find(f=>f.name==="Banana"),mango=pantry.find(f=>f.name==="Mango");
  const line=(food,quantity=1)=>({food,quantity,id:crypto.randomUUID()});
  const recipe={name:"Test kitchen",yieldCount:2,unit:"katori",lines:[line(banana),line(mango)]};
  const portion=recipePortion(recipe);
  assert.equal(portion.grams,null);assert.equal(portion.kcal,(banana.kcal+mango.kcal)/2);
  assert.equal(scaled(portion,"sugar",2).value,scaled(banana,"sugar").value+scaled(mango,"sugar").value);
  const unknown={...mango,p:null,c:null,f:null,panel:undefined,sugar:undefined};
  assert.equal(scaled(recipePortion({...recipe,lines:[line(banana),line(unknown)]}),"sugar"),null);
  const bounded={...banana,panel:{...banana.panel,bounds:{sugar:"<"}}};
  assert.equal(scaled(recipePortion({...recipe,lines:[line(bounded),line(mango)]}),"sugar").relation,"≤");
  const plan={id:crypto.randomUUID(),day,kind:"plan",data:{meal:"Breakfast",lines:[line(portion),line(unknown)]}};
  const draft={action:"put",revision:0,entry:plan};
  await post(draft);assert.equal((await read())[0].kind,"plan");
  await post({...draft,revision:1});
  const entries=toFoodEntries(plateRows(plan.data.lines,day,"Breakfast"));
  const eat=revision=>({action:"repeat",entries,consume:{id:plan.id,revision}});
  await post(eat(1),409);await post(eat(2),409,"synthetic-b");
  assert.equal((await read()).length,1);
  await post(eat(2));await post(eat(2));const logged=await read();
  assert.equal(logged.length,2);assert(logged.every(r=>r.kind==="food"));
  assert.equal((await read("synthetic-b")).length,0);
  const before=[...logged,{id:"review-"+day,day,kind:"review",revision:1,data:{signature:diarySignature(logged,day)}}];
  const week=weekStory(before,day,["sugar","kcal"]);
  assert.equal(week.complete,1);assert.equal(week.averages[0].value,null);assert.equal(week.averages[1].days,1);
  assert.equal(breakfastNotes(week,"sugar").length,0);
  assert.equal(weekStory([...before.slice(1),{...before[0],revision:2}],day,["p"]).complete,0);
  const experiment={id:crypto.randomUUID(),kind:"experiment",day,data:{first:"Pohe",second:"Chilla"}};
  await post({action:"put",revision:0,entry:experiment});
  const rate={kind:"hunger",id:"h-"+experiment.id+"-"+day,day,data:{experiment:experiment.id,choice:"first",rating:3}};
  await post({action:"put",revision:0,entry:rate});await post({action:"put",revision:1,entry:{...rate,data:{...rate.data,rating:2}}});
  const ratings=hungerSummary(await read(),experiment,day);
  assert.deepEqual(ratings.map(r=>[r.count,r.mean]),[[1,2],[0,null]]);
  await post({action:"put",revision:0,entry:{...rate,id:"another"}},400);
  const boxing={id:crypto.randomUUID(),day,kind:"exercise",data:{name:"Boxing",minutes:20,boxing:{rounds:4,roundMinutes:3,restSeconds:60,effort:6}}};
  await post({action:"put",revision:0,entry:boxing});assert.equal(weekStory(await read(),day,[]).minutes,20);
  const swing={id:crypto.randomUUID(),day,kind:"exercise",data:{name:"Kettlebell swing",minutes:0.5,strength:{sets:2,reps:10,loadKg:25}}};
  await post({action:"put",revision:0,entry:swing});
  assert.deepEqual((await read()).find(r=>r.id===swing.id).data.strength,swing.data.strength);
  await post({action:"put",revision:1,entry:{...swing,data:{...swing.data,strength:{sets:-1}}}},400);
  console.log("Passed pantry, household yields, missing/bounded nutrients, account isolation, stale plans, atomic consumption and retries, week completeness, breakfast ratings and boxing records.");
}finally{db.close();await rm(dir,{recursive:true,force:true})}
