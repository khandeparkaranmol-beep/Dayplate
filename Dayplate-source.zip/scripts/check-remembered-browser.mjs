import assert from "node:assert/strict";
import {DatabaseSync} from "node:sqlite";
import {createRequire} from "node:module";
import {build} from "esbuild";
import {mkdtemp,readFile,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";

const temp=await mkdtemp(join(tmpdir(),"dayplate-device-"));
const sql=new DatabaseSync(":memory:");
sql.exec(await readFile("drizzle/0003_google_sessions.sql","utf8"));
function prepared(statement,bindings=[]){
  const read=sql.prepare(statement);
  return {
    bind:(...args)=>prepared(statement,args),
    first:async()=>read.get(...bindings),
    run:async()=>({meta:{changes:read.run(...bindings).changes}})
  };
}
const db={prepare:prepared,async batch(statements){
  sql.exec("BEGIN");
  try{const rows=[];for(const s of statements)rows.push(await s.run());sql.exec("COMMIT");return rows}
  catch(e){sql.exec("ROLLBACK");throw e}
}};
globalThis.testDayplateEnv={DB:db,GOOGLE_CLIENT_ID:"fixture.apps.googleusercontent.com"};
try{
  const routes={device:"app/api/google/device/route.ts",nonce:"app/api/google/nonce/route.ts",signout:"app/api/google/signout/route.ts",account:"app/account.ts",crypto:"lib/google-token.ts",proof:"lib/remembered-browser.ts"};
  await build({entryPoints:routes,outdir:temp,bundle:true,format:"cjs",platform:"node",outExtension:{".js":".cjs"},plugins:[{
    name:"test-d1",setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:"env",namespace:"test"}));b.onLoad({filter:/.*/,namespace:"test"},()=>({contents:"export const env=globalThis.testDayplateEnv"}))}
  }]});
  const load=name=>createRequire(import.meta.url)(join(temp,name+".cjs"));
  const {digest,randomToken}=load("crypto"),{hex,proofAlgorithm,deviceAlgorithm,deviceMessage,accessLifetime,deviceLifetime}=load("proof");
  const origin="https://khandeparkaranmol-beep.github.io";
  const req=(path,token,body,source=origin)=>new Request("https://example.test/api/google/"+path,{method:body?"POST":"GET",headers:{Origin:source,...(body?{"Content-Type":"application/json"}:{}),...(token?{Authorization:"Bearer "+token}:{})},body:body?JSON.stringify(body):undefined});
  async function login(owner){const token=randomToken();await db.prepare("INSERT INTO google_sessions VALUES(?,?,?)").bind(await digest(token),owner,Date.now()+accessLifetime).run();return token}
  async function browser(){const pair=await crypto.subtle.generateKey(deviceAlgorithm,false,["sign","verify"]);return {pair,publicKey:hex(await crypto.subtle.exportKey("raw",pair.publicKey))}}
  const a=await browser(),b=await browser(),user="google:42",old=await login(user),other=await login(user);
  await assert.rejects(()=>crypto.subtle.exportKey("pkcs8",a.pair.privateKey));
  const device=(body,token,source)=>load("device").POST(req("device",token,body,source));
  const remember=(key,token)=>device({action:"remember",publicKey:key.publicKey},token);
  const identity=async token=>(await load("account").getDiaryUser(req("journal",token)))?.userId;
  async function proof(key){
    const {nonce,verifier}=await (await load("nonce").GET(req("nonce"))).json();
    return {action:"resume",publicKey:key.publicKey,verifier,proof:hex(await crypto.subtle.sign(proofAlgorithm,key.pair.privateKey,deviceMessage(nonce)))};
  }
  assert.equal((await remember(a)).status,401);
  assert.equal((await remember(a,old)).status,200);
  assert.equal((await remember(b,other)).status,200);
  assert.equal(await identity(old),user);
  const claim=await proof(a);
  assert.equal((await device({...claim,publicKey:b.publicKey})).status,401);
  assert.equal((await device(claim,null,"https://example.org")).status,403);
  const resumed=await device(claim);assert.equal(resumed.status,200);
  const fresh=(await resumed.json()).token;assert.equal(await identity(fresh),user);
  assert.equal((await device(claim)).status,409);
  await db.prepare("UPDATE google_sessions SET expires=0 WHERE digest=?").bind(await digest(fresh)).run();
  assert.equal(await identity(fresh),undefined);
  const second=(await (await device(await proof(a))).json()).token;
  assert.equal(await identity(second),user);
  const cannotEnroll=await remember(await browser(),second);assert.equal(cannotEnroll.status,401);
  const id="device:"+await digest(a.publicKey);
  const durable=await db.prepare("SELECT expires FROM google_sessions WHERE digest=?").bind(id).first();
  assert.ok(Math.abs(durable.expires-Date.now()-deviceLifetime)<5000);
  assert.equal((await load("signout").POST(req("signout",second,{}))).status,200);
  assert.equal(await identity(old),undefined);
  assert.equal((await device(await proof(a))).status,410);
  assert.equal(await identity(other),user);
  await db.prepare("UPDATE google_sessions SET expires=0 WHERE digest=?").bind("device:"+await digest(b.publicKey)).run();
  assert.equal(await identity(other),undefined);
  assert.equal((await device(await proof(b))).status,410);
  console.log("Passed remembered-browser enrollment, restart, daily renewal, expiry, device revocation and isolation.");
}finally{sql.close();delete globalThis.testDayplateEnv;await rm(temp,{recursive:true,force:true})}
