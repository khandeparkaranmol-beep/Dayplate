import {strict as assert} from "node:assert";
import {build} from "esbuild";
import {mkdtemp,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {pathToFileURL} from "node:url";
const folder=await mkdtemp(join(tmpdir(),"dayplate-signin-"));
try{
 const path=join(folder,"verify.cjs");await build({entryPoints:["lib/google-token.ts"],outfile:path,format:"cjs",bundle:true,platform:"node"});
 const {verifyGoogle}=(await import(pathToFileURL(path))).default;
 const keys=await crypto.subtle.generateKey({name:"RSASSA-PKCS1-v1_5",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-256"},true,["sign","verify"]);
 const jwk={...await crypto.subtle.exportKey("jwk",keys.publicKey),kid:"fixture",alg:"RS256",use:"sig"};
 const encode=v=>Buffer.from(JSON.stringify(v)).toString("base64url");
 const now=Date.now()/1000|0,client="tester.apps.googleusercontent.com",nonce="local-test-nonce";
 const claims={iss:"https://accounts.google.com",sub:"123456",aud:client,iat:now,exp:now+3600,nonce};
 async function sign(payload){const str=encode({alg:"RS256",kid:"fixture"})+"."+encode(payload);const sig=await crypto.subtle.sign("RSASSA-PKCS1-v1_5",keys.privateKey,new TextEncoder().encode(str));return str+"."+Buffer.from(sig).toString("base64url")}
 const read=t=>verifyGoogle(t,client,nonce,async()=>[jwk]);
 const valid=await sign(claims);assert.equal(await read(valid),"google:123456");
 for(const vals of [{aud:"other"},{iss:"wrong"},{exp:now-60},{nonce:"different"},{iat:now+300}])await assert.rejects(read(await sign({...claims,...vals})));
 await assert.rejects(read(valid.split(".").slice(0,2).join(".")+".AA"));
 console.log("Passed Google signature, issuer, audience, expiry and nonce checks with synthetic keys.");
}finally{await rm(folder,{recursive:true,force:true})}
