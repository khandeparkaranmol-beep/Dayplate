import assert from "node:assert/strict";
import {DatabaseSync} from "node:sqlite";
import {mkdtemp,readFile,readdir,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {pathToFileURL} from "node:url";
import {build} from "esbuild";
import {zipSync,strToU8} from "fflate";
const tmp=await mkdtemp(join(tmpdir(),"dayplate-account-test-"));
try{
 for(const [name,entry] of [["friends","lib/friends.ts"],["health","app/health-import.ts"]])await build({entryPoints:[entry],bundle:true,platform:"node",format:"cjs",outfile:join(tmp,name+".cjs")});
 const {social}=(await import(pathToFileURL(join(tmp,"friends.cjs")))).default;
 const health=(await import(pathToFileURL(join(tmp,"health.cjs")))).default;
 const sql=new DatabaseSync(":memory:");for(const name of (await readdir("drizzle")).filter(n=>n.endsWith(".sql")).sort())sql.exec(await readFile(join("drizzle",name),"utf8"));
 const db={prepare(query){return {bind(...args){const statement=sql.prepare(query);return {first:()=>statement.get(...args),all:()=>({results:statement.all(...args)}),run:()=>({meta:statement.run(...args)})}}}},async batch(ops){sql.exec("BEGIN");try{const result=ops.map(x=>x.run());sql.exec("COMMIT");return result}catch(e){sql.exec("ROLLBACK");throw e}}};
 const act=async(u,body,expected=200)=>{const r=await social(db,u,body);const v=await r.json();assert.equal(r.status,expected,JSON.stringify(v));return v};
 await act(null,undefined,401);await act("A",{action:"profile",handle:"amma"});await act("B",{action:"profile",handle:"baba"});await act("C",{action:"profile",handle:"cousin"});await act("D",{action:"profile",handle:"AMMA"},409);
 const id=crypto.randomUUID(),challenge={action:"challenge",peer:"baba",id,metric:"steps",length:7};
 await act("A",challenge,409);await act("A",{action:"friend",peer:"BABA"});await act("A",{action:"acceptFriend",peer:"baba"},409);await act("B",{action:"acceptFriend",peer:"amma"});await act("A",challenge);const day=new Date().toISOString().slice(0,10);
 await act("A",{action:"acceptMatch",id,day},409);await act("C",{action:"acceptMatch",id,day},409);await act("B",{action:"acceptMatch",id,day});
 const insert=sql.prepare("INSERT INTO journal_records VALUES(?,?,?,?,?,1)");insert.run("A","activity-"+day,"activity",day,JSON.stringify({steps:7800,active:303,resting:1300}));insert.run("B","activity-"+day,"activity",day,JSON.stringify({steps:4100}));
 const feed=await act("A");assert.equal(feed.matches[0].mine,7800);assert.equal(feed.matches[0].theirs,4100);assert.equal((await act("C")).matches.length,0);assert(!JSON.stringify(feed).includes("resting"));
 const post=crypto.randomUUID();await act("A",{action:"post",id:post,content:"Went for a walk"});assert.equal((await act("C")).posts.length,0);await act("B",{action:"cheer",id:post,on:true});assert.equal((await act("A")).posts[0].cheers,1);await act("C",{action:"removePost",id:post},409);await act("A",{action:"removeFriend",peer:"baba"});assert.equal((await act("B")).posts.length,0);assert.equal((await act("A")).matches.length,0);
 const xml='<?xml version="1.0"?><!DOCTYPE HealthData [<!ELEMENT HealthData ANY>]><HealthData locale="en_IN">'+
 ['Phone','Watch'].map((x,i)=>'<Record type="HKQuantityTypeIdentifierStepCount" sourceName="'+x+'" unit="count" startDate="2026-11-19 10:00:00 +0530" value="'+(1000+i*300)+'"/>').join('')+
 '<Record type="HKQuantityTypeIdentifierActiveEnergyBurned" sourceName="Watch" unit="kJ" value="418.4" startDate="2026-11-19 10:00:00 +0530"/><Record type="HKQuantityTypeIdentifierBasalEnergyBurned" sourceName="Watch" unit="kcal" value="1500" startDate="2026-11-19 10:00:00 +0530"/><ActivitySummary dateComponents="2026-11-19" activeEnergyBurned="320" activeEnergyBurnedUnit="kcal"/>'+
 '<Workout sourceName="Watch" workoutActivityType="HKWorkoutActivityTypeWalking" duration="25" durationUnit="min" startDate="2026-11-19 10:00:00 +0530" endDate="2026-11-19 10:25:00 +0530"/></HealthData>';
 const results=[];for(const file of [new File([xml],"export.xml"),new File([zipSync({"apple_health_export/export.xml":strToU8(xml),"apple_health_export/workout-routes/ignore.gpx":strToU8("<private/>")})],"export.zip")]){
 const parsed=await health.parseHealth(file);const choices=health.initialSources(parsed);assert.equal(choices.steps,"");choices.steps="Watch";
 const entries=await health.importRows(parsed,choices,"2026-11-01","2026-11-30");assert.equal(entries.length,2);assert.equal(entries[0].data.steps,1300);assert.equal(entries[0].data.active,320);assert.equal(entries[0].data.resting,1500);assert.equal(entries[1].data.minutes,25);assert.equal(entries[1].data.health.start,"2026-11-19T04:30:00.000Z");results.push(entries)}
 assert.deepEqual(results[0],results[1]);console.log("Passed private accounts, friend consent, challenges, scores, cheers, removal, and Apple XML/ZIP imports with overlapping sources.");
}finally{await rm(tmp,{recursive:true,force:true})}
